/*
-------------------------------------------------------------------------------
FORMATO M�TRICA MTR:
--------------------
En este archivo se guarda la informaci�n  del rango de  caracteres,  su  tama�o
m�ximo, el color de la fuente y del fondo, y  por  �ltimo  el  avance  de  cada 
caracter individual.
El  nombre  de  la  imagen PNG  debe ser el mismo que el del archivo MTR, salvo
la extensi�n de formato.
-------------------------------------------------------------------------------
MTR MEASURE FORMAT:
-------------------
In this file information range of characters, its maximum size, font color  and
background, and finally the progress of each  individual  character  is  saved.
PNG name the image must be the same  as  the  MTR  file  except  the  extension 
format.
-------------------------------------------------------------------------------
// FORMAT MTR:
				SDL_RWops *datafile = SDL_RWFromFile( filename_mtr, "w" );
// In initial check of the file.
[0000000000]	SDL_WriteU8( datafile, 'M' );
[0000000001]	SDL_WriteU8( datafile, 'T' );
[0000000002]	SDL_WriteU8( datafile, 'R' );
-------------------------------------------------------------------------------
// Range of characters:
[0000000003]	SDL_WriteU8( datafile, cMin );
[0000000004]    SDL_WriteU8( datafile, cMax );
-------------------------------------------------------------------------------
// Maximum size:
[0000000005]	SDL_WriteU8( datafile, width  );
[0000000006]	SDL_WriteU8( datafile, height );
-------------------------------------------------------------------------------
// Font color:
[0000000007]	SDL_WriteU8( datafile, 'F' ); // Middel check of the file: 'F' 'B' 'A'
[0000000008]	SDL_WriteU8( datafile, FR );
[0000000009]	SDL_WriteU8( datafile, FG );
[0000000010]	SDL_WriteU8( datafile, FB );
-------------------------------------------------------------------------------
// Background color:
[0000000011]	SDL_WriteU8( datafile, 'B' ); // Middel check of the file: 'F' 'B' 'A'
[0000000012]	SDL_WriteU8( datafile, BR );
[0000000013]	SDL_WriteU8( datafile, BG );
[0000000014]	SDL_WriteU8( datafile, BB );
-------------------------------------------------------------------------------
// Advance:
[0000000015]	SDL_WriteU8( datafile, 'A' ); // Middel check of the file: 'F' 'B' 'A'
				int numChr = (cMax - cMin + 1);
				for( Uint8 letter = cMin; letter < cMax; ++letter ) {
	    			int advance;
					TTF_GlyphMetrics( font_ttf, (Uint16)letter, NULL, NULL, NULL, NULL, &advance );
[0000000016]		SDL_WriteU8( datafile, (Uint8)advance );
				}
-------------------------------------------------------------------------------
// Final check of the file.
[017+numChr]	SDL_WriteU8( datafile, 'E' );
[018+numChr]	SDL_WriteU8( datafile, 'N' );
[019+numChr]	SDL_WriteU8( datafile, 'D' );
				SDL_RWclose( datafile );
-------------------------------------------------------------------------------
*/

#define SDL_MAIN_HANDLED
#include "SDL2/SDL.h"
#include "SDL2/SDL_image.h"
#include "SDL2/SDL_ttf.h"
// #define ESTRECHO

// -----------------------------------------------------------------------------
// -- CONVERSOR DE TTF A BMP, PROGRAMADO POR PIPAGERARDO                      --
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// MAIN FUNCION PRINCIPAL:
// -----------------------------------------------------------------------------
int main( int argc, char *argv[] ) { 
	
	// FRONT COLOR:
	Uint8 FR = 255; 
	Uint8 FG = 255; 
	Uint8 FB = 255; 
	Uint8 FA = 255;

	// BACK COLOR:
	Uint8 BR = 0;   
	Uint8 BG = 0;   
	Uint8 BB = 0;
	Uint8 BA = 0;
	
	// EDGE SHARED COLOR:
	Uint8 ER = 127;
	Uint8 EG = 127; 
	Uint8 EB = 127;
	Uint8 EA = 255;
	
	#define SIZE_NAME 160
	char nombre_fuente_ttf[ SIZE_NAME ];
	char nombre_imagen_png[ SIZE_NAME ];
	char nombre_datos_mtr[  SIZE_NAME ];
	int tamano_de_la_fuente = 16;				// [6-128] pixels
	int estilo_de_la_fuente = TTF_STYLE_NORMAL; // TTF_STYLE_NORMAL | TTF_STYLE_BOLD | TTF_STYLE_ITALIC | TTF_STYLE_UNDERLINE | TTF_STYLE_STRIKETHROUGH 
	int tipo_de_la_fuente   = 1;				// 1 Solid | 2 Shaded | 3 Blended
	SDL_bool alpha          = SDL_FALSE; 		// SDL_FALSE | SDL_TRUE
	SDL_bool center		    = SDL_FALSE;		// SDL_FALSE | SDL_TRUE
	unsigned char cMin      = 0;    // 32;      // Caracter m�nimo >= 0.
	unsigned char cMax      = 255;  // 255;     // Caracter m�ximo <= 255.

	// ---------------------------------------------------------
	// SDL_strlcpy( nombre_fuente_ttf, "arial.ttf", SIZE_NAME );
	// ---------------------------------------------------------
	int alto   = 0;	 // Alto m�ximo de un caracter.
	int ancho  = 0;  // Ancho m�ximo de un caracter.
	int avance = 0;  // Avance de un caracter.
	int anchoImagen = 0;
	int altoImagen  = 0;
	int minx, maxx;
	unsigned int letra;
	int numChr; // N�mero de caracteres;
	char texto[2];
	int    bpp;
	Uint32 Rmask, Gmask, Bmask, Amask;
  	int iy, ix;
	SDL_Rect rect;
	TTF_Font    *mi_fuente = NULL;
  	SDL_Surface *img_texto = NULL;
  	SDL_Surface *imgRGBA   = NULL;
  	SDL_Surface *imgRGB    = NULL;
	SDL_Window  *window    = NULL;
	SDL_Surface *screen    = NULL;
	SDL_RWops   *datafile  = NULL;
	// ---------------------------------------------------------
	
	if( argc > 1 ) {
		
		SDL_strlcpy( nombre_fuente_ttf, argv[1], SIZE_NAME );
							
		int n_argc;
		for( n_argc = 2; n_argc < argc; ++n_argc ) {

			if( SDL_strstr( argv[ n_argc ], "-size" ) ) {
				++n_argc;
				tamano_de_la_fuente = SDL_atoi( argv[ n_argc ] );
				if     ( tamano_de_la_fuente < 6   ) tamano_de_la_fuente = 6;
				else if( tamano_de_la_fuente > 128 ) tamano_de_la_fuente = 128;
			}
			
			if( SDL_strstr( argv[ n_argc ], "-char" ) ) {
				++n_argc; cMin = (unsigned char)SDL_atoi( argv[ n_argc ] );
				++n_argc; cMax = (unsigned char)SDL_atoi( argv[ n_argc ] );
				if     ( cMin >= cMax  ) { cMin = 0; cMax = 255; }
				else if( cMax < 1    )   { cMin = 0; cMax = 255; }
			}

			if( SDL_strstr( argv[ n_argc ], "-alpha" ) ) {
				++n_argc;
				if( SDL_strstr( argv[ n_argc ], "on"  ) ) alpha = SDL_TRUE; 
				if( SDL_strstr( argv[ n_argc ], "off" ) ) alpha = SDL_FALSE;
			}
	
			if( SDL_strstr( argv[ n_argc ], "-center"   ) ) {
				++n_argc;
				if( SDL_strstr( argv[ n_argc ], "on"  ) ) center = SDL_TRUE;
				if( SDL_strstr( argv[ n_argc ], "off" ) ) center = SDL_FALSE;
			}

			if( SDL_strstr( argv[ n_argc ], "-normal"   ) ) estilo_de_la_fuente |= TTF_STYLE_NORMAL;
			if( SDL_strstr( argv[ n_argc ], "-bold"     ) ) estilo_de_la_fuente |= TTF_STYLE_BOLD;
			if( SDL_strstr( argv[ n_argc ], "-italic"   ) ) estilo_de_la_fuente |= TTF_STYLE_ITALIC;
			if( SDL_strstr( argv[ n_argc ], "-under"    ) ) estilo_de_la_fuente |= TTF_STYLE_UNDERLINE;
			if( SDL_strstr( argv[ n_argc ], "-strike"   ) ) estilo_de_la_fuente |= TTF_STYLE_STRIKETHROUGH;
			
			if( SDL_strstr( argv[ n_argc ], "-type" ) ) {
				++n_argc;
				if( SDL_strstr( argv[ n_argc ], "solid"    ) ) tipo_de_la_fuente = 1;
				if( SDL_strstr( argv[ n_argc ], "shaded"   ) ) tipo_de_la_fuente = 2;
				if( SDL_strstr( argv[ n_argc ], "blended"  ) ) tipo_de_la_fuente = 3;
			}
			
			if( SDL_strstr( argv[ n_argc ], "-front" ) ) {
				++n_argc; FR = (Uint8)SDL_atoi( argv[ n_argc ] );
				++n_argc; FG = (Uint8)SDL_atoi( argv[ n_argc ] );
				++n_argc; FB = (Uint8)SDL_atoi( argv[ n_argc ] );	
			}

			if( SDL_strstr( argv[ n_argc ], "-back" ) ) {
				++n_argc; BR = (Uint8)SDL_atoi( argv[ n_argc ] );
				++n_argc; BG = (Uint8)SDL_atoi( argv[ n_argc ] );
				++n_argc; BB = (Uint8)SDL_atoi( argv[ n_argc ] );	
			}

			if( SDL_strstr( argv[ n_argc ], "-edge" ) ) {
				++n_argc; ER = (Uint8)SDL_atoi( argv[ n_argc ] );
				++n_argc; EG = (Uint8)SDL_atoi( argv[ n_argc ] );
				++n_argc; EB = (Uint8)SDL_atoi( argv[ n_argc ] );	
			}
			
		}
	
	} else {
		SDL_Log( "------------------------------------------------------------------------\n" );
		SDL_Log( "TTF2PNG.EXE font.ttf [options] [Style Font] [Type Render] [Color RGB]\n" );
		SDL_Log( "Options:\n" );
		SDL_Log( "  -size   [6-128]           (default 16)\n" );
		SDL_Log( "  -char   [0-255] [0-255]   (default 0 255, recommended 32 255)\n" );
		SDL_Log( "  -alpha  [on|off]          (default off)\n");
		SDL_Log( "  -center [on|off]          (default off)\n");
		SDL_Log( "Style Font:\n" );
		SDL_Log( "  -normal (default)\n" );
		SDL_Log( "  -bold\n" );
		SDL_Log( "  -italic\n" );
		SDL_Log( "  -under\n" );
		SDL_Log( "  -strike\n" );
		SDL_Log( "Type Render:\n" );
		SDL_Log( "  -type   [solid|shaded|blended]  (default solid)\n");		
		SDL_Log( "Color RGB:\n" );
		SDL_Log( "  -front  [0-255] [0-255] [0-255] (default 255 255 255)\n");
		SDL_Log( "  -back   [0-255] [0-255] [0-255] (default   0   0   0)\n");
		SDL_Log( "  -edge   [0-255] [0-255] [0-255] (default 127 127 127)\n");
		SDL_Log( "           The edge color only works with shaded render.\n" );
		SDL_Log( "------------------------------------------------------------------------\n" );
		SDL_Log( "Examples:\n" );
		SDL_Log( "  TTF2BMP arial.ttf\n" );
		SDL_Log( "  TTF2BMP arial.ttf -char 32 255\n" );
		SDL_Log( "  TTF2BMP arial.ttf -size 20 -bold\n" );
		SDL_Log( "  TTF2BMP arial.ttf -alpha on -front 255 255 0 -back 0 127 0\n" );
		SDL_Log( "  TTF2BMP arial.ttf -size 24 -alpha on -bold -under -type shaded \n" );
		SDL_Log( "------------------------------------------------------------------------\n" );
		
		return 0;
	}

	SDL_strlcpy( nombre_datos_mtr, nombre_fuente_ttf, SIZE_NAME );
	nombre_datos_mtr[ SDL_strlen(  nombre_datos_mtr ) - 4 ] = 0;

	char t_texto[SIZE_NAME];	
	if( SDL_uitoa( (unsigned int)tamano_de_la_fuente, t_texto, 10 ) ) {
		SDL_strlcat( nombre_datos_mtr, "-Size", SIZE_NAME );
		SDL_strlcat( nombre_datos_mtr, t_texto, SIZE_NAME );		
	}
	if( ( cMin != 0) || ( cMax != 255 ) ) {
		if( SDL_uitoa( (unsigned int)cMin, t_texto, 10 ) ) {
			SDL_strlcat( nombre_datos_mtr, "-Char", SIZE_NAME );
			SDL_strlcat( nombre_datos_mtr, t_texto, SIZE_NAME );		
		}
		if( SDL_uitoa( (unsigned int)cMax, t_texto, 10 ) ) {
			SDL_strlcat( nombre_datos_mtr, "-", SIZE_NAME );
			SDL_strlcat( nombre_datos_mtr, t_texto, SIZE_NAME );		
		}
	}
	if( alpha ) {
		SDL_strlcat( nombre_datos_mtr, "-Alpha", SIZE_NAME );
	}
	if( center ) {
		SDL_strlcat( nombre_datos_mtr, "-Center", SIZE_NAME );
	}

	if( tipo_de_la_fuente == 1 ) SDL_strlcat( nombre_datos_mtr, "-Solid",   SIZE_NAME );
	if( tipo_de_la_fuente == 2 ) SDL_strlcat( nombre_datos_mtr, "-Shaded",  SIZE_NAME );
    if( tipo_de_la_fuente == 3 ) SDL_strlcat( nombre_datos_mtr, "-Blended", SIZE_NAME );

    if( estilo_de_la_fuente == TTF_STYLE_NORMAL       ) SDL_strlcat( nombre_datos_mtr, "-N",  SIZE_NAME );
    if( estilo_de_la_fuente & TTF_STYLE_BOLD          ) SDL_strlcat( nombre_datos_mtr, "-B",  SIZE_NAME );
    if( estilo_de_la_fuente & TTF_STYLE_ITALIC        ) SDL_strlcat( nombre_datos_mtr, "-I",  SIZE_NAME );
    if( estilo_de_la_fuente & TTF_STYLE_UNDERLINE     ) SDL_strlcat( nombre_datos_mtr, "-U",  SIZE_NAME );
    if( estilo_de_la_fuente & TTF_STYLE_STRIKETHROUGH ) SDL_strlcat( nombre_datos_mtr, "-S",  SIZE_NAME );

	SDL_strlcpy( nombre_imagen_png, nombre_datos_mtr, SIZE_NAME );
	SDL_strlcat( nombre_datos_mtr,  ".mtr", SIZE_NAME );
	SDL_strlcat( nombre_imagen_png, ".png", SIZE_NAME );
		
	SDL_Log( "font   name = %s\n", nombre_fuente_ttf );
	SDL_Log( "bitmap name = %s\n", nombre_imagen_png );
	SDL_Log( "data   name = %s\n", nombre_datos_mtr );
	SDL_Log( "font   size = %d\n", tamano_de_la_fuente );
	SDL_Log( "char min    = %u\n", cMin );
	SDL_Log( "char max    = %u\n", cMax );	
	if( alpha )	                 SDL_Log( "alpha = Alpha Blend 32 bits RGBA\n");
	else                         SDL_Log( "alpha = No Alpha Blend 24 bits RGB\n");
	if( center )                 SDL_Log( "center = Center\n");
	else                         SDL_Log( "center = No center\n");
    if( estilo_de_la_fuente == TTF_STYLE_NORMAL       ) SDL_Log( "style = Normal\n" );
    if( estilo_de_la_fuente & TTF_STYLE_BOLD          ) SDL_Log( "style = Bold\n" );
    if( estilo_de_la_fuente & TTF_STYLE_ITALIC        ) SDL_Log( "style = Italic\n" );
    if( estilo_de_la_fuente & TTF_STYLE_UNDERLINE     ) SDL_Log( "style = UnderLine\n" );
    if( estilo_de_la_fuente & TTF_STYLE_STRIKETHROUGH ) SDL_Log( "style = StrikeThrough\n" );
	if( tipo_de_la_fuente == 1 ) SDL_Log( "type  = Solid\n");
	if( tipo_de_la_fuente == 2 ) SDL_Log( "type  = Shaded\n");
	if( tipo_de_la_fuente == 3 ) SDL_Log( "type  = Blended\n");
	SDL_Log( "front color = %u %u %u\n", FR, FG, FB );
	SDL_Log( "back  color = %u %u %u\n", BR, BG, BB );
	SDL_Log( "edge  color = %u %u %u\n", ER, EG, EB );

	// --------------------------------------------------------------------------------  
	// INICIAMOS LOS SISTEMAS Y CARGAMOS LA FUENTE:
	// --------------------------------------------------------------------------------  
	SDL_SetHint( SDL_HINT_RENDER_DRIVER,            "direct3d"  ); // "direct3d" | "opengl" | "software"
	SDL_SetHint( SDL_HINT_FRAMEBUFFER_ACCELERATION, "direct3d"  ); // "direct3d" | "opengl" | "software"
	SDL_SetHint( SDL_HINT_RENDER_VSYNC,             "1"         );  // "0" | "1"
	SDL_SetHint( SDL_HINT_RENDER_SCALE_QUALITY,     "nearest"   );  // "nearest" | "linear"

	// Initialize SDL
	SDL_SetMainReady();
	if( SDL_Init( SDL_INIT_VIDEO  | SDL_INIT_EVENTS  | SDL_INIT_TIMER ) < 0 ) {
		SDL_Log( "SDL could not initialize! SDL Error: %s\n", SDL_GetError() );
		return 1;
	}
	
	// Init image
	IMG_Init( IMG_INIT_PNG );
	
	// Initialize TTF
	if( TTF_Init() == -1 ) {
    	SDL_Log( "TTF_Init: %s\n", TTF_GetError() );
    	SDL_Quit();
    	return 0;
	}
	
	// TTF_Font *TTF_OpenFont(const char *file, int ptsize);
	mi_fuente = TTF_OpenFont( nombre_fuente_ttf, tamano_de_la_fuente );
	// long TTF_FontFaces( const TTF_Font *font );
	// TTF_Font *TTF_OpenFontIndex(const char *file, int ptsize, long index );
	if( mi_fuente == NULL ) {
    	SDL_Log( "TTF_OpenFont: %s\n", TTF_GetError() );
    	TTF_Quit();
		SDL_Quit();
		return 0;
	}
	TTF_SetFontStyle(   mi_fuente, estilo_de_la_fuente );
    // TTF_HINTING_NORMAL | TTF_HINTING_LIGHT | TTF_HINTING_MONO | TTF_HINTING_NONE
	TTF_SetFontHinting( mi_fuente, TTF_HINTING_NORMAL );
	// --------------------------------------------------------------------------------

	// --------------------------------------------------------------------------------
	// OBTENEMOS LAS MEDIDAS DE LA FUENTE
	// --------------------------------------------------------------------------------
	alto  = TTF_FontHeight( mi_fuente );
	// alto  = TTF_FontLineSkip( mi_fuente );
	ancho = 0;
	for( letra = cMin; letra < cMax; ++letra ) {
		if( TTF_GlyphIsProvided( mi_fuente, (Uint16)letra ) ) {
		TTF_GlyphMetrics( mi_fuente,  (Uint16)letra, &minx, &maxx, NULL, NULL, &avance );
			#ifdef ESTRECHO
				int t_ancho = maxx - minx;
			#else
				int t_ancho = avance;
			#endif
			// SDL_Log( "%c %u %d %d %u\n" , letra, letra, minx, maxx, avance );
			if( t_ancho > ancho ) ancho = t_ancho;
		}
	}
	numChr = (cMax - cMin + 1); 			// N�mero de caracteres.
	anchoImagen = ancho * 16;				// El ancho total de la imagen.
	altoImagen  = alto  * ( numChr / 16 );	// El alto total de la imagen.
	if( numChr % 16 ) altoImagen += alto;	// Si no es exacto.
	SDL_Log( "ancho * alto = %d * %d\n", ancho, alto );
	SDL_Log( "anchoImagen * altoImagen = %d * %d\n", anchoImagen, altoImagen );
	// --------------------------------------------------------------------------------

	// ---------------------------------------------------------------------------
	// CREAMOS LA IMAGEN:
	// ---------------------------------------------------------------------------
	SDL_PixelFormatEnumToMasks( SDL_PIXELFORMAT_RGBA8888, &bpp, &Rmask, &Gmask, &Bmask, &Amask );
	imgRGBA = SDL_CreateRGBSurface( 0, anchoImagen, altoImagen, bpp, Rmask, Gmask, Bmask, Amask );
	if( imgRGBA == NULL ) {
		SDL_Log( "Not create surface RGBA! SDL Error: %s\n", SDL_GetError() );
		IMG_Quit();
  		TTF_CloseFont( mi_fuente );
  		TTF_Quit();
		SDL_Quit();
		return 0;
	}
	SDL_FillRect( imgRGBA, NULL, SDL_MapRGBA( imgRGBA->format, BR, BG, BB, BA ) );
	if( tipo_de_la_fuente == 2 ) SDL_SetColorKey( imgRGBA, SDL_TRUE, SDL_MapRGBA( imgRGBA->format, ER, EG, EB, EA ) );
				
	SDL_PixelFormatEnumToMasks( SDL_PIXELFORMAT_RGB888, &bpp, &Rmask, &Gmask, &Bmask, &Amask );
	imgRGB = SDL_CreateRGBSurface( 0, anchoImagen, altoImagen, bpp, Rmask, Gmask, Bmask, Amask );
	if( imgRGB == NULL ) {
		SDL_Log( "Not create surface RGB! SDL Error: %s\n", SDL_GetError() );
		IMG_Quit();
  		TTF_CloseFont( mi_fuente );
  		TTF_Quit();
		SDL_Quit();
		return 0;
	}
	SDL_FillRect( imgRGB, NULL, SDL_MapRGB( imgRGB->format, BR, BG, BB ) );
	// ---------------------------------------------------------------------------
 
	// ---------------------------------------------------------------------------
	// PINTAMOS LA IMAGEN CON LOS CARACTERES:
	// ---------------------------------------------------------------------------
	datafile = SDL_RWFromFile( nombre_datos_mtr, "w" );
	SDL_WriteU8( datafile, 'M' );
	SDL_WriteU8( datafile, 'T' );
	SDL_WriteU8( datafile, 'R' );
	SDL_WriteU8( datafile, cMin );
    SDL_WriteU8( datafile, cMax );
	SDL_WriteU8( datafile, (Uint8)ancho );
	SDL_WriteU8( datafile, (Uint8)alto  );
	SDL_WriteU8( datafile, 'F' );
	SDL_WriteU8( datafile, FR );
	SDL_WriteU8( datafile, FG );
	SDL_WriteU8( datafile, FB );
	SDL_WriteU8( datafile, 'B' );
	SDL_WriteU8( datafile, BR );
	SDL_WriteU8( datafile, BG );
	SDL_WriteU8( datafile, BB );
	SDL_WriteU8( datafile, 'A' );
	letra  = cMin;
  	rect.x = 0;     rect.y = 0;
  	rect.w = ancho; rect.h = alto;
	for( iy = 0; iy <16; iy++ ) {
    	rect.x = 0; 
    	for ( ix = 0; ix < 16; ix++ ) {
			texto[0] = letra; texto[1] = 0;	
    		if( tipo_de_la_fuente == 1 ) {
    			img_texto = TTF_RenderText_Solid(   mi_fuente, texto, (SDL_Color){ FR, FG, FB, FA } );
    		} else if( tipo_de_la_fuente == 2 ) {
				img_texto = TTF_RenderText_Shaded(  mi_fuente, texto, (SDL_Color){ FR, FG, FB, FA }, (SDL_Color){ ER, EG, EB, EA } );
    		} else {
    			img_texto = TTF_RenderText_Blended( mi_fuente, texto, (SDL_Color){ FR, FG, FB, FA } );
    		}
			int t_x = rect.x;
			if( TTF_GlyphIsProvided( mi_fuente, (Uint16)letra ) ) {
				TTF_GlyphMetrics(    mi_fuente, (Uint16)letra, &minx, &maxx, NULL, NULL, &avance );
				#ifdef ESTRECHO
					avance = maxx - minx;
				#endif
				rect.w = avance; 
				int t_min = ( ( ancho - avance ) >> 1 );
				if( center ) rect.x += t_min;
				SDL_BlitSurface( img_texto, NULL, imgRGBA, &rect);
				SDL_FreeSurface( img_texto ); 
			} else avance = ancho;
			// SDL_Log( "%u %u\n", letra, avance );
			SDL_WriteU8( datafile, (Uint8)avance ); 
			rect.x = t_x + ancho;
			letra++;
			if( letra > cMax ) break;
		}
		if( letra > cMax ) break;
		rect.y += alto; 
	}
	SDL_WriteU8( datafile, 'E' );
	SDL_WriteU8( datafile, 'N' );
	SDL_WriteU8( datafile, 'D' );
	SDL_RWclose( datafile );
	SDL_BlitSurface( imgRGBA, NULL, imgRGB, NULL );
	if( alpha )	IMG_SavePNG( imgRGBA, nombre_imagen_png );
	else        IMG_SavePNG( imgRGB,  nombre_imagen_png );
	// ---------------------------------------------------------------------------
	

	// --------------------------------------------------------------------------------
	// CREAMOS LA VENTANA Y MOSTRAMOS EL RESULTADO:
	// --------------------------------------------------------------------------------
	window = SDL_CreateWindow(
		"Abbaye des Morts v2.0",
		SDL_WINDOWPOS_CENTERED,
		SDL_WINDOWPOS_CENTERED,
		anchoImagen,
		altoImagen,
		SDL_WINDOW_HIDDEN
	);
	if( window == NULL ) {
		SDL_Log( "Window not initialize! SDL Error: %s\n", SDL_GetError() );
		IMG_Quit();
	  	TTF_CloseFont( mi_fuente );
  		TTF_Quit();
		SDL_FreeSurface( imgRGBA ); 
		SDL_FreeSurface( imgRGB  ); 
		SDL_Quit();
		return 0;
	}
	screen = SDL_GetWindowSurface( window );
	if( screen == NULL ) {
		SDL_Log( "Not get windows surface! SDL Error: %s\n", SDL_GetError() );
		IMG_Quit();
	  	TTF_CloseFont( mi_fuente );
  		TTF_Quit();
		SDL_FreeSurface( imgRGBA ); 
		SDL_FreeSurface( imgRGB  ); 
		SDL_DestroyWindow( window );
		SDL_Quit();
		return 0;
	}
	SDL_ShowWindow( window );
	SDL_ShowCursor( SDL_ENABLE /* SDL_DISABLE  */ );  // Mostrar el cursor gen�rico windows.
  	SDL_bool continuar = SDL_TRUE;
  	SDL_Event event;
	while( continuar ) {
		
		SDL_FillRect( screen, NULL, SDL_MapRGB( screen->format, 255, 0, 255 ) ); 
	    if( alpha ) SDL_BlitSurface( imgRGBA, NULL, screen, NULL );
	    else		SDL_BlitSurface( imgRGB,  NULL, screen, NULL );
	    
	    rect.x = 0;
	    rect.y = 0;

	    for ( iy = 0; iy <= altoImagen + alto; iy+= alto ) {
	    	rect.x = 0;
	    	rect.w = anchoImagen;
	    	rect.h = 1;
    		SDL_FillRect( screen, &rect, SDL_MapRGB( screen->format, 255, 255, 0 ) ); 
    		for ( ix = 0; ix <= anchoImagen + ancho; ix+= ancho ) {
	    		rect.w = 1;
	    		rect.h = altoImagen;
    			SDL_FillRect( screen, &rect, SDL_MapRGB( screen->format, 255, 255, 0 ) ); 
    			rect.x = ix;
    		}
    		rect.y = iy;
    	}
    		
    	SDL_UpdateWindowSurface( window );
    	
    	SDL_PollEvent( &event );
		switch( event.type ) {
			case SDL_QUIT: 			continuar = SDL_FALSE; break;
			case SDL_KEYDOWN:
			switch( event.key.keysym.sym ) {
				case SDLK_ESCAPE:	continuar = SDL_FALSE; break;
			}
		}
		SDL_Delay( 100 );

  	}
	// ---------------------------------------------------------------------------		

    
    // ---------------------------------------------------------------------------		
	// CERRAMOS TODO Y SALIMOS:
    // ---------------------------------------------------------------------------		
	IMG_Quit();
  	TTF_CloseFont( mi_fuente );
  	TTF_Quit();
  	SDL_FreeSurface( imgRGBA ); 
  	SDL_FreeSurface( imgRGB  ); 
  	SDL_FreeSurface(  screen );
	SDL_DestroyWindow( window );
	SDL_Quit();
	return 1;
}

/*
size_t SDL_RWfgets( SDL_RWops* context, char* str, size_t num ) {
	if( context == NULL ) return 0;
	if( str     == NULL ) return 0;
	if( num     <  2    ) return 0;
	--num;
	size_t i = 0;
	char   c = 0;
	while( i < num ) { 
		if( SDL_RWread( context, &c, 1, 1 ) == 0 ) break;
		if( c == '\r' ) continue;
		if( c == '\n' ) { str[ i ] = 0; ++i; break; }
		str[ i ] = c; ++i;
	}
	if( i < num ) str[i] = 0;
	return i;
}
*/
// SDL_Surface *TTF_RenderText_Solid(      TTF_Font *font, const char   *text, SDL_Color fg );
// SDL_Surface *TTF_RenderUTF8_Solid(      TTF_Font *font, const char   *text, SDL_Color fg );
// SDL_Surface *TTF_RenderUNICODE_Solid(   TTF_Font *font, const Uint16 *text, SDL_Color fg );
    		
// SDL_Surface *TTF_RenderText_Shaded(     TTF_Font *font, const char   *text, SDL_Color fg, SDL_Color bg );
// SDL_Surface *TTF_RenderUTF8_Shaded(     TTF_Font *font, const char   *text, SDL_Color fg, SDL_Color bg );
// SDL_Surface *TTF_RenderUNICODE_Shaded(  TTF_Font *font, const Uint16 *text, SDL_Color fg, SDL_Color bg );
 
// Blended Create a 32-bit ARGB:
// SDL_Surface *TTF_RenderText_Blended(    TTF_Font *font, const char   *text, SDL_Color fg );
// SDL_Surface *TTF_RenderUTF8_Blended(    TTF_Font *font, const char   *text, SDL_Color fg );
// SDL_Surface *TTF_RenderUNICODE_Blended( TTF_Font *font, const Uint16 *text, SDL_Color fg );
    
