#define SDL_MAIN_HANDLED
#include "SDL2/SDL.h"
#include "SDL2/SDL_image.h"
#include "SDL_font.h"

#define _RENDER_
	
// -----------------------------------------------------------------------------
// MAIN FUNCION PRINCIPAL:
// -----------------------------------------------------------------------------
int main(int argc, char *argv[]) { // Inicimamos la Librerias SDL. ----------------------------------------------
	
	int alto   = 0;	 // Alto m�ximo de un caracter.
	int ancho  = 0;  // Ancho m�ximo de un caracter.
	int avance = 0;  // Avance de un caracter.
	int anchoImagen = 256;
	int altoImagen  = 192;
	
	SDL_Window   *window = NULL;
	SDL_Renderer *render = NULL;
	SDL_Surface  *screen = NULL;	
  	SDL_bool continuar = SDL_TRUE;
  	SDL_Event event;
  	
	// --------------------------------------------------------------------------------  
	// INICIAMOS LOS SISTEMAS Y CARGAMOS LA FUENTE:
	// --------------------------------------------------------------------------------  
/*
	SDL_SetHint( SDL_HINT_RENDER_DRIVER,            "direct3d"  ); // "direct3d" | "opengl" | "software"
	SDL_SetHint( SDL_HINT_FRAMEBUFFER_ACCELERATION, "direct3d"  ); // "direct3d" | "opengl" | "software"
	SDL_SetHint( SDL_HINT_RENDER_OPENGL_SHADERS,    "0"         );
	SDL_SetHint( SDL_HINT_RENDER_VSYNC,             "1"         );  // "0" | "1"
	SDL_SetHint( SDL_HINT_RENDER_SCALE_QUALITY,     "nearest"   );  // "nearest" | "linear"
*/
	SDL_SetHint( SDL_HINT_RENDER_DRIVER,            "direct3d"  ); // "direct3d" | "opengl" | "software"
	SDL_SetHint( SDL_HINT_FRAMEBUFFER_ACCELERATION, "direct3d"  ); // "direct3d" | "opengl" | "software"
	SDL_SetHint( SDL_HINT_RENDER_VSYNC,             "1"         );  // "0" | "1"
	SDL_SetHint( SDL_HINT_RENDER_SCALE_QUALITY,     "nearest"   );  // "nearest" | "linear"

	
	// Initialize SDL
	SDL_SetMainReady();
	if( SDL_Init( SDL_INIT_VIDEO  | SDL_INIT_EVENTS  | SDL_INIT_TIMER ) < 0 ) {
		SDL_Log( "SDL could not initialize! SDL Error: %s\n", SDL_GetError() );
		return 1;
	}
	// Init image
	IMG_Init( IMG_INIT_PNG );
	// --------------------------------------------------------------------------------   
	
	// --------------------------------------------------------------------------------
	// CREAMOS LA VENTANA Y MOSTRAMOS EL RESULTADO:
	// --------------------------------------------------------------------------------	
	window = SDL_CreateWindow(
		"Prueba de fuentes PNG",
		SDL_WINDOWPOS_CENTERED,
		SDL_WINDOWPOS_CENTERED,
		256 * 3,
		192 * 3,
		SDL_WINDOW_HIDDEN
	);
	if( window == NULL ) {
		SDL_Log( "Window not initialize! SDL Error: %s\n", SDL_GetError() );
		IMG_Quit(); 
		SDL_Quit();
		return 0;
	}
	#ifdef _RENDER_
	render = SDL_CreateRenderer( window, -1, SDL_RENDERER_ACCELERATED );
	if( render == NULL ) {
		SDL_Log( "Not get window renderer! SDL Error: %s\n", SDL_GetError() );
		SDL_DestroyWindow( window );
		IMG_Quit();
		SDL_Quit();
		return 0;
	}
	SDL_RenderSetLogicalSize( render, 256, 192 );
	#else
	screen = SDL_GetWindowSurface( window );
	if( screen == NULL ) {
		SDL_Log( "Not get window surface! SDL Error: %s\n", SDL_GetError() );
	  	if( render != NULL ) SDL_DestroyRenderer( render );
		SDL_DestroyWindow( window );
		IMG_Quit();
		SDL_Quit();
		return 0;
	}
	#endif
	SDL_ShowWindow( window );
	SDL_ShowCursor( SDL_ENABLE /* SDL_DISABLE  */ );  // Mostrar el cursor gen�rico windows.

	// --------------------------------------------------------------------------------
	// CREAMOS LA FUENTE:
	// --------------------------------------------------------------------------------	
	SDL_Font *font = NULL;
	#ifdef _RENDER_
	font = SDL_NewFont( "./mtr/VeniceClassic-Size19-Char32-255-Solid-N.mtr", SDL_TRUE, render, NULL );
	#else
	font = SDL_NewFont( "./mtr/VeniceClassic-Size19-Char32-255-Solid-N.mtr", SDL_TRUE, render, screen );
	#endif
	if( font == NULL ) { 
		SDL_Log( "Error Font: %s\n", SDL_GetError() );	
		IMG_Quit();
		SDL_Quit();
		return 0; 
	}
 // SDL_ColorKeyFont( font, SDL_TRUE );
	SDL_ColorModFont( font, 0, 0, 0 );
 	// SDL_AlphaModFont( font, 32 );

   SDL_Log( "Ancho %d\n", SDL_WidthFont( font ) );
   SDL_Log( "Alto  %d\n", SDL_HeightFont( font ) );
   SDL_Log( "Ancho de M %d\n", SDL_WidthCharFont( font, 'M' ) );
   SDL_Log( "Ancho de Hola %d\n", SDL_WidthTextFont( font, "Hola" ) );
	
	#ifdef _RENDER_
	SDL_Texture* parche = NULL;
	parche = IMG_LoadTexture( render, "../graphics/parchment1.png" );
	#else
    SDL_Surface* parche = NULL;
	parche = IMG_Load( "../graphics/parchment1.png" );
	#endif
    if( parche == NULL ) {
    	SDL_Log( "Mal asunto: %s\n", SDL_GetError() );
    	
    	return 0;
    }
    

    SDL_Rect rect;
    rect.x = 0;
    rect.y = 0;
    rect.w = 256;
    rect.h = 192;
    
	int x;
	while( continuar ) {
	

	
	#ifdef _RENDER_	
		SDL_SetRenderDrawColor( render, 0, 0, 0, 255 );
		SDL_RenderClear( render );
		// SDL_RenderDrawRect( render, NULL );
		                           // srcrect dstrect
		SDL_RenderCopy(	render, parche, NULL, &rect );
	
		// SDL_CharFontR( font, 'X', render, 128, 96 );
		// SDL_TextFontR( font, "Tweelve crosses", render, 10, 10 );
		
		/*
		SDL_Rect rect1 = { 0, 43 ,256, 43 };   
		SDL_TextRectFontR( font, "Twelve crosses", render, &rect1 );
		SDL_Rect rect2 = { 0, 86, 256, 43 };   
		SDL_TextRectFontR( font, "against the devil", render, &rect2 );
		*/

	SDL_ColorModFont( font, 255, 255, 0 );
		SDL_TextRFontR( font, "Twelve crosses", 10 );

	SDL_ColorModFont( font, 0, 0, 0 );		
		SDL_TextHFontR( font, "Twelve crosses", 59 );
		SDL_TextHFontR( font, "against the devil", 85 );
		
		// SDL_TextFontR( font, "Hola cara culo.����", render, 10, 50 );
	
		// SDL_SetRenderDrawColor( render, 255, 255, 255, 255 );
		// SDL_RenderFillRect( render, &rect );
		// SDL_TextRectFontR( font, "hola", render, &rect );
			
		SDL_RenderPresent( render );
	
	#else
	
		SDL_FillRect( screen, NULL, SDL_MapRGB( screen->format, 0, 0, 0 ) ); 
		SDL_BlitSurface( parche, NULL, screen, NULL );

/*
		SDL_CharFontS( font, '�', screen, 10, 10 );
		SDL_TextFontS( font, "Tweelve crosses", screen, 10, 10 );
*/
	
		SDL_TextHFontS( font, "Twelve crosses", 59 );
		SDL_TextHFontS( font, "against the devil", 85 );

		/*
		SDL_FillRect( screen, &rect, SDL_MapRGB( screen->format, 255, 255, 255 ) ); 
		SDL_TextRectFontS( font, "hola", &rect );

	    x = SDL_TextFontS( font, "Tweelve crosses", 70, 40 );
 		    SDL_TextVFontS( font, "Claro que no.", 200 );
 		*/  
    	SDL_UpdateWindowSurface( window );
    #endif
    	
    	
    	SDL_PollEvent( &event );
		switch( event.type ) {
			case SDL_QUIT: 			continuar = SDL_FALSE; break;
			case SDL_KEYDOWN:
			switch( event.key.keysym.sym ) {
				case SDLK_ESCAPE:	continuar = SDL_FALSE; break;
			}
		}
		SDL_Delay( 100 );

  	}
	// ---------------------------------------------------------------------------		

    
    // ---------------------------------------------------------------------------		
	// CERRAMOS TODO Y SALIMOS:
    // ---------------------------------------------------------------------------		
    SDL_DeleteFont( font );
	if( screen != NULL ) SDL_FreeSurface(     screen );
  	if( render != NULL ) SDL_DestroyRenderer( render );
	SDL_DestroyWindow( window );
	IMG_Quit();
	SDL_Quit();
	return 1;
}



