/*
-------------------------------------------------------------------------------
FORMATO M�TRICA MTR:
--------------------
En este archivo se guarda la informaci�n  del rango de  caracteres,  su  tama�o
m�ximo, el color de la fuente y del fondo, y  por  �ltimo  el  avance  de  cada 
caracter individual.
El  nombre  de  la  imagen PNG  debe ser el mismo que el del archivo MTR, salvo
la extensi�n de formato.
-------------------------------------------------------------------------------
MTR MEASURE FORMAT:
-------------------
In this file information range of characters, its maximum size, font color  and
background, and finally the progress of each  individual  character  is  saved.
PNG name the image must be the same  as  the  MTR  file  except  the  extension 
format.
-------------------------------------------------------------------------------
// FORMAT MTR:
				SDL_RWops *datafile = SDL_RWFromFile( filename_mtr, "r" );
// In initial check of the file:
[0000000000]	( SDL_ReadU8( datafile ) == 'M' )
[0000000001]	( SDL_ReadU8( datafile ) == 'T' )
[0000000002]	( SDL_ReadU8( datafile ) == 'R' )		
-------------------------------------------------------------------------------
// Range of characters:
[0000000003]	Uint8 cMin = SDL_ReadU8( datafile );    // [    0 - cMax ]
[0000000004]	Uint8 cMax = SDL_ReadU8( datafile );    // [ cMin - 255  ]
				int numChr = (cMax - cMin + 1); 
				// Chek ( numChr > 0 ) && ( numChr < 257 )
-------------------------------------------------------------------------------
// Maximum size:
[0000000005]	Uint8 width  = SDL_ReadU8( datafile );
[0000000006]	Uint8 height = SDL_ReadU8( datafile );
-------------------------------------------------------------------------------
// Font color:
[0000000007]	( SDL_ReadU8( datafile ) == 'F' ) // Middel check of the file: 'F' 'B' 'A'
[0000000008]	Uint8 fr = SDL_ReadU8( datafile );
[0000000009]	Uint8 fg = SDL_ReadU8( datafile );
[0000000010]	Uint8 fb = SDL_ReadU8( datafile );
-------------------------------------------------------------------------------
// Background color:
[0000000011]	( SDL_ReadU8( datafile ) ==  'B' ) // Middel check of the file: 'F' 'B' 'A'
[0000000012]	Uint8 br = SDL_ReadU8( datafile );
[0000000013]	Uint8 bg = SDL_ReadU8( datafile );
[0000000014]	Uint8 bb = SDL_ReadU8( datafile );
-------------------------------------------------------------------------------
// Advance:
[0000000015]	( SDL_ReadU8( datafile ) == 'A' )  // Middel check of the file: 'F' 'B' 'A'
				Uint8 advance[ numChr ];
				for( int i = 0; i < font->numChr; ++i ){
[0000000016]		advance[ i ] = SDL_ReadU8( datafile );
				}
-------------------------------------------------------------------------------
// Final check of the file.
[017+numChr]	( SDL_ReadU8( datafile ) == 'E' )
[018+numChr]	( SDL_ReadU8( datafile ) == 'N' )
[019+numChr]	( SDL_ReadU8( datafile ) == 'D' )

-------------------------------------------------------------------------------
*/
#include "SDL_font.h"
// ----------------------------------------------------------------------------
// SDL Font:
// ----------------------------------------------------------------------------
struct _SDL_Font {
	Uint8 cMin;		// char min;
    Uint8 cMax;		// char max;
	int   numChr;	// number of chars.
	Uint8 width;
	Uint8 height;
    Uint8 fr;      // Front color:
    Uint8 fg;
    Uint8 fb;
    Uint8 br;      // Back color:
    Uint8 bg;
    Uint8 bb;
	Uint8 *advance;       // Uint8 advance[ numChr ];
    SDL_Surface  *surface; // PNG
    SDL_Texture  *texture; // PNG
    SDL_Surface  *screen;
    SDL_Renderer *render;
};

void SDL_DeleteFont( SDL_Font* font ) {
	if( font != NULL ) {
		if( font->texture != NULL ) { SDL_DestroyTexture( font->texture ); font->texture = NULL; }
		if( font->surface != NULL ) { SDL_FreeSurface( font->surface );    font->surface = NULL; }
		if( font->advance != NULL ) { SDL_free( font->advance );           font->advance = NULL; }
		SDL_free( font );
		font = NULL;
	}
}

SDL_Font* SDL_LoadMTR( const char* filename ) {
	SDL_bool    b_error = SDL_FALSE;
	SDL_Font*      font = NULL;
	SDL_RWops* datafile = NULL;
	if( filename == NULL ) { 
		SDL_SetError( "Error: No file name.\n" );
		return font;
	}
	// Abrimos el archivo:	
	datafile = SDL_RWFromFile( filename, "r" );
	if( datafile == NULL ) return font;
	// Comprobaci�n inicial:
	if( SDL_ReadU8( datafile ) != 'M' ) b_error = SDL_TRUE;
	if( SDL_ReadU8( datafile ) != 'T' ) b_error = SDL_TRUE;
	if( SDL_ReadU8( datafile ) != 'R' ) b_error = SDL_TRUE;
	if( b_error ) { 
		SDL_SetError( "Error: In initial check of the file.\n" );
		SDL_RWclose( datafile ); 
		return font; 
	}
	// Creamos la estructura:
	font = (SDL_Font*)SDL_malloc( sizeof(SDL_Font) );
	if( font == NULL ) { 
		SDL_SetError( "Error: Out of memory.\n" );
		SDL_RWclose( datafile ); 
		return font; 
	}
	font->surface = NULL;	
	font->texture = NULL;
	font->advance = NULL;
	font->screen  = NULL;
	font->render  = NULL;
	// Rango de char:
	font->cMin    = SDL_ReadU8( datafile );
    font->cMax    = SDL_ReadU8( datafile );
	font->numChr  = ( font->cMax - font->cMin + 1 );
	if( ( font->numChr < 0 ) || ( font->numChr > 256 ) ) {
		SDL_SetError( "Error: Too many characters (%d).\n", font->numChr );
		SDL_DeleteFont( font ); font = NULL;
		SDL_RWclose( datafile ); 
		return font;
	}
	// Medidas:
	font->width   = SDL_ReadU8( datafile );
	font->height  = SDL_ReadU8( datafile );
	// Front color:
	if( SDL_ReadU8( datafile ) != 'F' ) b_error = SDL_TRUE;
    font->fr      = SDL_ReadU8( datafile );
    font->fg      = SDL_ReadU8( datafile );
    font->fb      = SDL_ReadU8( datafile );
    // Back color:
	if( SDL_ReadU8( datafile ) != 'B' ) b_error = SDL_TRUE;
    font->br      = SDL_ReadU8( datafile );
    font->bg      = SDL_ReadU8( datafile );
    font->bb      = SDL_ReadU8( datafile );
	if( SDL_ReadU8( datafile ) != 'A' ) b_error = SDL_TRUE;
	if( b_error ) { 
		SDL_SetError( "Error: In middel check of the file.\n" );
		SDL_DeleteFont( font ); font = NULL;
		SDL_RWclose( datafile ); 
		return font;
	}
    // Avance:
	font->advance  = NULL;
	font->advance = (Uint8*)SDL_malloc( sizeof(Uint8) * font->numChr );
	if( font->advance == NULL ) { 
		SDL_SetError( "Error: Out of memory.\n" );
		SDL_DeleteFont( font ); font = NULL;
		SDL_RWclose( datafile ); 
		return font;
	}
	int i;
	for( i = 0; i < font->numChr; ++i ){
		font->advance[ i ] = SDL_ReadU8( datafile );
		// SDL_LOG( "%d %x\n", i + font->cMin, font->advance[ i ] );
	}
	// Comprobaci�n final:
	if( SDL_ReadU8( datafile ) != 'E' ) b_error = SDL_TRUE;
	if( SDL_ReadU8( datafile ) != 'N' ) b_error = SDL_TRUE;
	if( SDL_ReadU8( datafile ) != 'D' ) b_error = SDL_TRUE;
	if( b_error ) { 
		SDL_SetError( "Error: In final check of the file.\n" );
		SDL_DeleteFont( font ); font = NULL;
	}
	SDL_RWclose( datafile );
	return font;
}

SDL_Font* SDL_NewFont( const char* filename, SDL_bool colorkey, SDL_Renderer *render, SDL_Surface *surface ) {
	SDL_Font* font = NULL;
	if( ( render == NULL ) && ( surface == NULL ) ) {
		SDL_SetError( "Error: No SDL_Renderer* no SDL_Surface*.\n" );
		return font;
	}
	if( ( render != NULL ) && ( surface != NULL ) ) {
		SDL_SetError( "Error: ( SDL_Renderer* | SDL_Surface* ) Selects only one of the two, the other must be a NULL pointer.\n" );
		return font;
	}
	// Cargamos los datos MTR:
	font = SDL_LoadMTR( filename );
	if( font == NULL ) return font;
	font->screen = surface;
	font->render = render;
	// Cargamos la imagen PNG:
	char nombre_imagen_png[255];
	SDL_strlcpy( nombre_imagen_png, filename, 255 );
	nombre_imagen_png[ SDL_strlen( nombre_imagen_png ) - 4 ] = 0;
	SDL_strlcat( nombre_imagen_png, ".png", 255 );
	// Render tiene prioridad:
	if( font->render != NULL ) {
		if(	colorkey ) {
			font->surface = IMG_Load( nombre_imagen_png );
			if( font->surface == NULL ) { 
				SDL_DeleteFont( font ); font = NULL;
				return font; 
			}
			SDL_SetSurfaceBlendMode( font->surface, SDL_BLENDMODE_NONE );
			SDL_SetColorKey( font->surface, SDL_TRUE, SDL_MapRGB( font->surface->format, font->br, font->bg, font->bb ) );	
			font->texture = SDL_CreateTextureFromSurface( font->render, font->surface );
			SDL_FreeSurface( font->surface );
			font->surface = NULL;
		} else {
			font->texture = IMG_LoadTexture( font->render, nombre_imagen_png );
		}
		if( font->texture == NULL ) {
			SDL_DeleteFont( font ); font = NULL;
			return font;
		}
		SDL_SetRenderDrawBlendMode( font->render, SDL_BLENDMODE_NONE );
		return font;
	} 

	if( font->screen != NULL ) {
		font->surface = IMG_Load( nombre_imagen_png );
		if( font->surface == NULL ) { 
			SDL_DeleteFont( font ); font = NULL;
			return font; 
		}
		SDL_SetSurfaceBlendMode( font->surface, SDL_BLENDMODE_NONE );
		if(	colorkey ) SDL_SetColorKey( font->surface, SDL_TRUE, SDL_MapRGB( font->surface->format, font->br, font->bg, font->bb ) );
	}
	return font;
}

int SDL_WidthFont(  SDL_Font* font ) { return font->width; }
int SDL_HeightFont( SDL_Font* font ) { return font->height; }
int SDL_WidthCharFont( SDL_Font* font, Uint8 letter ) {
	if     ( letter < font->cMin ) return 0;
	else if( letter > font->cMax ) return 0;
	letter -= font->cMin;
	return font->advance[ letter ];
}
int SDL_WidthTextFont( SDL_Font* font, const char* text ) {
	int width = 0;
	size_t i = 0;
	size_t len = SDL_strlen( text );
	for( i = 0; i < len; ++i ) {
		width += SDL_WidthCharFont( font, text[ i ] );
	}
	return width;
}

void SDL_ColorModFont( SDL_Font* font, Uint8 r, Uint8 g, Uint8 b ) {
	if( font == NULL ) return;
	if( font->surface != NULL ) SDL_SetSurfaceColorMod( font->surface, r, g, b );
	if( font->texture != NULL ) SDL_SetTextureColorMod( font->texture, r, g, b );
}

void SDL_AlphaModFont( SDL_Font* font, Uint8 alpha ) {
	if( font == NULL ) return;
	if( font->surface != NULL ) {
		if( alpha == 255 ) SDL_SetSurfaceBlendMode( font->surface, SDL_BLENDMODE_NONE  );
		else               SDL_SetSurfaceBlendMode( font->surface, SDL_BLENDMODE_BLEND );
		SDL_SetSurfaceAlphaMod( font->surface, alpha );
	}
	if( font->texture != NULL ) {
		if( alpha == 255 ) SDL_SetTextureBlendMode( font->texture, SDL_BLENDMODE_NONE  );
		else               SDL_SetTextureBlendMode( font->texture, SDL_BLENDMODE_BLEND );
		SDL_SetTextureAlphaMod( font->texture, alpha );
	}
}

void SDL_ColorKeyFont( SDL_Font* font, SDL_bool b ) {
	if( font == NULL ) return;
	if( font->surface != NULL ) {
		SDL_SetColorKey( font->surface, b, SDL_MapRGB( font->surface->format, font->br, font->bg, font->bb ) );	
	}
	if( font->texture != NULL ) {
		// ? ? ?
	}
}
// ----------------------------------------------------------------------------
void SDL_SetRender( SDL_Font* font, SDL_Renderer *render ) {
	font->render = render;
}
int SDL_CharFontR( SDL_Font* font, Uint8 letter, int x, int y ) {
	if     ( letter < font->cMin ) return x;
	else if( letter > font->cMax ) return x;
    SDL_Rect origen;
    letter -= font->cMin;
	origen.x = font->width * ( letter % 16 ); 
    origen.y = font->height  * ( letter / 16 );
    origen.w = font->width; 
	origen.h = font->height;
    SDL_Rect destino;
    destino.x = x;        destino.y = y;
    destino.w = origen.w; destino.h = origen.h;
	SDL_RenderCopy(	font->render, font->texture, &origen, &destino );
	return x + font->advance[ letter ];
}
int SDL_TextFontR( SDL_Font* font, const char* text, int x, int y ) {
	size_t i = 0;
	size_t len = SDL_strlen( text );
	for( i = 0; i < len; ++i ) {
		x = SDL_CharFontR(  font, text[ i ], x, y );
	}
	return x;
}
int SDL_TextRFontR( SDL_Font* font, const char* text, int y ) {
	int w; //, h;
	// SDL_RenderGetLogicalSize( font->render, &w, &h );
	SDL_Rect    rect;
	SDL_RenderGetViewport( font->render, &rect );
	w = rect.w;
	// h = rect.h;
	int x = SDL_WidthTextFont( font, text );
	x = w - x;
	size_t i = 0;
	size_t len = SDL_strlen( text );
	for( i = 0; i < len; ++i ) {
		x = SDL_CharFontR(  font, text[ i ], x, y );
	}
	return x;
}
int SDL_TextHFontR( SDL_Font* font, const char* text, int y ) {
	int w; //, h;
	// SDL_RenderGetLogicalSize( font->render, &w, &h );
	SDL_Rect    rect;
	SDL_RenderGetViewport( font->render, &rect );
	w = rect.w;
	// h = rect.h;
	int x = SDL_WidthTextFont( font, text );
	x = ( w - x ) >> 1;
	size_t i = 0;
	size_t len = SDL_strlen( text );
	for( i = 0; i < len; ++i ) {
		x = SDL_CharFontR(  font, text[ i ], x, y );
	}
	return x;
}
int SDL_TextVFontR( SDL_Font* font, const char* text, int x ) {
	int h; // ,w;
	// SDL_RenderGetLogicalSize( font->render, &w, &h );
	SDL_Rect    rect;
	SDL_RenderGetViewport( font->render, &rect );
	// w = rect.w;
	h = rect.h;
	int y = font->height;
	y = ( h - y ) >> 1;
	size_t i = 0;
	size_t len = SDL_strlen( text );
	for( i = 0; i < len; ++i ) {
		x = SDL_CharFontR( font, text[ i ], x, y );
	}
	return x;
}
int SDL_TextHVFontR( SDL_Font* font, const char* text ) {
	int w, h;
	// SDL_RenderGetLogicalSize( font->render, &w, &h );
	SDL_Rect    rect;
	SDL_RenderGetViewport( font->render, &rect );
	w = rect.w;
	h = rect.h;
	int x = SDL_WidthTextFont( font, text );
	x = ( w - x ) >> 1;
	int y = font->height;
	y = ( h - y ) >> 1;
	size_t i = 0;
	size_t len = SDL_strlen( text );
	for( i = 0; i < len; ++i ) {
		x = SDL_CharFontR( font, text[ i ], x, y );
	}
	return x;
}
int SDL_TextRectFontR( SDL_Font* font, const char* text, SDL_Rect *rect ) {
	SDL_Rect clip;
	SDL_RenderGetClipRect( font->render, &clip );
	SDL_RenderSetClipRect( font->render, rect );
	int x = SDL_WidthTextFont( font, text );
	int y = font->height;
	x = ( ( rect->w - x ) >> 1 ) + rect->x;
	y = ( ( rect->h - y ) >> 1 ) + rect->y;
	size_t i = 0;
	size_t len = SDL_strlen( text );
	for( i = 0; i < len; ++i ) {
		x = SDL_CharFontR( font, text[ i ], x, y );
	}
	SDL_RenderSetClipRect( font->render, &clip );
	return x;
}
// ----------------------------------------------------------------------------
/*
void SDL_SetSurface( SDL_Font* font, SDL_Surface *surface ) {
	font->screen = surface;
}
int SDL_CharFontS( SDL_Font* font, Uint8 letter, int x, int y ) {
	if     ( letter < font->cMin ) return x;
	else if( letter > font->cMax ) return x;
    SDL_Rect origen;
    letter -= font->cMin;
	origen.x = font->width * ( letter % 16 ); 
    origen.y = font->height * ( letter / 16 );
    origen.w = font->width; 
	origen.h = font->height;
    SDL_Rect destino;
    destino.x = x;        destino.y = y;
    destino.w = origen.w; destino.h = origen.h;
	SDL_BlitSurface( font->surface, &origen, font->screen, &destino );
	return x + font->advance[ letter ];
}
int SDL_TextFontS( SDL_Font* font, const char* text, int x, int y ) {
	size_t i = 0;
	size_t len = SDL_strlen( text );
	for( i = 0; i < len; ++i ) {
		x = SDL_CharFontS(  font, text[ i ], x, y );
	}
	return x;
}
int SDL_TextRFontS( SDL_Font* font, const char* text, int y ) {
	int x = SDL_WidthTextFont( font, text );
	x = font->screen->w - x;
	size_t i = 0;
	size_t len = SDL_strlen( text );
	for( i = 0; i < len; ++i ) {
		x = SDL_CharFontS(  font, text[ i ], x, y );
	}
	return x;
}
int SDL_TextHFontS( SDL_Font* font, const char* text, int y ) {
	int x = SDL_WidthTextFont( font, text );
	x = ( font->screen->w - x ) >> 1;
	size_t i = 0;
	size_t len = SDL_strlen( text );
	for( i = 0; i < len; ++i ) {
		x = SDL_CharFontS(  font, text[ i ], x, y );
	}
	return x;
}
int SDL_TextVFontS( SDL_Font* font, const char* text, int x ) {
	int y = font->height;
	y = ( font->screen->h - y ) >> 1;
	size_t i = 0;
	size_t len = SDL_strlen( text );
	for( i = 0; i < len; ++i ) {
		x = SDL_CharFontS( font, text[ i ], x, y );
	}
	return x;
}
int SDL_TextHVFontS( SDL_Font* font, const char* text ) {
	int x = SDL_WidthTextFont( font, text );
	x = ( font->screen->w - x ) >> 1;
	int y = font->height;
	y = ( font->screen->h - y ) >> 1;
	size_t i = 0;
	size_t len = SDL_strlen( text );
	for( i = 0; i < len; ++i ) {
		x = SDL_CharFontS( font, text[ i ], x, y );
	}
	return x;
}
int SDL_TextRectFontS( SDL_Font* font, const char* text, SDL_Rect *rect ) {
	SDL_Rect clip;
	SDL_GetClipRect( font->screen, &clip );
	SDL_SetClipRect( font->screen, rect );
	int x = SDL_WidthTextFont( font, text );
	int y = font->height;
	x = ( ( rect->w - x ) >> 1 ) + rect->x;
	y = ( ( rect->h - y ) >> 1 ) + rect->y;
	size_t i = 0;
	size_t len = SDL_strlen( text );
	for( i = 0; i < len; ++i ) {
		x = SDL_CharFontS( font, text[ i ], x, y );
	}
	SDL_SetClipRect( font->screen, &clip );
	return x;
}
*/
// ----------------------------------------------------------------------------

/*
int SDL_BlitScaled(SDL_Surface*    src,
                   const SDL_Rect* srcrect,
                   SDL_Surface*    dst,
                   SDL_Rect*       dstrect)
*/

