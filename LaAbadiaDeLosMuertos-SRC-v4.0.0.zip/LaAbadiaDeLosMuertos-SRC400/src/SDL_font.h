/*
-------------------------------------------------------------------------------
FORMATO M�TRICA MTR:
--------------------
En este archivo se guarda la informaci�n  del rango de  caracteres,  su  tama�o
m�ximo, el color de la fuente y del fondo, y  por  �ltimo  el  avance  de  cada 
caracter individual.
El  nombre  de  la  imagen PNG  debe ser el mismo que el del archivo MTR, salvo
la extensi�n de formato.
-------------------------------------------------------------------------------
MTR MEASURE FORMAT:
-------------------
In this file information range of characters, its maximum size, font color  and
background, and finally the progress of each  individual  character  is  saved.
PNG name the image must be the same  as  the  MTR  file  except  the  extension 
format.
-------------------------------------------------------------------------------
*/
#ifndef _SDL_FONT_
#define _SDL_FONT_

#ifdef _PORT_ANDROID_
#include "SDL.h"
#include "SDL_image.h"
#include "SDL_mixer.h"
#else
#include "SDL2/SDL.h"
#include "SDL2/SDL_image.h"
#include "SDL2/SDL_mixer.h"
#endif

// ----------------------------------------------------------------------------
// SDL Font:
// ----------------------------------------------------------------------------
typedef struct _SDL_Font SDL_Font;

// Destroy a font structure.
void  SDL_DeleteFont( SDL_Font* font ); 

// Creates a new font structure:
SDL_Font* SDL_NewFont(      
	const char*   filename, // MTR file name extension "./path/filename.mtr".
	SDL_bool      colorkey, // SDL_TRUE for transparent background color. (No alpha PNG)
	SDL_Renderer* render,   // ( SDL_Renderer* | SDL_Surface* )  Selects  only 
	SDL_Surface*  surface   // one of the two, the other must be a NULL pointer.
); // Comment: If the image has a transparent PNG alpha channel and background, 
   //          will always have a transparent background.

// Return functions:
int      SDL_WidthFont( SDL_Font* font );
int     SDL_HeightFont( SDL_Font* font );
int  SDL_WidthCharFont( SDL_Font* font, Uint8 letter );
int  SDL_WidthTextFont( SDL_Font* font, const char* text );

// Use this function to set an additional color value multiplied into blit surface operations or texture. 
void  SDL_ColorModFont( // Change the text color, but only works well if 
	SDL_Font* font, 	// the text color  is white  in the image PNG.
	Uint8 r, 			// Red   component.
	Uint8 g, 			// Green component.
	Uint8 b 			// Blue  component.
);

// Use this function to set an additional alpha value used in blit surface operations or texture.
void SDL_AlphaModFont(
	SDL_Font* font, 	// If alpha is 255 off transparency.
	Uint8     alpha		// If alpha is not 255 active transparency.
);

// Use this function to set the color key (transparent pixel) in a surface.
void SDL_ColorKeyFont(	// SDL_TRUE for transparent background color.
	SDL_Font* font,		// SDL_FALSE for opaque background color.
	SDL_bool  b			// The change only works with SDL_Surface.
);
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// SDL Render Font: If you chose to SDL_Renderer in SDL_NewFont.
// ----------------------------------------------------------------------------
void    SDL_SetRender( SDL_Font* font, SDL_Renderer *render ); 			 // Using exceptionally.
int     SDL_CharFontR( SDL_Font* font, Uint8     letter, int x, int y ); // Write a letter.
int     SDL_TextFontR( SDL_Font* font, const char* text, int x, int y ); // Write a text.
int    SDL_TextRFontR( SDL_Font* font, const char* text, int y );	// Centered Right.
int    SDL_TextHFontR( SDL_Font* font, const char* text, int y );	// Centered Horizontally.
int    SDL_TextVFontR( SDL_Font* font, const char* text, int x );	// Centered Hertically.
int   SDL_TextHVFontR( SDL_Font* font, const char* text  ); 		// Horizontal and Vertical centering.
int SDL_TextRectFontR( SDL_Font* font, const char* text, SDL_Rect *rect ); // Centered within a rectangle.
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// SDL Surface Font: If you chose to SDL_Surface in SDL_NewFont.
// ----------------------------------------------------------------------------
/*
void    SDL_SetSurface( SDL_Font* font, SDL_Surface *surface ); // Using exceptionally.
int      SDL_CharFontS( SDL_Font* font, Uint8 letter, int x, int y );
int      SDL_TextFontS( SDL_Font* font, const char* text, int x, int y );
int     SDL_TextRFontS( SDL_Font* font, const char* text, int y );
int     SDL_TextHFontS( SDL_Font* font, const char* text, int y );
int     SDL_TextVFontS( SDL_Font* font, const char* text, int x );
int    SDL_TextHVFontS( SDL_Font* font, const char* text );
int  SDL_TextRectFontS( SDL_Font* font, const char* text, SDL_Rect *rect );
*/
// ----------------------------------------------------------------------------

#endif

