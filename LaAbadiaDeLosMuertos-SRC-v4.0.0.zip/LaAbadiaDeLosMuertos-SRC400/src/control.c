/* control.c */
#include "control.h"

void updatetouch() {
	if( touch.zoom < 0.5f ) touch.zoom = 0.5f;
	if( touch.zoom > 2.0f ) touch.zoom = 2.0f;
	if( touch.alpha < 32  ) touch.alpha = 32;
	if( touch.alpha > 255 ) touch.alpha = 32;
	float aspectw, aspecti;
	if( win_w > win_h ) {
		aspectw = (float)win_w / win_h;
		aspecti = (float)win_wi / win_hi;
		touch.zoomx = touch.zoom * aspecti / aspectw;
		touch.zoomy = touch.zoom;
	} else {
		aspectw = (float)win_h / win_w;
		aspecti = (float)win_hi / win_wi;
		touch.zoomx = touch.zoom;
		touch.zoomy = touch.zoom * aspecti / aspectw;
	}
	touch.y1 = 0.833f - (0.125f * touch.zoomy) + 0.125f;
	touch.y2 = 0.125f  * touch.zoomy;
	touch.x1 = 0.125f * touch.zoomx;
	touch.x2 = 0.25f  * touch.zoomx;
	touch.x3 = 0.741f - ( 0.25f * touch.zoomx ) + 0.25f; 
	touch.x4 = touch.x3 + ( 0.125f * touch.zoomx );
	touch.yi = 160 - (32 * touch.zoomy) + 32;
	touch.xi = 192 - ( 64 * touch.zoomx ) + 64;
	touch.wi = 64 * touch.zoomx;
	touch.hi = 32 * touch.zoomy;
//	touch.id =  SDL_TOUCH_MOUSEID;
}

int gamecontrol() {
	int key = 0;
	SDL_Event event;
	while( SDL_PollEvent( &event ) ) {
		switch( event.type ) {
			case SDL_JOYDEVICEADDED:
				if( joystick == NULL ) joystick = SDL_JoystickOpen( event.jdevice.which );
			break;
			case SDL_JOYDEVICEREMOVED:
				if( joystick == SDL_JoystickFromInstanceID( event.jdevice.which ) ) {
					SDL_JoystickClose( joystick ); 
					joystick = NULL;
				}
			break;
			case SDL_CONTROLLERDEVICEADDED:
				if( gamecontroller == NULL ) gamecontroller = SDL_GameControllerOpen( event.cdevice.which );
			break;
			case SDL_CONTROLLERDEVICEREMOVED:
				if( gamecontroller == SDL_GameControllerFromInstanceID( event.cdevice.which ) ) {
					SDL_GameControllerClose( gamecontroller );
					gamecontroller = NULL;
				}
			break;			
			// case SDL_FINGERUP:
			case SDL_FINGERMOTION:
			case SDL_FINGERDOWN:
				if( touch.id == 0 ) {
					if ( SDL_GetNumTouchDevices() > 0 ) touch.id = SDL_GetTouchDevice( 0 );
					updatetouch();
				}
			break;
			case SDL_APP_WILLENTERBACKGROUND:
			case SDL_APP_DIDENTERBACKGROUND:
				pause = SDL_TRUE; 
			break;
			case SDL_APP_WILLENTERFOREGROUND:
			case SDL_APP_DIDENTERFOREGROUND:
				pause = SDL_FALSE;
			break;
			case SDL_APP_TERMINATING:
			case SDL_QUIT:
				key   = _QUIT_;
				pause = SDL_FALSE;
			break;
			case SDL_WINDOWEVENT:
				if( event.window.event == SDL_WINDOWEVENT_RESIZED ) {
					win_w = event.window.data1; 
					win_h = event.window.data2;
					setLogicalSize( win_wi, win_hi );
					updatetouch();
				}
				if( event.window.event == SDL_WINDOWEVENT_MAXIMIZED ) {
					setfullscreen();
				}
			    if( event.window.event == SDL_WINDOWEVENT_MINIMIZED ) {
			    	pause = SDL_TRUE; 
				}
        		if( event.window.event == SDL_WINDOWEVENT_RESTORED ) {
        			pause = SDL_FALSE;	// SDL_RestoreWindow( screen );
				}
			break;
			case SDL_KEYDOWN:
				switch( event.key.keysym.sym ) {
					/*
		    		case SDLK_AC_SEARCH: 		break;
					case SDLK_AC_HOME: 			break;
					case SDLK_AC_FORWARD: 		break;
					case SDLK_AC_STOP: 			break;
					case SDLK_AC_REFRESH: 		break;
					case SDLK_AC_BOOKMARKS: 	break;
					*/
					case SDLK_AC_BACK:  key |= _ESCAPE_; 	break;
					case SDLK_ESCAPE:	key |= _ESCAPE_; 	break;
				#ifndef _PORT_ANDROID_
					case SDLK_F1:		key |= _F1_;		break;
					case SDLK_F2:		key |= _F2_;		break;
					case SDLK_F3:		key |= _F3_;		break;
					case SDLK_F4:		key |= _F4_;		break;
					case SDLK_l:
						if( language == _SPANISH_ ) language  = _ENGLISH_;
						else						language  = _SPANISH_;
						SDL_Delay( 100 );
					break;
					case SDLK_m:
						if( bmusic == SDL_TRUE ) { bmusic = SDL_FALSE; Mix_HaltMusic(); }
						else					 { bmusic = SDL_TRUE; Mix_PlayChannel( -1, fx[2], 0 ); }
						SDL_Delay( 200 );
					break;
					case SDLK_g:
						++systemgraph;
						if( systemgraph > _MSX2_ ) systemgraph = _ZXSPEC_;
						SDL_DestroyTexture( tiles );
						SDL_Delay( 100 );
						tiles = IMG_LoadTexture( renderer, filespng[ systemgraph ] );
						SDL_Delay( 100 );
					break;
					case SDLK_F11:
					case SDLK_f:
						setfullscreen();
						SDL_Delay( 100 );
					break;
					case SDLK_PAUSE:
					case SDLK_p:
						if( pause ) pause = SDL_FALSE;
						else        pause = SDL_TRUE;
						SDL_Delay( 200 );	
					break;
				#endif
				}
			break;
		}
	}

	// ----------------------------------------------------------------
	// TOUCH:
	// ----------------------------------------------------------------
	if( touch.id != 0 ) {
		int d = SDL_GetNumTouchDevices();
		for( d = 0; d < SDL_GetNumTouchDevices(); d++ ) {
		touch.id = SDL_GetTouchDevice( d );
		int i;
		for( i = 0; i < SDL_GetNumTouchFingers( touch.id ); i++ ) {
			SDL_Finger* finger = SDL_GetTouchFinger( touch.id, i );
			if( finger != NULL ) {
				if( finger->y > touch.y1 ) {
					if( finger->x < touch.x1 ) 					       key |= _LEFT_;
					if( finger->x > touch.x1 && finger->x < touch.x2 ) key |= _RIGHT_;
					if( finger->x > touch.x3 && finger->x < touch.x4 ) key |= _DOWN_;
					if( finger->x > touch.x4 ) 					       key |= _UP_;
				}
				if( finger->y < touch.y2 ) {
					if( finger->x < touch.x2  ) {
						++systemgraph;
						if( systemgraph > _MSX2_ ) systemgraph = _ZXSPEC_;
						SDL_DestroyTexture( tiles );
						tiles = IMG_LoadTexture( renderer, filespng[ systemgraph ] );
					} else if( finger->x > touch.x3 ) {
						touch.id = 0;
					} else {
						if( pause ) pause = SDL_FALSE;
						else        pause = SDL_TRUE;
					}
					SDL_Delay( 100 );
				}
			}
		}
		}
	}
	// ----------------------------------------------------------------
	// JOYSTICK:
	// ----------------------------------------------------------------
	if( gamecontroller != NULL ) {
		if( SDL_GameControllerGetButton( gamecontroller, SDL_CONTROLLER_BUTTON_A ) > 0 ) key |= _UP_;
		if( SDL_GameControllerGetButton( gamecontroller, SDL_CONTROLLER_BUTTON_B ) > 0 ) key |= _UP_;
		if     ( SDL_GameControllerGetButton( gamecontroller, SDL_CONTROLLER_BUTTON_DPAD_UP    ) > 0 ) key |= _UP_;
		else if( SDL_GameControllerGetButton( gamecontroller, SDL_CONTROLLER_BUTTON_DPAD_DOWN  ) > 0 ) key |= _DOWN_;
		else key |= _V_CENTERED_;
		if     ( SDL_GameControllerGetButton( gamecontroller, SDL_CONTROLLER_BUTTON_DPAD_LEFT  ) > 0 ) key |= _LEFT_;
		else if( SDL_GameControllerGetButton( gamecontroller, SDL_CONTROLLER_BUTTON_DPAD_RIGHT ) > 0 ) key |= _RIGHT_;
		else key |= _H_CENTERED_;
		Sint16 axisvalue = SDL_GameControllerGetAxis( gamecontroller, SDL_CONTROLLER_AXIS_LEFTX );
		if(      axisvalue * flipx >  axisr  ) key |= _RIGHT_;
		else if( axisvalue * flipx < -axisr  ) key |= _LEFT_;
		else						           key |= _H_CENTERED_;
		axisvalue = SDL_GameControllerGetAxis( gamecontroller, SDL_CONTROLLER_AXIS_LEFTY );
		if(      flipy * axisvalue >  axisr  ) key |= _DOWN_;
		else if( flipy * axisvalue < -axisr  ) key |= _V_CENTERED_; // _UP_;
		else						           key |= _V_CENTERED_;
	} 
	else if( joystick != NULL ) {
		Uint8 hatvalue = SDL_JoystickGetHat( joystick, 0 );
		switch( hatvalue ) {
			case SDL_HAT_UP:
			case SDL_HAT_CENTERED:	key |= _H_CENTERED_;	
									key |= _V_CENTERED_;	break;				
			case SDL_HAT_RIGHT:
			case SDL_HAT_RIGHTUP:	key |= _RIGHT_;			break;
			case SDL_HAT_LEFT:
			case SDL_HAT_LEFTUP:	key |= _LEFT_;			break;
			case SDL_HAT_DOWN: 		key |= _DOWN_; 			break;
			case SDL_HAT_RIGHTDOWN: key |= _RIGHTDOWN_; 	break;
			case SDL_HAT_LEFTDOWN: 	key |= _LEFTDOWN_; 		break;
		}
	
		Sint16 axisvalue = SDL_JoystickGetAxis( joystick, axisx );
		if(      axisvalue * flipx >  axisr  ) key |= _RIGHT_;
		else if( axisvalue * flipx < -axisr  ) key |= _LEFT_;
		else						           key |= _H_CENTERED_;

		axisvalue = SDL_JoystickGetAxis( joystick, axisy );
		if(      flipy * axisvalue >  axisr  ) key |= _DOWN_;
		else if( flipy * axisvalue < -axisr  ) key |= _V_CENTERED_; // _UP_;
		else						           key |= _V_CENTERED_;

		if( SDL_JoystickGetButton( joystick, 0 ) > 0 ) key |= _UP_;
		if( SDL_JoystickGetButton( joystick, 1 ) > 0 ) key |= _UP_;
		if( SDL_JoystickGetButton( joystick, 2 ) > 0 ) key |= _UP_;

	}

	const Uint8 *keystate = SDL_GetKeyboardState(NULL);
	if(      keystate[SDL_SCANCODE_RIGHT] ) key |= _RIGHT_;
	else if( keystate[SDL_SCANCODE_D]     ) key |= _RIGHT_;
	else if( keystate[SDL_SCANCODE_LEFT]  ) key |= _LEFT_;
	else if( keystate[SDL_SCANCODE_A]     ) key |= _LEFT_;
	else						        	key |= _H_CENTERED_;

	if(      keystate[SDL_SCANCODE_DOWN]  ) key |= _DOWN_;
	else if( keystate[SDL_SCANCODE_S]     ) key |= _DOWN_;
	else if( keystate[SDL_SCANCODE_UP]    ) key |= _UP_;
	else if( keystate[SDL_SCANCODE_SPACE] ) key |= _UP_;
	else if( keystate[SDL_SCANCODE_W]     ) key |= _UP_;
	else						         	key |= _V_CENTERED_;
	
	return key;
}

int commoncontrol() {
	
	int key = 0;
	SDL_Event event;
	while( SDL_PollEvent( &event ) ) {
	switch( event.type ) {
	// ----------------------------------------------------------------
	// TOUCH:
	// ----------------------------------------------------------------
		// case SDL_FINGERUP:
		case SDL_FINGERMOTION:
			if( touch.id == 0 ) {
				if ( SDL_GetNumTouchDevices() > 0 ) touch.id = SDL_GetTouchDevice( 0 );
				updatetouch();
			}
		break;
		case SDL_FINGERDOWN:
			if( touch.id == 0 ) {
				if ( SDL_GetNumTouchDevices() > 0 ) touch.id = SDL_GetTouchDevice( 0 );
				updatetouch();
			}
			if( event.tfinger.y > touch.y1 ) {
				if( event.tfinger.x < touch.x1 ) {
					if( language == _SPANISH_ ) language  = _ENGLISH_;
					else						language  = _SPANISH_;
				}
				if( event.tfinger.x > touch.x1 && event.tfinger.x < touch.x2 ) key |= _INFO_;
				if( event.tfinger.x > touch.x3 && event.tfinger.x < touch.x4 ) key |= _DOWN_;
				if( event.tfinger.x > touch.x4 ) key |= _UP_;	
				SDL_Delay( 200 );
			}
			if( event.tfinger.y < touch.y2 ) {
				if( event.tfinger.x < touch.x2  ) {
					++systemgraph;
					if( systemgraph > _MSX2_ ) systemgraph = _ZXSPEC_;
					SDL_DestroyTexture( tiles );
					tiles = IMG_LoadTexture( renderer, filespng[ systemgraph ] );
				} else if( event.tfinger.x > touch.x3  ) {
						touch.id = 0; 
				} else {
					if( pause ) pause = SDL_FALSE;
					else        pause = SDL_TRUE;
				}
				SDL_Delay( 200 );
			}
		break;
	// ----------------------------------------------------------------
	// JOYSTICK:
	// ----------------------------------------------------------------
		case SDL_CONTROLLERDEVICEADDED:
			if( gamecontroller == NULL ) gamecontroller = SDL_GameControllerOpen( event.cdevice.which );
		break;
		case SDL_CONTROLLERDEVICEREMOVED:
			if( gamecontroller == SDL_GameControllerFromInstanceID( event.cdevice.which ) ) {
				SDL_GameControllerClose( gamecontroller );
				gamecontroller = NULL;
			}
		break;
		case SDL_CONTROLLERAXISMOTION:
			if( event.caxis.axis == SDL_CONTROLLER_AXIS_LEFTX ) {
				if(      event.caxis.value >  axisr ) key |= _RIGHT_;
				else if( event.caxis.value < -axisr ) key |= _LEFT_;
				else								  key |= _H_CENTERED_;
			}
			if( event.caxis.axis == SDL_CONTROLLER_AXIS_LEFTY ) {
				if(      event.caxis.value >  axisr ) key |= _DOWN_;
				else if( event.caxis.value < -axisr ) key |= _V_CENTERED_; // _UP_;
				else								  key |= _V_CENTERED_;
			}
		break;
		case SDL_CONTROLLERBUTTONDOWN:
			if( event.cbutton.button == SDL_CONTROLLER_BUTTON_A ) key |= _UP_;
			if( event.cbutton.button == SDL_CONTROLLER_BUTTON_B ) key |= _UP_;
			if     ( event.cbutton.button == SDL_CONTROLLER_BUTTON_DPAD_UP    ) key |= _UP_;
			else if( event.cbutton.button == SDL_CONTROLLER_BUTTON_DPAD_DOWN  ) key |= _DOWN_;
			else 																key |= _V_CENTERED_;
			if     ( event.cbutton.button == SDL_CONTROLLER_BUTTON_DPAD_LEFT  ) key |= _LEFT_;
			else if( event.cbutton.button == SDL_CONTROLLER_BUTTON_DPAD_RIGHT ) key |= _RIGHT_;
			else 																key |= _H_CENTERED_;
		break;
		case SDL_JOYDEVICEADDED:
			if( joystick == NULL ) joystick = SDL_JoystickOpen( event.jdevice.which );
		break;
		case SDL_JOYDEVICEREMOVED:
			if( joystick == SDL_JoystickFromInstanceID( event.jdevice.which ) ) {
				SDL_JoystickClose( joystick ); 
				joystick = NULL;
			}
		break;
		case SDL_JOYHATMOTION:
			if( gamecontroller ) break;
			switch( event.jhat.value ) {
			case SDL_HAT_UP:
			case SDL_HAT_CENTERED:	key |= _H_CENTERED_;
									key |= _V_CENTERED_;	break;					
			case SDL_HAT_RIGHT:
			case SDL_HAT_RIGHTUP:	key |= _RIGHT_;			break;
			case SDL_HAT_LEFT:
			case SDL_HAT_LEFTUP:	key |= _LEFT_;			break;
			case SDL_HAT_DOWN:		key |= _DOWN_;			break;
			case SDL_HAT_RIGHTDOWN:	key |= _RIGHTDOWN_;		break;
			case SDL_HAT_LEFTDOWN:	key |= _LEFTDOWN_;		break;
			}
		break;
		case SDL_JOYAXISMOTION:
			if( gamecontroller ) break;
			if( event.jaxis.axis == axisx ) {
				if(      event.jaxis.value >  axisr ) key |= _RIGHT_;
				else if( event.jaxis.value < -axisr ) key |= _LEFT_;
				else								  key |= _H_CENTERED_;
			}
			if( event.jaxis.axis == axisy ) {
				if(      event.jaxis.value >  axisr ) key |= _DOWN_;
				else if( event.jaxis.value < -axisr ) key |= _V_CENTERED_; // _UP_;
				else								  key |= _V_CENTERED_;
			}
		break;
		case SDL_JOYBUTTONDOWN:
			if( gamecontroller ) break;
			switch( event.jbutton.button ) {
			case 0:
			case 1:
			case 2:
				key |= _UP_;							
			break;
			}
		break;
		// ----------------------------------------------------------------
		// OPCIONES:
		// ----------------------------------------------------------------
		case SDL_APP_WILLENTERBACKGROUND:
		case SDL_APP_DIDENTERBACKGROUND:	
			pause = SDL_TRUE;
		break;
		case SDL_APP_WILLENTERFOREGROUND:
		case SDL_APP_DIDENTERFOREGROUND:
			pause = SDL_FALSE;
		break;
		case SDL_QUIT:
		case SDL_APP_TERMINATING:
			key   = _QUIT_;
			pause = SDL_FALSE;
		break;
		case SDL_WINDOWEVENT:
			if( event.window.event == SDL_WINDOWEVENT_RESIZED ) {
				win_w = event.window.data1; 
				win_h = event.window.data2;
				setLogicalSize( win_wi, win_hi );
				updatetouch();
			}
			if( event.window.event == SDL_WINDOWEVENT_MAXIMIZED ) {
				setfullscreen();
			}
			if( event.window.event == SDL_WINDOWEVENT_MINIMIZED ) {
			    pause = SDL_TRUE;      
			}
        	if( event.window.event == SDL_WINDOWEVENT_RESTORED ) {
        		pause = SDL_FALSE; // SDL_RestoreWindow( screen );
			}
		break;
		case SDL_KEYDOWN:
			switch( event.key.keysym.sym ) {
			case SDLK_AC_BACK:  key |= _ESCAPE_; 	break;
			case SDLK_ESCAPE:	key |= _ESCAPE_;	break;
		#ifndef _PORT_ANDROID_
			case SDLK_F1:		key |= _F1_;		break;
			case SDLK_F2:		key |= _F2_;		break;
			case SDLK_F3:		key |= _F3_;		break;
			case SDLK_F4:		key |= _F4_;		break;
			case SDLK_i: 		key |=_INFO_;		break;
			case SDLK_l:
				if( language == _SPANISH_ ) language  = _ENGLISH_;
				else						language  = _SPANISH_;
				SDL_Delay( 200 );
			break;
			case SDLK_m:
				if( bmusic == SDL_TRUE ) { bmusic = SDL_FALSE; Mix_HaltMusic(); }
				else					 { bmusic = SDL_TRUE; Mix_PlayChannel( -1, fx[2], 0 ); }
				SDL_Delay( 200 );
			break;
			case SDLK_g:
				++systemgraph;
				if( systemgraph > _MSX2_ ) systemgraph = _ZXSPEC_;
				SDL_DestroyTexture( tiles );
				SDL_Delay( 200 );
				tiles = IMG_LoadTexture( renderer, filespng[ systemgraph ] );
				SDL_Delay( 200 );
			break;
			case SDLK_F11:
			case SDLK_f:
				setfullscreen();
				SDL_Delay( 200 );
			break;
			case SDLK_PAUSE:
			case SDLK_p:
				if( pause ) pause = SDL_FALSE;
				else        pause = SDL_TRUE;
				SDL_Delay( 200 );
			break;
		#endif
		// ----------------------------------------------------------------
		// KEYBOARD:
		// ----------------------------------------------------------------
			case SDLK_w:
			case SDLK_UP:
			case SDLK_SPACE:	key |= _UP_;	break;
			case SDLK_s:
			case SDLK_DOWN:		key |= _DOWN_;	break;
			case SDLK_a:
			case SDLK_LEFT:		key |= _LEFT_;	break;
			case SDLK_d:
			case SDLK_RIGHT:	key |= _RIGHT_;	break;
			}
		break;
		case SDL_KEYUP:
			switch( event.key.keysym.sym ) {
			case SDLK_w:
			case SDLK_s:
			case SDLK_SPACE:
			case SDLK_UP:
			case SDLK_DOWN:		key |= _V_CENTERED_;	break;
			case SDLK_a:
			case SDLK_d:
			case SDLK_LEFT:
			case SDLK_RIGHT:	key |= _H_CENTERED_;	break;
			}
		break;
		}
	}
	return key;
	
}


