/* control.h */
#ifndef _CONTROL_
#define _CONTROL_
#include "environment.h"

#define _UP_ 			1
#define _DOWN_			2
#define _V_CENTERED_	4
#define _RIGHT_ 		8
#define _LEFT_  		16
#define _H_CENTERED_	32
#define _QUIT_  		64
#define _ESCAPE_		128
#define _INFO_			256
#define _PAUSE_			512
#define _F1_			1024
#define _F2_			2048
#define _F3_			4096
#define _F4_			8192
#define _CENTERED_		_V_CENTERED_ + _H_CENTERED_
#define _RIGHTDOWN_		_RIGHT_ + _DOWN_
#define _LEFTDOWN_		_LEFT_  + _DOWN_
void updatetouch();
int  commoncontrol();
int  gamecontrol();

#endif

