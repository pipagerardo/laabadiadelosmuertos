/* demo.c */
#include "demo.h"
#include "game.h"
#include "enemies.h"
#include "drawing.h"
#include "loading.h"
#include "jean.h"
#include "control.h"

void demo() {

	/* Load data */
	uint stagedata[25][22][32];
	int  enemydata[25][7][15];
	uint exit = loaddata( stagedata, enemydata );
	if( exit == 1 ) return;
	
	/* Variables */	
	uint room[2] = {5,5}; /* Room, previous room */
	uint changeflag = 1; /* Screen change */
	uint counter[3] = {0,0,0}; /* Counters */
	float proyec[24] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}; /* Enemiess shoots */
	uint keyp = 0;
	uint parchment = 0;
	register uint n = 0;

	/* Init struct */
	struct enem enemies = {
		.type = {0,0,0,0,0,0,0},
		.x = {0,0,0,0,0,0,0},
		.y = {0,0,0,0,0,0,0},
		.direction = {0,0,0,0,0,0,0},
		.tilex = {0,0,0,0,0,0,0},
		.tiley = {0,0,0,0,0,0,0},
		.animation = {0,0,0,0,0,0,0},
		.limleft = {0,0,0,0,0,0,0},
		.limright = {0,0,0,0,0,0,0},
		.speed = {0,0,0,0,0,0,0},
		.fire = {0,0,0,0,0,0,0},
		.adjustx1 = {0,0,0,0,0,0,0},
		.adjustx2 = {0,0,0,0,0,0,0},
		.adjusty1 = {0,0,0,0,0,0,0},
		.adjusty2 = {0,0,0,0,0,0,0}
	};

	struct hero jean = {
		.x = 72,
		.y = 136,
		.direction = 1,
		.jump = 0,
		.height = 0,
		.animation = 0,
		.gravity = 1.9,
		.points = {0,0,0,0,0,0,0,0},
		.ground = 0,
		.collision = {0,0,0,0},
		.ducking = 0,
		.checkpoint = {5,72,136,5},
		.state = {1,0}, // vidas, cruces
		.flags = {0,0,0,0,0,0,0},
		.death = 0,
		.push = {0,0,0,0},
		.temp = 0
	};

	Uint32 i_ticks, time_ticks, f_ticks;
	i_ticks = SDL_GetTicks();
	SDL_ColorModFont( font, 255, 255, 255 );
	SDL_SetRenderDrawColor( renderer, 0, 0, 0, 255 );

	for( n = 0; n < 10; ++n ) {
		keyp = commoncontrol();
		if( keyp & _QUIT_   ) { state = _RUN_DESTROY_;     pause = SDL_FALSE; return; }
		if( keyp & _ESCAPE_ ) { state = _RUN_STARTSCREEN_; pause = SDL_FALSE; return; }
		SDL_RenderClear( renderer );
		drawscreen( stagedata, room, counter );
		statusbar( room, jean.state[0], jean.state[1] );
		drawjean( &jean, counter );
		renderpresent();
		SDL_Delay( frame );	
	}
	jean.ducking = 0;
	jean.push[0] = 0; // UP
	jean.push[1] = 0; // DOWN
	jean.ducking = 0;
	jean.push[0] = 0; // UP
	jean.push[1] = 0; // DOWN
	
	/* Game loop */
	while( exit != 1 ) {

		/* Manage counters */
		counters( counter );

		/* Cleaning the renderer */
		SDL_RenderClear( renderer );
		
		/* Animation of fire and water */
		animation( stagedata, room, counter );

		/* Draw screen */
		drawscreen( stagedata, room, counter );

		/* Draw statusbar */
		statusbar( room, jean.state[0], jean.state[1] );

		/* Draw Jean */
		drawjean( &jean, counter );

		/* Enemies */
		if (enemies.type[0] > 0) {
			if (room[0] != 4) movenemies( &enemies, counter, proyec, jean );
			if ((room[0] == 5) || (room[0] == 6)) crusaders( &enemies, room );
			if (room[0] == 10)	dragon( &enemies, counter, proyec );
			if (room[0] == 11)	fireball( &enemies, counter, jean, stagedata );
			if (room[0] == 14)	plants( &enemies, counter, proyec );
			if (room[0] ==  9)	drawrope( enemies );
			if (room[0] == 18)	death( &enemies, counter, proyec, stagedata );
			if ((room[0] == 24) && (enemies.type[0] == 18))	satan( &enemies, counter, proyec );
			if ((room[0] == 24) && (jean.flags[6]   ==  5))	crusaders( &enemies, room );
			drawenemies( &enemies );
		}

		/* Shoots */
		if ((proyec[0] > 0) && ((room[0] == 17) || (room[0] == 20) || (room[0] == 21) || (room[0] == 22)))
			drawshoots( proyec, &enemies );

		/* Jean management */
		if (jean.death == 0) {
			if (jean.flags[6] < 5) {
				if (jean.temp == 0) keyp = demo_control( &jean );
				// else				keyp = demo_gamecontrol();
				if (jean.temp == 1) jean.temp = 0;
				collisions( &jean, stagedata, room );
				movejean( &jean );
			} // else keyp = demo_gamecontrol();
			if (room[0] != 4) {
				touchobj( &jean, stagedata, room, &parchment, &changeflag, &enemies, proyec );
				contact( &jean, enemies, proyec, room );
			}
			events( &jean, stagedata, room, counter, &enemies );
		} // else keyp = demo_gamecontrol();

		/* Jean death */
		if (jean.death == 98) {
			if (room[0] != 4) {
				room[0] = jean.checkpoint[0];
				jean.x = jean.checkpoint[1];
				jean.y = jean.checkpoint[2];
				jean.jump = 0;
				jean.height = 0;
				jean.push[0] = 0;
				jean.push[1] = 0;
				jean.push[2] = 0;
				jean.push[3] = 0;
				changeflag = 2;
				jean.state[0] --;
				jean.death = 0;
				jean.temp = 1;
				// music( room, &changeflag, jean.flags[6] );
				// Mix_ResumeMusic ();
			} else {
				jean.death = 0;
				jean.flags[6] = 8;
			}
		}
		/* Using flag 6 as counter, to make time */
		if (jean.flags[6] > 7) jean.flags[6] ++;
		/* Reaching 15, jump to ending sequence */
		if (jean.flags[6] == 15) {
			state = _RUN_STARTSCREEN_;
			exit  = 1;
		}
		changescreen( &jean, room, &changeflag );
		if( changeflag > 0 ) {
			if ((jean.flags[6] < 4) || (jean.flags[6] > 5)) searchenemies( room, &enemies, &changeflag, enemydata );
			// music( room, &changeflag, jean.flags[6] );
			for( n=0; n<24; n++ ) { /* Reset enemyshoots */
				proyec[n] = 0;
			}
			counter[0] = 0;
			changeflag = 0;
		}
				
		// Sin m�s vidas, fin de la partida.
		if( jean.state[0] == 0 ) {
			// Mix_HaltMusic();
			state = _RUN_STARTSCREEN_;
			exit = 1;
		}
		/* Exit requested */
		if( keyp & _ESCAPE_ ) {
			exit = 1;
			state = _RUN_STARTSCREEN_;
		}
		/* Exit requested */
		if( keyp & _QUIT_ ) {
			exit = 1;
			state = _RUN_DESTROY_;
		}

		/* Flip ! */
		renderpresent();

		if( pause ) {
			Mix_PauseMusic();
			while( !exit && pause ) {
				// keyp = gamecontrol();
				keyp = commoncontrol();
				if( keyp & _QUIT_   ) { exit = 1; state = _RUN_DESTROY_; pause = SDL_FALSE; }
				if( keyp & _ESCAPE_ ) { exit = 1; state = _RUN_STARTSCREEN_; pause = SDL_FALSE; }
				if( keyp & _INFO_   ) { touch.alpha += 16; if( touch.alpha > 255 ) touch.alpha = 32; updatetouch(); }
				if( keyp & _UP_   ) { touch.zoom += 0.05f; updatetouch(); }
				if( keyp & _DOWN_ ) { touch.zoom -= 0.05f; updatetouch(); }
				SDL_RenderClear( renderer );
				drawscreen( stagedata, room, counter );
				statusbar( room, jean.state[0], jean.state[1] );
				drawjean( &jean, counter );
				// drawenemies( &enemies );
				SDL_TextHVFontR( font, texts[ language + 66 ] ); 
				renderpresent();
				SDL_Delay( frame );	
			}
			Mix_ResumeMusic();
		} 
		
		f_ticks = SDL_GetTicks();
		time_ticks = f_ticks - i_ticks;
		i_ticks = f_ticks;
		if( time_ticks < frame ) SDL_Delay( frame - time_ticks );
		
	}
	demo_control( NULL );

}

uint demo_control( struct hero *jean ) {
	
	static SDL_RWops *datafile = NULL;
	static int change = 0;
	static Uint32 mov = 0;
	if( jean == NULL ) {
		if( datafile != NULL ) SDL_RWclose( datafile );
		datafile = NULL;
		return 0;
	}
	if( datafile == NULL )	{
		datafile = SDL_RWFromFile( _DATA_DEMO_, "r" );
		if( datafile == NULL ) return _ESCAPE_;
		change = 0;
		mov    = 0;
	}	

	uint key = gamecontrol();
	if( key & _UP_    ) key |= _ESCAPE_;
	if( key & _DOWN_  ) key |= _ESCAPE_;
	if( key & _RIGHT_ ) key |= _ESCAPE_;
	if( key & _LEFT_  ) key |= _ESCAPE_;
	if( key & _QUIT_  ) key |= _ESCAPE_;
	
	if( change == 0 ) {
		if( SDL_RWread( datafile, &mov, 4, 1 ) == 0 )  key |= _ESCAPE_;
		change = 7;
	} else {
		--change;
		mov >>= 4;
	}

	if( mov & 8 ) { 				// RIGHT
		jean->push[3] = 1; // RIGHT
		jean->push[2] = 0; // LEFT
	} else if( mov & 4  ) {			// LEFT
		jean->push[3] = 0; // RIGHT
		jean->push[2] = 1; // LEFT
	} else /*if ( key & _H_CENTERED_ ) */ {	// H_CENTERED
		jean->push[3] = 0; // RIGHT			
		jean->push[2] = 0; // LEFT
	}

	if( mov & 2 ) 	{
		if( jean->jump == 0 ) {		// DOWN
			jean->ducking = 1;
			jean->push[1] = 1;// DOWN
		}
		jean->push[0] = 0; 	// UP
	} else if ( mov & 1 ) {		// UP
		if( jean->jump == 0	) {
			jean->jump    = 1;	
			jean->ducking = 0;
			jean->push[0] = 1;  // UP
			jean->push[1] = 0;	// DOWN		
		}
	} else /* if ( key & _V_CENTERED_ ) */ {	// V_CENTERED
		jean->ducking = 0;
		jean->push[0] = 0; // UP
		jean->push[1] = 0; // DOWN	
	}
	
	if( ( key & _ESCAPE_ ) || ( key & _QUIT_ ) ) {
		if( datafile != NULL ) SDL_RWclose( datafile );
		datafile = NULL;
	}
	
	return key;
}


