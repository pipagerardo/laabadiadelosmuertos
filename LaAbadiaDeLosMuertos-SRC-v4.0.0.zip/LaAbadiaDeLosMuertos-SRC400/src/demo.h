/* demo.h */
#ifndef _DEMO_
#define _DEMO_
#include "environment.h"

void demo();
uint demo_control( struct hero *jean );

#endif


