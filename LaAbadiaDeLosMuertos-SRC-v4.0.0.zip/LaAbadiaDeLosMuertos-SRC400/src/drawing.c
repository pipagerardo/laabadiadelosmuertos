/* drawing.c */
#include "drawing.h"

void drawscreen( uint stagedata[][22][32], uint room[], uint counter[] ) {

	register int coordx = 0;
	register int coordy = 0;
	register uint data = 0;
	SDL_Rect srctiles = {0,0,8,8};
	SDL_Rect destiles = {0,0,8,8};

	for( coordy=0; coordy<=21; coordy++ ) {
		for( coordx=0; coordx<=31; coordx++ ) {
			data = stagedata[room[0]][coordy][coordx];
			if( (data == 0) || (data == 99) ) continue;
			destiles.x = coordx << 3;
			destiles.y = coordy << 3;
			if( data < 200 ) {	
				srctiles.w = 8;
				srctiles.h = 8;
				if( data < 101 ) {
					srctiles.y = 0;
					/* Cross brightness */
					if (data == 84) srctiles.x = ((data - 1) << 3) + (counter[0]/8 << 3);
					else			srctiles.x = (data - 1) << 3;
				} else {
					if (data == 154) {
						srctiles.x=600 + ((counter[0] >> 3) << 4 );
						srctiles.y=0;
						srctiles.w=16;
						srctiles.h=24;
					} else {
						srctiles.y = 8;
						srctiles.x = (data - 101) << 3;
					}
				}	
			} else if( (data > 199) && (data < 300) ) {	
				srctiles.x = (data - 201) * 48;
				srctiles.y = 16;
				srctiles.w = 48;
				srctiles.h = 48;	
			} else if( (data > 299) && (data < 399) ) {	
				srctiles.x = 96 + ((data - 301) << 3 );
				srctiles.y = 16;
				srctiles.w = 8;
				srctiles.h = 8;
				/* Door movement */
				if( (room[0] == 7) && ((counter[1] > 59) && (counter[1] < 71)) ) {
					if ((data == 347) || (data == 348) || (data == 349) || (data == 350)) {
						destiles.x += 2;
						if( (data == 350) && (counter[1] == 70) )
							Mix_PlayChannel(-1, fx[3], 0); /* Sound of door */
					}
				}	
			} else if( (data > 399) && (data < 405) ) { 	/* Hearts */
				srctiles.x = 96 + ((data - 401) << 3 ) + ( ( counter[0] >> 4 ) << 5 );
				srctiles.y = 24;
				srctiles.w = 8;
				srctiles.h = 8;
			} else if( (data > 408) && (data < 429) ) { 	/* Crosses */
				srctiles.x = 96 + ((data - 401) << 3 ) + ( (counter[1] / 23) << 5 );
				srctiles.y = 24;
				srctiles.w = 8;
				srctiles.h = 8;	
			} else if( (data > 499) && (data < 599) ) {
				srctiles.x = 96 + ((data - 501) << 3 );
				srctiles.y = 32;
				srctiles.w = 8;
				srctiles.h = 8;
			} else if( (data > 599) && (data < 650) ) {
				srctiles.x = 96 + ((data - 601) << 3 );
				srctiles.y = 56;
				srctiles.w = 8;
				srctiles.h = 8;
			} else if( data == 650 ) { /* Cup */
				srctiles.x = 584;
				srctiles.y = 87;
				srctiles.w = 16;
				srctiles.h = 16;	
			}
			destiles.w = srctiles.w;
			destiles.h = srctiles.h;
			SDL_RenderCopy( renderer, tiles, &srctiles, &destiles );	
		}
	}
}

void statusbar( uint room[], int lifes, int crosses ) {
	if( room[0] == 4 ) return;
	SDL_Rect srcbar = {448,104,13,12};
	SDL_Rect desbar = {0,177,13,12};
	SDL_RenderCopy (renderer, tiles, &srcbar, &desbar );
	if( lifes < 10 ) {
		SDL_CharFontR( font, lifes + '0', 14, 173 );
	} else {
		int dec  =  ( lifes / 10 ) ;
		int uni = lifes - ( dec * 10 );
		int x = SDL_CharFontR( font, dec + '0', 14, 173 );
		SDL_CharFontR( font, uni + '0', x, 173 );
	}
	srcbar.x = 461;
	srcbar.w = 12;
	desbar.x = 31;
	SDL_RenderCopy( renderer, tiles, &srcbar, &desbar );
	if (crosses < 10) {
		SDL_CharFontR( font, crosses + '0', 46, 173 );
	} else {
		int x = SDL_CharFontR( font, '1', 46, 173 );
		SDL_CharFontR( font, crosses - 10 + '0', x, 173 );
	}
	if( (room[0] > 0) && (room[0] < 4) )
		SDL_TextRFontR( font, texts[ language + room[0] -1 ], 173 );
	if( room[0] > 4 ) 
		SDL_TextRFontR( font, texts[ language + room[0] -2 ], 173 );
}

void drawrope( struct enem enemies ) {
	register int i = 0;
	register int j = 0;
	register int blocks = 0;
	SDL_Rect srctile = {424,8,16,8};
	SDL_Rect destile = {0,0,16,8};
	for( i=2; i<6; i++ ) {
		blocks = (enemies.y[i] - (enemies.limleft[i] - 8)) / 8;
		for (j=0; j<=blocks; j++) {
			srctile.y = 8;
	  		destile.x = enemies.x[i];
	  		destile.y = (enemies.limleft[i] - 8) + (8 * j);
			SDL_RenderCopy(renderer,tiles,&srctile,&destile);
		}
	}
}

void drawshoots( float proyec[], struct enem *enemies ) {
	/* Shoots from skeletons & gargoyles */

	SDL_Rect srctile = {656,24,16,8};
	SDL_Rect destile = {0,0,0,0};
	register int i = 0;
	register int n = 0;
	srctile.y = 24;
	
	for( n=0; n<=4; n+=2 ) {
		
		if (proyec[n] == 0) continue;
	  	i = proyec[n+1];
	  	if (enemies->type[i] == 15) {
	  		srctile.y = 26;
			srctile.h = 10;
			srctile.x = 640 - (16 * enemies->direction[i]);
	  	}

	  	/* Move shoot */
	  	if (enemies->direction[i] == 1) {
			if (proyec[n] > enemies->limleft[i] + 8 ) proyec[n] -= 2.5;
			else {
				enemies->fire[i] = 0;
				enemies->speed[i] = 0;
				proyec[n] = 0;
				continue;
			}
	  	} else {
			if (proyec[n] < enemies->limright[i] - 8 ) proyec[n] += 2.5;
			else {
		  		enemies->fire[i] = 0;
				enemies->speed[i] = 0;
				proyec[n] = 0;
				continue;
			}
	  	}
	  	
	  	/* Draw shoot */
	  	destile.w = srctile.w;
		destile.h = srctile.h;
		destile.x = proyec[n];
		destile.y = enemies->y[i] + 8;
		SDL_RenderCopy(renderer,tiles,&srctile,&destile);
		
	}
	
}

void drawparchment( Uint8 R, Uint8 G, Uint8 B ) {
	SDL_SetTextureColorMod( tiles , R, G, B );
	SDL_Rect srctile = { 904, 0, 24, 24 };
	SDL_Rect destile = { 32, 40, 24, 24 };
	register int i, j;
	for( i = 0; i < 4; ++i ) {
		srctile.x = 904; destile.x = 32;
		SDL_RenderCopy( renderer, tiles, &srctile, &destile );
		for( j = 0; j < 3; ++j ) {
			srctile.x = 928; destile.x += 24;
			SDL_RenderCopy( renderer, tiles, &srctile, &destile );
			srctile.x = 952; destile.x += 24;
			SDL_RenderCopy( renderer, tiles, &srctile, &destile );
		}
		srctile.x = 976; destile.x += 24;
		SDL_RenderCopy( renderer, tiles, &srctile, &destile );
		if( i == 0 || i == 2 ) srctile.y += 24;
		destile.y += 24;
	}
	SDL_SetTextureColorMod( tiles , 255, 255, 255 );
}

void showparchment( uint *parchment ) {
	if( systemgraph == _ZXSPEC_ )	drawparchment( 255, 255,   0 ); // yelow
	else							drawparchment( 230, 206, 128 ); // yelow
	SDL_ColorModFont( font, 0, 0, 0 );
	int x1 = 63; // 59
	int x2 = 89; // 85
	switch( *parchment ) {
		case 3: 
			SDL_TextHFontR( font, texts[ language +  43 ], x1 );
			SDL_TextHFontR( font, texts[ language +  44 ], x2 );
		break;
		case 8:	
			SDL_TextHFontR( font, texts[ language +  45 ], x1 );
			SDL_TextHFontR( font, texts[ language +  46 ], x2 );
		break;
		case 12: 
			SDL_TextHFontR( font, texts[ language +  47 ], x1 );
			SDL_TextHFontR( font, texts[ language +  48 ], x2 );
		break;
		case 14: 
			SDL_TextHFontR( font, texts[ language +  49 ], x1 );
			SDL_TextHFontR( font, texts[ language +  50 ], x2 );
		break;
		case 16: 
			SDL_TextHFontR( font, texts[ language +  51 ], x1 );
			SDL_TextHFontR( font, texts[ language +  52 ], x2 );
		break;
		case 21: 
			SDL_TextHFontR( font, texts[ language +  53 ], x1 );
			SDL_TextHFontR( font, texts[ language +  54 ], x2 );
		break;
	}
    SDL_ColorModFont( font, 255, 255, 255 );
}

void redparchment() {
	if( systemgraph == _ZXSPEC_ )	drawparchment( 255,  0,    0 ); // Red
	else							drawparchment( 212,  82,  77 ); //	Dark red
	SDL_ColorModFont( font, 0, 0, 0 );
	SDL_TextHFontR( font, texts[ language +  55 ], 52 );
	SDL_TextHFontR( font, texts[ language +  56 ], 76 );
	SDL_TextHFontR( font, texts[ language +  57 ], 100 );
    SDL_ColorModFont( font, 255, 255, 255 );
}

void blueparchment() {
	if( systemgraph == _ZXSPEC_ )	drawparchment(   0,  0,  255 ); //	Blue
	else							drawparchment( 125, 118, 252 ); //	Light blue
	SDL_ColorModFont( font, 0, 0, 0 );
	SDL_TextHFontR( font, texts[ language +  58 ], 52 );
	SDL_TextHFontR( font, texts[ language +  59 ], 76 );
	SDL_TextHFontR( font, texts[ language +  60 ], 100 );
    SDL_ColorModFont( font, 255, 255, 255 );
}

