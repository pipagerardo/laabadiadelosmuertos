/* drawing.h */
#ifndef _DRAWING_
#define _DRAWING_
#include "environment.h"

void drawscreen( uint stagedata[][22][32], uint room[], uint counter[] );

void statusbar( uint room[],int lifes,int crosses );

void drawrope( struct enem enemies );

void drawshoots( float proyec[], struct enem *enemies );

void drawparchment( Uint8 R, Uint8 G, Uint8 B );

void showparchment( uint *parchment );

void redparchment();

void blueparchment();

#endif

