/* ending.c */
#include "ending.h"
#include "control.h"
#include "loading.h"

void ending() {

	// playmus( 10, 0 );
	playmus( 0, 0 );
	state = _RUN_STARTSCREEN_;
	int key = 0;
	int exit = 0;
	SDL_Rect srcdoor = {600,72,64,48};
	SDL_Rect desdoor = {96,72,64,48};
	Uint32 i_ticks, time_ticks, f_ticks;
	i_ticks = SDL_GetTicks();
	SDL_SetRenderDrawColor( renderer, 0, 0, 0, 255 );
	int i = 0;
	int x = 0;
	for( i=0; i<951; i++ ) {

		// Check Controls
		key = commoncontrol();
		if( key & _QUIT_ ) { 
			state = _RUN_DESTROY_; 
			break;
		} 
		if( ( key & _UP_ ) || ( key & _ESCAPE_ ) ) break;
		
		/* Cleaning the renderer */
		SDL_RenderClear( renderer );

		if( i<360 ) x = i/60;
		else		x = 5;
		
		if(i > 365) {
			SDL_TextHFontR( font, texts[ language +  61 ], 19 );
			SDL_TextHFontR( font, texts[ language +  62 ], 43 ); 
			SDL_TextHFontR( font, texts[ language +  63 ], 136 );
			SDL_TextHFontR( font, texts[ language +  64 ], 157 );
		}

		srcdoor.x = 600 + (64 * x);
		SDL_RenderCopy( renderer, tiles, &srcdoor, &desdoor );

		/* Flip */
		renderpresent();

		if( pause ) {
			Mix_PauseMusic();
			while( !exit && pause ) {
				key = commoncontrol();
				if( key & _QUIT_   ) { exit = 1; state = _RUN_DESTROY_; pause = SDL_FALSE; }
				if( key & _ESCAPE_ ) { exit = 1; state = _RUN_STARTSCREEN_; pause = SDL_FALSE; }
				if( key & _INFO_   ) { touch.alpha += 16; if( touch.alpha > 255 ) touch.alpha = 32; updatetouch(); }
				if( key & _UP_     ) { touch.zoom += 0.05f; updatetouch(); }
				if( key & _DOWN_   ) { touch.zoom -= 0.05f; updatetouch(); }
				SDL_RenderClear(renderer);
				SDL_TextHVFontR( font, texts[ language + 66 ] );
				renderpresent();
				SDL_Delay( frame );	
			}
			Mix_ResumeMusic();
		} 

		f_ticks = SDL_GetTicks();
		time_ticks = f_ticks - i_ticks;
		i_ticks = f_ticks;
		if( time_ticks < frame ) SDL_Delay( frame - time_ticks );

	}

	/* Cleaning */
	Mix_HaltMusic();

}

