/* ending.h */
#ifndef _ENDING_
#define _ENDING_
#include "environment.h"

void ending();

#endif

