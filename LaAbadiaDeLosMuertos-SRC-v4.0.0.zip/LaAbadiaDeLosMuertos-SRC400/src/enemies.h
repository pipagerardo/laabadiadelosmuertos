/* enemies.h */
#ifndef _ENEMIES_
#define _ENEMIES_
#include "environment.h"

void searchenemies( uint room[], struct enem *enemies, uint *changeflag, int enemydata[][7][15] );

void drawenemies( struct enem *enemies );

void movenemies( struct enem *enemies, uint counter[], float proyec[], struct hero jean );

void plants( struct enem *enemies, uint counter[], float proyec[] );

void crusaders( struct enem *enemies, uint room[] );

void death( struct enem *enemies, uint counter[], float proyec[], uint stagedata[][22][32] );

void dragon( struct enem *enemies, uint counter[], float proyec[] );

void satan( struct enem *enemies, uint counter[], float proyec[] );

void fireball( struct enem *enemies, uint counter[], struct hero jean, uint stagedata[][22][32] );

#endif

