/* environment.c */
#include "environment.h"

#ifdef _PORT_ANDROID_	
	#include <stdlib.h>
#endif
#include "loading.h"

SDL_bool	  bmusic	  = SDL_TRUE;	// SDL_TRUE | SDL_FALSE Musica.
int 		  language    = _SPANISH_;	// _SPANISH_ | _ENGLISH_
int 		  systemgraph = _MSX2_; 	//  _ZXSPEC_ | _MSX1_ | _MSX2_
uint 		  frame       = 60; 		// 30 Hz ~ 60 Hz Fotogramas por segundo.
uint          state       = _RUN_LOADING_;
uint          fullscreen  = 1; 			// 0-Windowed, 1-Fullscreen
int  		  zoom        = 3;
int			  win_wi      = 256;
int			  win_hi      = 192;
int			  win_w       = 0;
int			  win_h       = 0;
int           joyn        = 0;
Sint16 		  axisr       = 12000;  	// Precisi�n del Joystick de 0 a 32767
int			  axisx       = 0;			// Joystick Eje Horizontal X = 0
int			  axisy       = 1;			// Joystick Eje Vertical   Y = 1;
int           flipx       = 1;
int           flipy		  = 1;
SDL_bool      pause		  = SDL_FALSE;
SDL_Window   *screen      = NULL;
SDL_Renderer *renderer    = NULL;
SDL_Joystick *joystick    = NULL;
SDL_GameController* gamecontroller = NULL;
struct s_touch touch = { 0, 
#ifdef _PORT_ANDROID_
1.5f,
#else
1.0f,
#endif
1.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0, 0, 0, 0, 127 };
SDL_Font	 *font        = NULL;
SDL_Font	 *minifont    = NULL;
SDL_Texture  *tiles       = NULL;
SDL_Texture  *loading     = NULL;
size_t       c_num = -1;
Mix_Music    *bso = NULL;
Mix_Chunk 	 *fx[8]  = { NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL };
const char   *fmn[10] = { _MUSIC_0_, _MUSIC_1_, _MUSIC_2_, _MUSIC_3_, _MUSIC_4_, _MUSIC_5_,	_MUSIC_6_, _MUSIC_7_, _MUSIC_8_, _MUSIC_9_ };
const char   *texts[134] = { // 0 Espa�ol y 67 Ingles
	// Rooms
	"Oraci�n de Esperanza",		// 00
	"Torre de la Campana",		// 01
	"Suministros de vino",		// 02
	"Escapa !!!",				// 03
	"La muerte est� cerca",		// 04
	"Iglesia abandonada",		// 05
	"El Altar",					// 06
	"�rbol del ahorcado",		// 07
	"Bestia pestilente",		// 08
	"Cueva de ilusiones",		// 09
	"Ruinas plagadas",			// 10
	"Catacumbas",				// 11
	"Jard�n oculto",			// 12
	"Tuneles l�gubres",			// 13
	"Lago la desesperaci�n",	// 14
	"La rueda de la fe",		// 15
	"Banquete de la Muerte",	// 16
	"R�o subterr�neo",			// 17
	"Puerta inesperada",		// 18
	"Iglesia sat�nica",			// 19
	"Almas torturadas",			// 20
	"Cenizas a las cenizas",	// 21
	"Satan�s !!!",				// 22
	// Start Screen
#ifdef _PORT_ANDROID_
	" <ARRIBA>    PARA EMPEZAR",    // 23
	" <DERECHA>   INFO. JUEGO",	   	// 24
	" <IZQUIERDA> ESPA�OL/INGLES",	// 25
#else
	" PULSA <BARRA> PARA EMPEZAR",	// 23
	" <I> INFO. JUEGO",		    	// 24
	" <F> VENTANA / PANTALLA",		// 25
#endif
	"???",							// 26
	"ERES JEAN", 					// 27
	"RAYMOND", 						// 28
	"MENSAJE",						// 29
	"VIDA EXTRA",					// 30
	"RECOGE LAS CRUCES",			// 31
	"PUNTO DE",						// 32
	"CONTROL",						// 33
	"EVITA LOS ENEMIGOS",			// 34
	"Y LAS TRAMPAS", 				// 35
	"ACTIVA EL MECANISMO", 			// 36
	"Y ABRE LAS PUERTAS", 			// 37
	// History
	"Siglo XIII. Los C�taros estaban", 		// 38
	"siendo expulsados por la Iglesia",		// 39
	"Cat�lica de la regi�n de Languedoc", 	// 40
	"El C�taro Jean Raymond corre", 		// 41
	"para escapar de los Cruzados...",		// 42
	// Parchment
	"Doce cruces", 					// 43
	"contra el diablo",				// 44
	"Doce hermanos", 				// 45
	"murieron aqu�", 				// 46
	"Cuatro hermanos",				// 47
	"cambiaron su fe",				// 48
	"Un camino invisible",			// 49
	"sobre un puente",				// 50
	"Salta a la muerte",			// 51
	"y demuestra tu fe",			// 52
	"Desl�zate en la",				// 53
	"jaula de la bestia",			// 54
	"Tu destino no vendr�", 		// 55
	"de mi mano, pero s�", 			// 56
	"por manos humanas", 			// 57
	"Herej�a !!! El C�taro", 		// 58
	"est� oculto en el trono", 		// 59
	"de Satan�s, quemarlo !", 		// 60
	// Ending
	"Tu cuerpo se quem�", 			// 61
	"en las llamas, pero", 			// 62
	"tu alma ha encontrado", 		// 63
	"un lugar en el Cielo",			// 64
	// Game Over
	"JUEGO TERMINADO",				// 65
	"P A U S A",					// 66
	// Rooms
	"A prayer of Hope",
	"Tower of the Bell",
	"Wine supplies",
	"Escape !!!",
	"Death is close",
	"Abandoned church",
	"The Altar",
	"Hangman's Tree",
	"Pestilent Beast",
	"Cave of illusions",
	"Plagued ruins",
	"Catacombs",
	"Hidden garden",
	"Gloomy tunels",
	"Lake of despair",
	"The wheel of faith",
	"Banquet of Death",
	"Underground river",
	"Unexpected gate",
	"Evil church",
	"Tortured souls",
	"Ashes to ashes",
	"Satan !!!",
	// Start Screen
#ifdef _PORT_ANDROID_
	" <UP>    TO START",
	" <RIGHT> GAME INFO",
	" <LEFT>  SPANISH/ENGLISH",
#else
	" PRESS <UP> TO START",
	" <I> GAME INFO",
	" <F> WINDOW / FULLSCREEN",
#endif
	" ??? ",
	"YOU ARE JEAN",
	"RAYMOND",
	"MESSAGE", 
	"EXTRA LIFE",
	"COLLECT CROSSES", 
	"USE IT AS",
	"CHECKPOINT",
	"AVOID ENEMIES",
	"AND TRAPS", 
	"ACTIVATE MECHANISM", 
	"TO OPEN THE DOORS", 
	// History
	"13th Century. The Cathars were",
	"being expelled by the Catholic", 
	"Church out of the Languedoc.",
	"The Catar Jean Raymond runs",
	"to escape the Crusaders...", 
	// Parchment
	"Twelve crosses",
	"against the devil",
	"Twelve brothers", 
	"hid and died here",
	"Four brothers",
	"changed their faith",
	"An invisible path",
	"over a wood bridge",
	"Jump to death", 
	"and prove your faith",
	"Glide through",
	"the beast cage",
	"Your doom will come",
	"not by my hand,",
	"but by human hands",
	"Heresy !!! The Catar",
	"is hidden on the throne",
	"of Satan, burn him !",
	// Ending
	"Your body has burned", 
	"in the flames,", 
	"but your soul has found", 
	"a place in Heaven",
	// Game Over
	"GAME OVER",
	"P A U S E"
};

char         *configpath = NULL;

const char   *filespng[3] = {
	_TILES_ZX_,
	_TILES_MSX1_,
	_TILES_MSX2_
};

const Uint8 msxcolor[16][3] = {
		{   0,   0,   0 }, //  0 Transparent
		{   0,   0,   0 }, //  1 Black
		{  33, 200,  66 }, //  2 Medium Green
		{  94, 220, 120 }, //  3 Light green
		{  84,  85, 237 }, //  4 Dark blue
		{ 125, 118, 252 }, //  5 Light blue
		{ 212,  82,  77 }, //  6 Dark red
		{  66, 235, 245 }, //  7 Cyan
		{ 252,  85,  84 }, //  8 Medium red
		{ 255, 121, 120 }, //  9 Light red
		{ 212, 193,  84 }, // 10 Dark yellow
		{ 230, 206, 128 }, // 11 Light yellow
		{  33, 176,  59 }, // 12 Dark green
		{ 201,  91, 186 }, // 13 Magenta
		{ 204, 204, 204 }, // 14 Gray
		{ 255, 255, 255 }  // 15 White
};

const Uint8 zxcolor[16][3] = { 
		{   0,   0,   0 }, //  0 black
		{   0,   0, 205 }, //  1 blue
		{ 205,   0,   0 }, //  2 red
		{ 205,   0, 205 }, //  3 magenta
		{   0, 205,   0 }, //  4 green
		{   0, 205, 205 }, //  5 cyan
		{ 205, 205,   0 }, //  6 yellow
		{ 205, 205, 205 }, //  7 white
		{   0,   0,   0 }, //  8 Light black
		{   0,   0, 255 }, //  9 Light blue
		{ 255,   0,   0 }, // 10 Light red
		{ 255,   0, 255 }, // 11 Light magenta
		{   0, 255,   0 }, // 12 Light green
		{   0, 255, 255 }, // 13 Light cyan
		{ 255, 255,   0 }, // 14 Light yellow
		{ 255, 255, 255 }  // 15 Light white
};

SDL_bool init() {
	
	frame = 1000 / frame;

#ifdef _PORT_ANDROID_
	SDL_SetHint( SDL_HINT_ANDROID_SEPARATE_MOUSE_AND_TOUCH, "1" );
#endif
	SDL_SetHint( SDL_HINT_ACCELEROMETER_AS_JOYSTICK, "0" );
	SDL_SetHint( SDL_HINT_RENDER_VSYNC, "1" );  
	SDL_SetHint( SDL_HINT_RENDER_SCALE_QUALITY,  "nearest" /* "linear" */ );
	SDL_SetHint( SDL_HINT_MOUSE_FOCUS_CLICKTHROUGH, "0" );
	SDL_SetHint( SDL_HINT_JOYSTICK_ALLOW_BACKGROUND_EVENTS, "0" );
	SDL_SetHint( SDL_HINT_ACCELEROMETER_AS_JOYSTICK, "0" );
	
	if( SDL_Init( SDL_INIT_VIDEO  | SDL_INIT_EVENTS  | SDL_INIT_TIMER | SDL_INIT_AUDIO | SDL_INIT_JOYSTICK | SDL_INIT_GAMECONTROLLER /*| SDL_INIT_HAPTIC*/ ) < 0 ) {
	#ifdef _SHOW_LOG_
		SDL_LOG( "SDL could not initialize! SDL Error: %s\n", SDL_GetError() );
	#endif
		return SDL_FALSE;
	}
	
#ifdef _PORT_ANDROID_
	SDL_SetHint( SDL_HINT_ANDROID_SEPARATE_MOUSE_AND_TOUCH, "1" );
#endif
	SDL_SetHint( SDL_HINT_RENDER_SCALE_QUALITY,  "nearest" /* "linear" */ );
	SDL_SetHint( SDL_HINT_RENDER_VSYNC, "1" );  
	SDL_SetHint( SDL_HINT_MOUSE_FOCUS_CLICKTHROUGH, "0" );
	SDL_SetHint( SDL_HINT_JOYSTICK_ALLOW_BACKGROUND_EVENTS, "0" );
	SDL_SetHint( SDL_HINT_ACCELEROMETER_AS_JOYSTICK, "0" );
	
	SDL_DisableScreenSaver();

	/* Iniciamos el Audio */
	int init = Mix_Init( MIX_INIT_OGG );
	if( ( init & MIX_INIT_OGG ) != MIX_INIT_OGG ) {
	#ifdef _SHOW_LOG_
		SDL_LOG( "Mix_Init: %s\n", Mix_GetError() );
	#endif
		return SDL_FALSE;
	}
	if( Mix_OpenAudio( MIX_DEFAULT_FREQUENCY, MIX_DEFAULT_FORMAT, MIX_DEFAULT_CHANNELS, 1024 ) == -1 ) {
	#ifdef _SHOW_LOG_
		SDL_LOG( "Mix_OpenAudio: %s\n", Mix_GetError() );
	#endif
		return SDL_FALSE;
	}
	Mix_AllocateChannels( 5 );

	/* Iniciamos la imagen */
	init = IMG_Init( IMG_INIT_PNG );
	if( ( init & IMG_INIT_PNG ) != IMG_INIT_PNG ) {
	#ifdef _SHOW_LOG_
		SDL_LOG( "IMG_Init: %s\n", IMG_GetError() );
	#endif
		return SDL_FALSE;
	}

#ifdef _PORT_ANDROID_
	SDL_DisplayMode mode;
 	SDL_GetCurrentDisplayMode( 0, &mode );
 	win_w = mode.w;
 	win_h = mode.h;
 	zoom  = 3;
 	fullscreen = 1;
 	#else
	win_w = win_wi * zoom;
	win_h = win_hi * zoom;	
#endif

	/* Creating window */
#ifdef _PORT_ANDROID_
	Uint32 windowflags = SDL_WINDOW_FULLSCREEN;
#else
	Uint32 windowflags = SDL_WINDOW_RESIZABLE;
	if( fullscreen ) windowflags |= SDL_WINDOW_FULLSCREEN_DESKTOP;
#endif
	screen = SDL_CreateWindow(
		_TITLE_,
		SDL_WINDOWPOS_CENTERED,
		SDL_WINDOWPOS_CENTERED,
		win_w,
		win_h, 
		windowflags
	);
	if( screen == NULL ) {
	#ifdef _SHOW_LOG_
		SDL_LOG( "Window not initialize! SDL Error: %s\n", SDL_GetError() );
	#endif
		return SDL_FALSE;
	}
	
#ifndef _PORT_ANDROID_
	SDL_Surface* ico = NULL;
	ico = IMG_Load( _ICO16x16_ );
	if( ico != NULL ) SDL_SetWindowIcon( screen, ico );
	SDL_FreeSurface( ico );
#endif
	
	/* Creating renderer */
	renderer = SDL_CreateRenderer( screen, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC );
	if( renderer == NULL ) {
	#ifdef _SHOW_LOG_
		SDL_LOG( "Renderer not initialize! SDL Error: %s\n", SDL_GetError() );
	#endif
		return SDL_FALSE;
	}
	
	/* Configure Render */
#ifndef _PORT_ANDROID_
	SDL_DisplayMode mode;
 	SDL_GetWindowDisplayMode( screen, &mode );
 	mode.w = win_w;
 	mode.h = win_h;
 	mode.refresh_rate = 1000 / frame;
 	if( SDL_SetWindowDisplayMode( screen, &mode ) < 0 ) {
 	#ifdef _SHOW_LOG_
 		SDL_LOG( "Error SDL_SetWindowDisplayMode\n" );
		SDL_LOG( "w = %d, h = %d, refresh = %d\n", mode.w, mode.h, mode.refresh_rate );
	#endif
	}
#endif

	setLogicalSize( win_wi, win_hi );
	SDL_SetRenderDrawColor(  renderer, 0, 0, 0, 255 );
	SDL_SetRenderDrawBlendMode( renderer, SDL_BLENDMODE_NONE /*SDL_BLENDMODE_BLEND*/ );

	/* Joysticks */
	if( joystick == NULL ) {
		int nJoysticks = SDL_NumJoysticks();
		if( nJoysticks > 0 ) joystick = SDL_JoystickOpen( joyn );
	}
	
	return SDL_TRUE;
}

void setfullscreen() {
	if (fullscreen == 0) {
		SDL_SetWindowFullscreen( screen, SDL_WINDOW_FULLSCREEN_DESKTOP ); /* SDL_WINDOW_FULLSCREEN */
		SDL_ShowCursor( 0 );
		SDL_RenderPresent( renderer );
		fullscreen = 1;
	} else {
		SDL_SetWindowFullscreen( screen, 0 );
		SDL_ShowCursor( 1 );
		SDL_RenderPresent( renderer );
		fullscreen = 0;

 		SDL_RenderPresent( renderer );
 		SDL_RestoreWindow( screen );
 		SDL_RenderPresent( renderer );
	}
}


int setLogicalSize( int logical_w, int logical_h ) {

/*
    SDL_RenderSetIntegerScale( renderer, SDL_TRUE );
	SDL_RenderSetLogicalSize( renderer, logical_w, logical_h );
	return 0;
*/	

    int w = 1, h = 1;
    float want_aspect;
    float real_aspect;
    float scale;
    int   i_scale;
    SDL_Rect viewport;

    if (SDL_GetRendererOutputSize( renderer, &w, &h ) < 0) return -1;
    win_w = w;
    win_h = h;

    want_aspect = (float)logical_w / logical_h;
    real_aspect = (float)w / h;

    // Clear the scale because we're setting viewport in output coordinates
    SDL_RenderSetScale( renderer, 1.0f, 1.0f );

    if( SDL_fabs( want_aspect - real_aspect ) < 0.0001 ) {
        // The aspect ratios are the same, just scale appropriately
        scale = (float)w / logical_w;
        SDL_RenderSetViewport( renderer, NULL );
    } else if( want_aspect > real_aspect ) { // >
        // We want a wider aspect ratio than is available - letterbox it
		scale = (float)w / logical_w;

		i_scale = (int)SDL_floor( scale * 10.0f );
		if( i_scale % 2 ) --i_scale;
		scale = i_scale / 10.0f;
		
        viewport.x = 0;
        viewport.w = w;
        viewport.h = (int)SDL_ceil(logical_h * scale);
        viewport.y = (h - viewport.h) / 2;
        SDL_RenderSetViewport(renderer, &viewport);
    } else {
        // We want a narrower aspect ratio than is available - use side-bars
        scale = (float)h / logical_h;
        
		i_scale = (int)SDL_floor( scale * 10.0f );
		if( i_scale % 2 ) --i_scale;
		scale = i_scale / 10.0f;
        
        viewport.y = 0;
        viewport.h = h;
        viewport.w = (int)SDL_ceil( logical_w * scale );
        viewport.x = (w - viewport.w) / 2;
        SDL_RenderSetViewport( renderer, &viewport );
    }

    // Set the new scale
    SDL_RenderSetScale( renderer, scale, scale );

    return 0;

}

void renderpresent() {
	if( touch.id ) {
		SDL_RenderSetViewport( renderer, NULL );
		SDL_RenderSetScale( renderer, (float)win_w / win_wi, (float)win_h / win_hi );
		SDL_SetTextureAlphaMod( tiles, touch.alpha );
		SDL_Rect origen  = { 776, 122, 64, 32 };
		// SDL_Rect destino = {   0, 160, 64, 32 };
		SDL_Rect destino = {   0, touch.yi, touch.wi, touch.hi };
		SDL_RenderCopy( renderer, tiles, &origen, &destino );
		origen.x  = 840; 
		destino.x = touch.xi; 
		SDL_RenderCopy( renderer, tiles, &origen, &destino );
		if( pause ) {
			SDL_SetRenderDrawBlendMode( renderer, SDL_BLENDMODE_BLEND );
			SDL_SetRenderDrawColor( renderer, 255, 255, 255, touch.alpha );
			destino.x = 2; destino.y = 0;
			destino.w = touch.x2 * 254; destino.h = touch.y2 * 192;
			SDL_RenderDrawRect( renderer, &destino );
			destino.x = destino.w + 3;
			destino.w = touch.x3 * 254 - destino.x;
			SDL_RenderDrawRect( renderer, &destino );
			destino.x = touch.x3 * 256;
			destino.w = 254 - destino.x ;
			SDL_RenderDrawRect( renderer, &destino );
			SDL_SetRenderDrawColor( renderer, 0, 0, 0, 255 );
			SDL_SetRenderDrawBlendMode( renderer, SDL_BLENDMODE_NONE );
		}
		SDL_SetTextureAlphaMod( tiles, 255 );
		setLogicalSize( win_wi, win_hi );
	}
	SDL_RenderPresent( renderer );
}

int destroy( int ret ) {
	
	/* Cleaning */
	freemultimedia();
	if( configpath != NULL ) SDL_free( configpath );
	if( joystick   != NULL ) SDL_JoystickClose( joystick );
	if( renderer   != NULL ) SDL_DestroyRenderer( renderer );
	if( screen     != NULL ) SDL_DestroyWindow( screen );
	configpath = NULL;
	joystick   = NULL;
	renderer   = NULL;
	screen     = NULL;

	IMG_Quit();
	Mix_Quit();
	SDL_Quit();
	
#ifdef _PORT_ANDROID_
	exit( ret );
#endif
	return ret;
}
