/* environment.h */
#ifndef _ENVIRONMENT_
#define _ENVIRONMENT_

// #define _SHOW_LOG_
// #define _SAVE_DEMO_
// #define _TRAMPA_
// #define _TRAMPA_

#ifdef _PORT_ANDROID_
	#include "SDL.h"
	#include "SDL_image.h"
	#include "SDL_mixer.h"
	#include <android/log.h>
	#define  LOG_TAG    "ABBAYE"
	#define  SDL_LOG(...)  __android_log_print( ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__ )
#else
	#include "SDL2/SDL.h"
	#include "SDL2/SDL_image.h"
	#include "SDL2/SDL_mixer.h"
	#define  SDL_LOG(...) SDL_Log( __VA_ARGS__ )
#endif

#include "SDL_font.h"

#define _TITLE_ 		"Abbaye des Morts v4.00 "
#define _VERSION_		"PipaGerardo v4.00 "

#define _EXIT_FAILURE_		-1
#define _EXIT_SUCCESSFUL_	0

#define _RUN_LOADING_     	8
#define _RUN_STARTSCREEN_	0
#define _RUN_HISTORY_     	1
#define _RUN_GAME_        	2
#define _RUN_GAMEOVER_    	3
#define _RUN_ENDING_      	4
#define _RUN_DESTROY_     	6
#define _RUN_DEMO_        	7
	
#define _SPANISH_	0
#define _ENGLISH_ 	67
#define _ZXSPEC_	0
#define _MSX1_		1
#define _MSX2_		2

#ifdef _PORT_ANDROID_
	#define _FILE_CONFIG_   "/config.txt"
#else
	#define _FILE_CONFIG_   "config.txt"
	#define _ICO16x16_      "../graphics/Abbaye_des_morts16x16.png"
#endif

#define _DATA_MAP_		"data/map.txt"
#define _DATA_ENEMIES_	"data/enemies.txt"
#define _DATA_DEMO_		"data/demo.txt"

#define _TILES_ZX_ 		"graphics/tiles_zx.png"
#define _TILES_MSX1_	"graphics/tiles_msx1.png"
#define _TILES_MSX2_	"graphics/tiles_msx2.png"

#define _LOAD_ZX_		"graphics/loading_zx.png"
#define _LOAD_MSX1_		"graphics/loading_msx1.png"
#define _LOAD_MSX2_		"graphics/loading_msx2.png"

#define _MUSIC_0_ 		"musics/PrayerofHope.ogg"		// Ending
#define _MUSIC_1_ 		"musics/AreaIChurch.ogg"		//
#define _MUSIC_2_ 		"musics/GameOver.ogg"			// Game Over
#define _MUSIC_3_ 		"musics/HangmansTree.ogg"		//
#define _MUSIC_4_ 		"musics/AreaIICaves.ogg"		//
#define _MUSIC_5_ 		"musics/EvilFight.ogg"
#define _MUSIC_6_ 		"musics/AreaIIIHell.ogg"
#define _MUSIC_7_ 		"musics/Manhuntwood.ogg"		// 
#define _MUSIC_8_ 		"musics/MainTitle.ogg"			// Start Screen
#define _MUSIC_9_ 		"musics/Manhunt.ogg"			// History

#define _SOUND_0_		"sounds/shoot.ogg"
#define _SOUND_1_		"sounds/doorfx.ogg"
#define _SOUND_2_		"sounds/item.ogg"
#define _SOUND_3_		"sounds/jump.ogg"
#define _SOUND_4_		"sounds/slash.ogg"
#define _SOUND_5_		"sounds/mechanism.ogg"
#define _SOUND_6_		"sounds/onedeath.ogg"
#define _SOUND_7_		"sounds/thunder.ogg"
// #define _SOUND_8_	"sounds/gamestar.ogg"		// ? ? ?

#define _FONT_1_		"graphics/VeniceClassic.mtr"	
#define _FONT_2_		"graphics/Consola.mtr"

typedef unsigned int uint;
extern SDL_bool		 bmusic;
extern int 			 language;
extern int 			 systemgraph;
extern uint 		 frame;
extern uint          state;
extern uint          fullscreen;
extern int  		 zoom;
extern int			 win_w;
extern int			 win_h;
extern int			 win_wi;
extern int		     win_hi;
extern int           joyn;
extern Sint16 		 axisr;
extern int			 axisx;
extern int			 axisy;
extern int           flipx;
extern int           flipy;
extern SDL_bool      pause;
extern SDL_Window	*screen;
extern SDL_Renderer *renderer;
extern SDL_Joystick *joystick;
extern SDL_GameController* gamecontroller;
extern struct s_touch {
	SDL_TouchID id;
	float zoom;
	float zoomx;
	float zoomy;
	float y1;
	float y2;
	float x1;
	float x2;
	float x3;
	float x4;
	int   yi;
	int   xi;
	int   wi;
	int   hi;
	int   alpha;
} touch;
			
extern SDL_Font		*font;
extern SDL_Font		*minifont;
extern SDL_Texture  *tiles;
extern SDL_Texture  *loading;
extern size_t       c_num;
extern Mix_Music    *bso;
extern Mix_Chunk 	*fx[8];
extern const char   *fmn[10];
extern const char   *filespng[3];
extern const char   *texts[134];
extern char         *configpath;
extern const Uint8  msxcolor[16][3];
extern const Uint8  zxcolor[16][3];

/* Structs */
struct enem {
	int type[7];
	float x[7];
	float y[7];
	int direction[7];
	int tilex[7];
	int tiley[7];
	int animation[7];
	int limleft[7];
	int limright[7];
	int speed[7];
	int fire[7];
	int adjustx1[7];
	int adjustx2[7];
	int adjusty1[7];
	int adjusty2[7];
};

struct hero {
	float x;
	float y;
	int direction;
	int jump; 			/* 1-Up, 2-Down */
	float height; 		/* Limit of jump */
	int animation;
	float gravity;
	int points[8]; 		/* Points of collision */
	int ground; 		/* Pixel where is ground */
	int collision[4];	/* Collisions, in 4 directions */
	int ducking;
	int checkpoint[4];
	int state[2]; 		/* Vidas y cruces */
	int flags[7];
	int death;
	int push[4]; 		/* Pulsaciones de teclas */
	int temp;
};

SDL_bool init();

void setfullscreen();
int  setLogicalSize( int logical_w, int logical_h );
void renderpresent();

int destroy( int ret );

#endif

