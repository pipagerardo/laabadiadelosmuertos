/* game.c */
#include "game.h"
#include "enemies.h"
#include "drawing.h"
#include "loading.h"
#include "jean.h"
#include "control.h"

void game() {

	/* Load data */
	uint stagedata[25][22][32];
	int  enemydata[25][7][15];
	uint exit = loaddata( stagedata, enemydata );
	if( exit == 1 ) return;

	/* Variables */	
	uint room[2] = {5,5}; /* Room, previous room */
	uint changeflag = 1; /* Screen change */
	uint counter[3] = {0,0,0}; /* Counters */
	float proyec[24] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}; /* Enemiess shoots */
	uint keyp = 0;
	uint parchment = 0;
	register uint n = 0;

	/* Init struct */
	struct enem enemies = {
		.type = {0,0,0,0,0,0,0},
		.x = {0,0,0,0,0,0,0},
		.y = {0,0,0,0,0,0,0},
		.direction = {0,0,0,0,0,0,0},
		.tilex = {0,0,0,0,0,0,0},
		.tiley = {0,0,0,0,0,0,0},
		.animation = {0,0,0,0,0,0,0},
		.limleft = {0,0,0,0,0,0,0},
		.limright = {0,0,0,0,0,0,0},
		.speed = {0,0,0,0,0,0,0},
		.fire = {0,0,0,0,0,0,0},
		.adjustx1 = {0,0,0,0,0,0,0},
		.adjustx2 = {0,0,0,0,0,0,0},
		.adjusty1 = {0,0,0,0,0,0,0},
		.adjusty2 = {0,0,0,0,0,0,0}
	};

	struct hero jean = {
		.x = 72,
		.y = 136,
		.direction = 1,
		.jump = 0,
		.height = 0,
		.animation = 0,
		.gravity = 1.9,
		.points = {0,0,0,0,0,0,0,0},
		.ground = 0,
		.collision = {0,0,0,0},
		.ducking = 0,
		.checkpoint = {5,72,136,5},
		.state = {9,0}, // vidas, cruces
		.flags = {0,0,0,0,0,0,0},
		.death = 0,
		.push = {0,0,0,0},
		.temp = 0
	};

	Uint32 i_ticks, time_ticks, f_ticks;
	i_ticks = SDL_GetTicks();
	SDL_ColorModFont( font, 255, 255, 255 );
	SDL_SetRenderDrawColor( renderer, 0, 0, 0, 255 );

	for( n = 0; n < 10; ++n ) {
		keyp = commoncontrol();
		if( keyp & _QUIT_   ) { state = _RUN_DESTROY_;     pause = SDL_FALSE; return; }
		if( keyp & _ESCAPE_ ) { state = _RUN_STARTSCREEN_; pause = SDL_FALSE; return; }
		SDL_RenderClear( renderer );
		drawscreen( stagedata, room, counter );
		statusbar( room, jean.state[0], jean.state[1] );
		drawjean( &jean, counter );
		renderpresent();
		SDL_Delay( frame );	
	}
	jean.ducking = 0;
	jean.push[0] = 0; // UP
	jean.push[1] = 0; // DOWN

	/* Game loop */
	while( exit != 1 ) {

		/* Manage counters */
		counters( counter );

		/* Cleaning the renderer */
		SDL_RenderClear( renderer );

	#ifdef _TRAMPA_
		if( keyp & _F1_ ) {
			++jean.state[0];
		#ifdef _SHOW_LOG_
			SDL_LOG( "room[0]=%d\n", room[0] );
		#endif
		}
		if( keyp & _F2_ ) {
			++room[0];
			++room[1];
			if( room[0] > 24 ) {
				room[0] = 4;  room[1] = 4;
			}
			changescreen( &jean, room, &changeflag );
			searchenemies( room, &enemies, &changeflag, enemydata );
			music( room, &changeflag, jean.flags[6] );
			for( n=0; n<24; n++ ) { // Reset enemyshoots
				proyec[n] = 0;
			}
			counter[0] = 0;
			changeflag = 0;
		#ifdef _SHOW_LOG_
			SDL_LOG( "room[0]=%d\n", room[0] );
		#endif
		}
		// DEMONIO
		if( keyp & _F3_ ) {
			room[0] = 24;
			room[1] = 23;
			jean.x = 16; // 110;
			jean.y = 116;//170;
			jean.state[0] = 9;
			jean.state[1] = 12;
			enemies.type[0] = 18;
			enemies.x[0] = 200;
			enemies.y[0] = 48;
			enemies.direction[0] = 0;
			enemies.tilex[0] = 192;
			enemies.tiley[0] = 88;
			enemies.animation[0] = 0;
			enemies.limleft[0] = 16;
			enemies.limright[0] = 80;
			enemies.speed[0] = 0;
			enemies.fire[0] = 0;
			enemies.adjustx1[0] = 0;
			enemies.adjustx2[0] = 32;
			enemies.adjusty1[0] = 0;
			enemies.adjusty2[0] = 48;
			changescreen( &jean, room, &changeflag );
			searchenemies( room, &enemies, &changeflag, enemydata );
			music( room, &changeflag, jean.flags[6] );
		}
	#endif
	
		/* Animation of fire and water */
		animation( stagedata, room, counter );

		/* Draw screen */
		drawscreen( stagedata, room, counter );

		/* Draw statusbar */
		statusbar( room, jean.state[0], jean.state[1] );

		/* Draw Jean */
		drawjean( &jean, counter );

		/* Enemies */
		if (enemies.type[0] > 0) {
			if (room[0] != 4) movenemies( &enemies, counter, proyec, jean );
			if ((room[0] == 5) || (room[0] == 6)) crusaders( &enemies, room );
			if (room[0] == 10)	dragon( &enemies, counter, proyec );
			if (room[0] == 11)	fireball( &enemies, counter, jean, stagedata );
			if (room[0] == 14)	plants( &enemies, counter, proyec );
			if (room[0] ==  9)	drawrope( enemies );
			if (room[0] == 18)	death( &enemies, counter, proyec, stagedata );
			if ((room[0] == 24) && (enemies.type[0] == 18))	satan( &enemies, counter, proyec );
			if ((room[0] == 24) && (jean.flags[6]   ==  5))	crusaders( &enemies, room );
			drawenemies( &enemies );
		}

		/* Shoots */
		if ((proyec[0] > 0) && ((room[0] == 17) || (room[0] == 20) || (room[0] == 21) || (room[0] == 22)))
			drawshoots( proyec, &enemies );

		/* Jean management */
		if (jean.death == 0) {
			if (jean.flags[6] < 5) {
				if (jean.temp == 0) keyp = control( &jean );
				else				keyp = gamecontrol();
				if (jean.temp == 1) jean.temp = 0;
				collisions( &jean, stagedata, room );
				movejean( &jean );
			} else keyp = gamecontrol();
			if (room[0] != 4) {
				touchobj( &jean, stagedata, room, &parchment, &changeflag, &enemies, proyec );
				contact( &jean, enemies, proyec, room );
			}
			events( &jean, stagedata, room, counter, &enemies );
		} else keyp = gamecontrol();

		/* Jean death */
		if (jean.death == 98) {
			if (room[0] != 4) {
				room[0] = jean.checkpoint[0];
				jean.x = jean.checkpoint[1];
				jean.y = jean.checkpoint[2];
				jean.jump = 0;
				jean.height = 0;
				jean.push[0] = 0;
				jean.push[1] = 0;
				jean.push[2] = 0;
				jean.push[3] = 0;
				changeflag = 2;
				jean.state[0] --;
				jean.death = 0;
				jean.temp = 1;
				music( room, &changeflag, jean.flags[6] );
				Mix_ResumeMusic();
			} else {
				jean.death = 0;
				jean.flags[6] = 8;
			}
		}
		/* Using flag 6 as counter, to make time */
		if (jean.flags[6] > 7) jean.flags[6] ++;
		/* Reaching 15, jump to ending sequence */
		if (jean.flags[6] == 15) {
			state = _RUN_ENDING_;
			exit  = 1;
		}
		changescreen( &jean, room, &changeflag );
		if( changeflag > 0 ) {
			if ((jean.flags[6] < 4) || (jean.flags[6] > 5)) searchenemies( room, &enemies, &changeflag, enemydata );
			music( room, &changeflag, jean.flags[6] );
			for( n=0; n<24; n++ ) { /* Reset enemyshoots */
				proyec[n] = 0;
			}
			counter[0] = 0;
			changeflag = 0;
		}
		
		/* Parchments */
	#ifndef _SAVE_DEMO_
		if( jean.flags[6] == 3 ) parchment = 50;  // Red 
		if( jean.flags[6] == 6 ) parchment = 100; // Blue
		
		if( parchment > 0 ) {
			Mix_PauseMusic();
			Mix_PlayChannel( -1, fx[2], 0 );
	
			for( n = 0; n < 10; ++n ) {
				keyp = commoncontrol();
				if( keyp & _QUIT_   ) { exit = 1; state = _RUN_DESTROY_; break; }
				if( keyp & _ESCAPE_ ) { exit = 1; state = _RUN_STARTSCREEN_; break;	}
				SDL_RenderClear( renderer );
				drawscreen( stagedata, room, counter );
				statusbar( room, jean.state[0], jean.state[1] );
				drawjean( &jean, counter );
				drawenemies( &enemies );
				if( parchment < 50 ) 
					showparchment( &parchment );
				else if ( parchment < 100 ) {
					redparchment();
				} else {
					crusaders( &enemies, room );
					blueparchment();
				}
				if( pause ) {
					SDL_TextHVFontR( font, texts[ language + 66 ] ); 
					if( ( keyp != _QUIT_ ) && ( keyp != _ESCAPE_ ) ) exit = 0; 
				}
				renderpresent();
				SDL_Delay( frame );	
			} 	
			keyp = 0;

			while( !(keyp & _UP_) && ( exit == 0 ) ) {
				keyp = commoncontrol();
				if( keyp & _QUIT_   ) { exit = 1; state = _RUN_DESTROY_; }
				if( keyp & _ESCAPE_ ) { exit = 1; state = _RUN_STARTSCREEN_; }
				SDL_RenderClear( renderer );
				drawscreen( stagedata, room, counter );
				statusbar( room, jean.state[0], jean.state[1] );
				drawjean( &jean, counter );
				drawenemies( &enemies );
				if( parchment < 50 ) 
					showparchment( &parchment );
				else if ( parchment < 100 ) {
					redparchment();
					jean.flags[6] = 4;
				} else {
					crusaders( &enemies, room );
					blueparchment();
				}
				if( pause ) {
					SDL_TextHVFontR( font, texts[ language + 66 ] ); 
					if( ( keyp != _QUIT_ ) && ( keyp != _ESCAPE_ ) ) exit = 0; 
				}
				renderpresent();
				SDL_Delay( frame );	
			}
			jean.ducking = 0;
			jean.push[0] = 0; 
			jean.push[1] = 0;
			jean.push[2] = 0;
			jean.push[3] = 0;
			SDL_Delay(300);
			keyp = gamecontrol();	
			Mix_ResumeMusic();
			keyp = 0;
			parchment = 0;
			if( jean.flags[6] == 4 ) {
				Mix_PlayChannel(-1, fx[2], 0);
				jean.flags[6] = 5;
				jean.direction = 0;
				music( room, &changeflag, jean.flags[6] );
			}
			if( jean.flags[6] == 6 ) { 
				jean.death = 0;
				changeflag = 1;
				room[0] = 4;
				jean.flags[6] = 7;
				jean.x = 125;
				jean.y = 115;
				jean.jump = 1;
			}
			SDL_RenderClear( renderer );
			drawscreen( stagedata, room, counter );
			statusbar( room, jean.state[0], jean.state[1] );
			drawjean( &jean, counter );
			drawenemies( &enemies );
			
		}
	#endif	
		/* End Parchments */
		
		// Sin m�s vidas, fin de la partida.
		if( jean.state[0] == 0 ) {
			Mix_HaltMusic();
			state = _RUN_GAMEOVER_;
			exit = 1;
		}
		/* Exit requested */
		if( keyp & _ESCAPE_ ) {
			exit = 1;
			state = _RUN_STARTSCREEN_;
		}
		/* Exit requested */
		if( keyp & _QUIT_ ) {
			exit = 1;
			state = _RUN_DESTROY_;
		}

		/* Flip ! */
		renderpresent();
	
		if( pause ) {
			Mix_PauseMusic();
			while( !exit && pause ) {
				keyp = commoncontrol();
				if( keyp & _QUIT_   ) { exit = 1; state = _RUN_DESTROY_; pause = SDL_FALSE; }
				if( keyp & _ESCAPE_ ) { exit = 1; state = _RUN_STARTSCREEN_; pause = SDL_FALSE; }
				if( keyp & _INFO_   ) { touch.alpha += 16; if( touch.alpha > 255 ) touch.alpha = 32; updatetouch(); }
				if( keyp & _UP_   ) { touch.zoom += 0.05f; updatetouch(); }
				if( keyp & _DOWN_ ) { touch.zoom -= 0.05f; updatetouch(); }
				
				SDL_RenderClear( renderer );
				drawscreen( stagedata, room, counter );
				statusbar( room, jean.state[0], jean.state[1] );
				drawjean( &jean, counter );
				// drawenemies( &enemies );
				SDL_TextHVFontR( font, texts[ language + 66 ] ); 
				renderpresent();
				SDL_Delay( frame );	
			}
			Mix_ResumeMusic();
		}
		
		f_ticks = SDL_GetTicks();
		time_ticks = f_ticks - i_ticks;
		i_ticks = f_ticks;
		if( time_ticks < frame ) SDL_Delay( frame - time_ticks );
		
	}

}

void animation( uint stagedata[][22][32], uint room[], uint counter[] ) {
	register int i = 0;
	register int j = 0;
	register uint data = 0;
	for( j=0; j<=21; j++ ) {
		for( i=0; i<=31; i++ ) {
			data = stagedata[room[0]][j][i];
			/* Fire animation */
			if ((data == 59) || (data == 60)) {
				if ((counter[0] == 1) || (counter[0] == 11) || (counter[0] == 21)) {
					if (data == 59) data = 60;
					else			data = 59;
				}
			}
			/* Water animation */
			if ((data > 500) && (data < 533)) {
				if (data < 532) data ++;
				else 			data = 501;
			}
			stagedata[room[0]][j][i] = data;
		}
	}
}

void counters( uint counter[] ) {
	if (counter[0] < 29) counter[0] ++;
	else				 counter[0] = 0;
	if (counter[1] < 90) counter[1] ++;
	else				 counter[1] = 0;
	if (counter[2] < 8)  counter[2] ++;
	else				 counter[2] = 0;
}

uint control( struct hero *jean ) {

	uint key = gamecontrol();

	if( key & _RIGHT_ ) { 		// RIGHT
		jean->push[3] = 1; 		// RIGHT
		jean->push[2] = 0; 		// LEFT
	} else if( key & _LEFT_ ) {	// LEFT
		jean->push[3] = 0; 		// RIGHT
		jean->push[2] = 1; 		// LEFT
	} else {					// H_CENTERED
		jean->push[3] = 0; 		// RIGHT			
		jean->push[2] = 0; 		// LEFT
	}

	if( key & _DOWN_ ) 	{
		if( jean->jump == 0 ) {	// DOWN
			jean->ducking = 1;
			jean->push[1] = 1;	// DOWN
		}
		jean->push[0] = 0; 		// UP
	} else if ( key & _UP_ ) {	// UP
		if( jean->jump == 0	) {
			jean->jump    = 1;	
			jean->ducking = 0;
			jean->push[0] = 1;  // UP
			jean->push[1] = 0;	// DOWN		
		}
	} else {					// V_CENTERED
		jean->ducking = 0;
		jean->push[0] = 0; 		// UP
		jean->push[1] = 0; 		// DOWN	
	}

	// ----------------------------------------------------------------------------------
	// GUARDAR MOVIMIENTOS PARA DEMO:
	#ifdef _SAVE_DEMO_
	static SDL_RWops *datafile = NULL;
	static int change = 0;
	static Uint32 mov = 0;
	if( datafile == NULL )	{ 
		datafile = SDL_RWFromFile( _DATA_DEMO_, "w" );
		if( datafile == NULL ) return _ESCAPE_;
		change = 0;
		mov    = 0;
	}

	if( key & _UP_    ) mov |= 0x10000000;
	if( key & _DOWN_  ) mov |= 0x20000000;
	if( key & _LEFT_  ) mov |= 0x40000000;
	if( key & _RIGHT_ ) mov |= 0x80000000;
	
	if( change > 6 ) {
		if( SDL_RWwrite( datafile, &mov, 4, 1 ) == 0 )  key = _ESCAPE_;
		change = 0;
		mov    = 0;
	} else {
		++change;
		mov >>= 4;
	}
	
	if( key == _ESCAPE_ ) {
		if( datafile != NULL ) SDL_RWclose( datafile );
		datafile = NULL;
	}
	#endif
	// ----------------------------------------------------------------------------

	return key;
}

void events( struct hero *jean, uint stagedata[][22][32], uint room[], uint counter[], struct enem *enemies ) {

	int i = 0;
	int x = 0;
	int y = 0;

	switch( room[0] ) {
	
	case 4:
		if (jean->temp < 7) {
			/* Mover a Jean */
			if (counter[1] == 45) {
				switch (jean->direction) {
					case 0: jean->direction = 1; break;
					case 1: jean->direction = 0; break;
				}
				jean->temp ++;
			}
		} else {
			jean->direction = 0;
			jean->death = 1;
		}
	break;

	case 7: /* Close door */
		if ((jean->x > 24) && (jean->flags[0] == 0)) {
			stagedata[7][14][0] = 347;
			stagedata[7][15][0] = 348;
			stagedata[7][16][0] = 349;
			stagedata[7][17][0] = 350;
			jean->flags[0] = 1;
			Mix_PlayChannel(-1, fx[1], 0);
			SDL_Delay(500);
		}
	break;

	case 8: /* Open ground */
		if ((jean->x > 15) && (jean->flags[1] == 1) && (stagedata[8][20][26] == 7)) {
			stagedata[8][20][26] = 38;
			stagedata[8][20][27] = 0;
			stagedata[8][21][26] = 0;
			stagedata[8][21][27] = 0;
			Mix_PlayChannel(-1, fx[1], 0);
			SDL_Delay(500);
		}
		/* Open door */
		if ((jean->x > 211) && (jean->flags[2] == 1) && (stagedata[8][14][31] == 343)) {
			stagedata[8][14][31] = 0;
			stagedata[8][15][31] = 0;
			stagedata[8][16][31] = 0;
			stagedata[8][17][31] = 0;
			Mix_PlayChannel(-1, fx[1], 0);
			SDL_Delay(500);
		}
	break;
	
	case 10: /* Dragon fire kills Jean */
		if (((jean->x > 127) && (jean->x < 144)) && (jean->y < 89)) {
			if ((enemies->speed[0] > 109) && (enemies->speed[0] < 146))
				jean->death = 1;
		}
	break;
	
	case 19: /* Open door */
		if ((jean->y > 16) && (jean->flags[3] == 1) && (stagedata[19][16][0] == 347)) {
			stagedata[19][16][0] = 0;
			stagedata[19][17][0] = 0;
			stagedata[19][18][0] = 0;
			stagedata[19][19][0] = 0;
			Mix_PlayChannel(-1, fx[1], 0);
			SDL_Delay(500);
		}
	break;
	
	case 20: /* Open door */
		if ((jean->x > 208) && (jean->flags[4] == 1) && (stagedata[20][14][31] == 343)) {
			stagedata[20][14][31] = 0;
			stagedata[20][15][31] = 0;
			stagedata[20][16][31] = 0;
			stagedata[20][17][31] = 0;
			Mix_PlayChannel(-1, fx[1], 0);
			SDL_Delay(500);
		}
	break;

	case 24:
		if ((jean->state[1] == 12) && (jean->x > 8) && (jean->flags[6] == 0)) {
			/* Block entry */
			stagedata[24][16][0] = 99;
			stagedata[24][17][0] = 99;
			stagedata[24][18][0] = 99;
			stagedata[24][19][0] = 99;
			jean->flags[6] = 1;
			/* Mark checkpoint */
			jean->checkpoint[0] = 24;
			jean->checkpoint[1] = jean->x;
			jean->checkpoint[2] = jean->y;
		}
		if ((jean->flags[6] == 1) && (jean->state[1] > 0) && (counter[0] == 0)) {
			/* Putting crosses */
			switch (jean->state[1]) {
				case 1:  x=11; y=5;  break;
				case 2:  x=10; y=5;  break;
				case 3:  x=8;  y=8;  break;
				case 4:  x=5;  y=8;  break;
				case 5:  x=4;  y=8;  break;
				case 6:  x=2;  y=12; break;
				case 7:  x=5;  y=14; break;
				case 8:  x=6;  y=14; break;
				case 9:  x=9;  y=14; break;
				case 10: x=10; y=14; break;
				case 11: x=13; y=13; break;
				case 12: x=15; y=16; break;
			}
			stagedata[24][y][x] = 84;
			jean->state[1] --;
			Mix_PlayChannel(-1, fx[1], 0);
		}
		if ((jean->flags[6] == 1) && (jean->state[1] == 0) && (counter[0] == 29)) {
			/* Draw cup */
			stagedata[24][3][15] = 650;
			jean->flags[6] = 2;
			Mix_PlayChannel(-1, fx[1], 0);
		}
		/* Killed Satan, Smoke appears */
		if (enemies->type[0] == 88) {
			if (enemies->speed[0] < 90) enemies->speed[0] ++;
			else {
				enemies->speed[0] = 0;
				enemies->type[i] = 0;
				enemies->x[0] = 0;
				enemies->y[0] = 0;
				enemies->type[0] = 17;
				/* Putting red parchment */
				stagedata[24][14][28] = 339;
				stagedata[24][14][29] = 340;
				stagedata[24][15][28] = 341;
				stagedata[24][15][29] = 342;
			}
		}
	break;
	}
}

void music( uint room[], uint *changeflag, int flag ) {
	if (room[0] == 1)  playmus( 0, 0 );
	if ((room[0] == 2) && (room[1] == 1))  playmus( 1, -1 );
	if (room[0] == 4)   playmus(  2, 0 );
	if ((room[0] == 5) && (room[1] != 6)) playmus( 7, -1 );
	if ((room[0] == 6) && (room[1] == 7)) playmus( 7, -1 );
	if ((room[0] == 7) && (room[1] == 6)) playmus( 1, -1 );
	if (((room[0] == 8) && (room[1] == 9)) || ((room[0] == 8) && (*changeflag == 2))) playmus( 1, -1 );
	if (room[0] == 9) playmus( 3, 0 );
	if (((room[0] == 11) && (room[1] == 12)) || ((room[0] == 11) && (*changeflag == 2))) playmus( 4, -1 );
	if (((room[0] == 12) && (room[1] == 11)) || ((room[0] == 12) && (*changeflag == 2))) playmus( 1, -1 );
	if ((room[0] == 13) && (room[1] == 14)) playmus( 1, -1 );
	if (((room[0] == 14) && (room[1] == 13)) || ((room[0] == 14) && (*changeflag == 2))) playmus( 4, -1 );
	if ((room[0] == 15) && (*changeflag == 2)) playmus( 4, -1 );
	if ((room[0] == 16) && (room[1] == 17)) playmus( 4, -1 );
	if ((room[0] == 17) && (room[1] == 16)) playmus( 1, -1 );
	if (room[0] == 18) playmus( 5, -1);
	if (((room[0] == 19) && (room[1] == 18)) || ((room[0] == 19) && (*changeflag == 2))) playmus( 4, -1 );
	if ((room[0] == 20) && (room[1] == 21)) playmus( 4, -1 );
	if ((room[0] == 21) && (room[1] == 20)) playmus( 6, -1 );
	if ((room[0] == 23) && (room[1] == 24)) playmus( 6, -1 );
	if ((room[0] == 24) && (flag != 5)) playmus( 5, -1 );
	if ((room[0] == 24) && (flag == 5)) playmus( 7, -1 );
 	*changeflag -= 1;
}

void changescreen( struct hero *jean, uint room[], uint *changeflag ) {
	if ((jean->x < 1) && (room[0] != 5)) {
		room[1] = room[0];
		room[0] -= 1;
		jean->x = 240;
		*changeflag = 1;
	}
	if ((jean->x + 16) > 256) {
		room[1] = room[0];
		room[0] += 1;
		jean->x = 1;
		*changeflag = 1;
	}
	if ((jean->y + 12 < -16) && (jean->jump == 1)) {
		room[1] = room[0];
		room[0] -=5;
		jean->y = 152;
		*changeflag = 1;
	}
	if ((jean->y > 175) && (jean->jump != 1)) {
		room[1] = room[0];
		room[0] +=5;
		jean->y = -16;
		*changeflag = 1;
	}
}

