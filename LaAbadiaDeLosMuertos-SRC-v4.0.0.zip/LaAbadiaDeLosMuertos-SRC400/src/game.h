/* game.h */
#ifndef _GAME_
#define _GAME_
#include "environment.h"

void game();

void animation( uint stagedata[][22][32], uint room[], uint counter[] );

void counters( uint counter[] );

uint control( struct hero *jean );

void events( struct hero *jean, uint stagedata[][22][32], uint room[], uint counter[], struct enem *enemies );

void music( uint room[], uint *changeflag,int flag );

void changescreen( struct hero *jean, uint room[], uint *changeflag );

#endif

// Rooms: Se empieza en 5. Room 0 est� libre.
//   NADA -> 0,  1,  2,  3,  4 <- FINAL QUEMADO
//  START->  5,  6,  7,  8,  9 <- AHORCADO
// DRAGON-> 10, 11, 12, 13, 14
//          15, 16, 17, 18, 19
//          20, 21, 22, 23, 24 <- DEMONIO
// 
// room[0] = 7;	// HABITACI�N ACTUAL
// room[1] = 6;	// HABITACI�N PREVIA
// jean.x = 240; 	// ( 0 ~ 256 ) 110;
// jean.y = 116;	// ( 0 ~ 192 ) 170;
// jean.direction = 1; // 1 derecha | 0 izquierda
// jean.jump = 0;		// 1 saltar  | 0 suelo
// jean.ducking = 0;	// 1 agachado | 0 en pie
// (jean->death == 0)  // VIVO
// (jean->death > 0)   // MUERTO
// STATES:
// jean.state[0] = 9;  // vidas
// jean.state[1] = 0;  // cruces
// CHECKPOINTS:
// checkpoint inicial = {5,72,136,5}
// jean->checkpoint[0] = room[0];
// jean->checkpoint[1] = jean->x;
// jean->checkpoint[2] = jean->y;
// jean->checkpoint[3] = room[1];
// FLAGS:
// jean.flags[0] == 1  // Cerrar puerta de la Abadia.
// jean.flags[1] == 1; // BELL
// jean.flags[2] == 1; // DRAGON
// jean.flags[3] == 1; // AHORCADO
// jean.flags[4] == 1; // PUERTA INESPERADA
// jean.flags[5] == 1; //  Cruces invertidas, 0 Curces normales
// jean.flags[6] == 8; // A las Puertas del cielo.
// jean.flags[6] == 2; // dibujar la copa.
// jean.flags[6] == 5;  // Animaci�n jack en la hogera.
// jean.flags[6] == 15; // A la hogera.
// jean.flags[6] == 3; // Tocar parche rojo.
// jean.flags[6] == 6; // Parche Azul
// jean.flags[6] == 4; // Suena coger parche.

