/* gameover.c */
#include "gameover.h"
#include "control.h"
#include "loading.h"

void gameover() {
		
	playmus( 2, 0 );
	SDL_SetRenderDrawColor( renderer, 0, 0, 0, 255 );
	
	Uint32 ticks, i_ticks, time_ticks, f_ticks;
	ticks = i_ticks = f_ticks = SDL_GetTicks();
	uint exit = 0;
	int  key  = 0;
	while (exit != 1) {
		// Start game
		if( ( f_ticks - ticks ) > 8000 )  { 
			exit = 1;
			state = _RUN_STARTSCREEN_;
		}
		// Check Controls
		key = commoncontrol();
		if( key & _QUIT_ ) { 
			exit = 1;
			state = _RUN_DESTROY_; 
		} 
		if( ( key & _UP_ ) || ( key & _ESCAPE_ ) ) { 
			exit = 1;
			state = _RUN_STARTSCREEN_; 
		} 
		
		// Cleaning the renderer 
		SDL_RenderClear( renderer );
		SDL_TextHVFontR( font, texts[ language +  65 ] ); 

		// Flip !
		renderpresent();

		if( pause ) {
			Mix_PauseMusic();
			while( !exit && pause ) {
				int keyp = commoncontrol();
				if( keyp & _QUIT_   ) { exit = 1; state = _RUN_DESTROY_; pause = SDL_FALSE; }
				if( keyp & _ESCAPE_ ) { exit = 1; state = _RUN_STARTSCREEN_; pause = SDL_FALSE; }
				if( key & _INFO_   ) { touch.alpha += 16; if( touch.alpha > 255 ) touch.alpha = 32; updatetouch(); }
				if( key & _UP_     ) { touch.zoom += 0.05f; updatetouch(); }
				if( key & _DOWN_   ) { touch.zoom -= 0.05f; updatetouch(); }
				SDL_RenderClear(renderer);
				SDL_TextHVFontR( font, texts[ language + 66 ] );
				renderpresent();				
				SDL_Delay( frame );	
			}
			Mix_ResumeMusic();
		} 
		
		f_ticks = SDL_GetTicks();
		time_ticks = f_ticks - i_ticks;
		i_ticks = f_ticks;
		if( time_ticks < frame ) SDL_Delay( frame - time_ticks );

	}

	/* Cleaning */
	Mix_HaltMusic();
		
}


