/* gameover.h */
#ifndef _GAMEOVER_
#define _GAMEOVER_
#include "environment.h"

void gameover();

#endif

