/* history.c */
#include "history.h"
#include "control.h"
#include "loading.h"

void history() {

	SDL_Rect srcjean = {384,88,16,24};
	SDL_Rect desjean = {0,100,16,24};
	SDL_Rect srcenem = {96,64,16,24};
	SDL_Rect desenem = {0,100,16,24};
	int   key = 0;
	uint exit = 0;
	float posjean = -16;
	float posenem[4] = {-17,-17,-17,-17};
	uint animation = 0;
	uint i = 0;
	uint musicload = 0;

	Uint32 i_ticks, time_ticks, f_ticks;
	i_ticks = SDL_GetTicks();
	SDL_ColorModFont( font, 255, 255, 255 );
	SDL_SetRenderDrawColor( renderer, 0, 0, 0, 255 );
	while (exit != 1) {

		/* Cleaning the renderer */
		SDL_RenderClear(renderer);

		/* Play music at start */
		if (musicload == 0) {
			musicload = 1;
			playmus( 9, 0 );
		}

		/* Show text */
		SDL_TextHFontR( font, texts[ language +  38 ], 8 );
		SDL_TextHFontR( font, texts[ language +  39 ], 28 );
		SDL_TextHFontR( font, texts[ language +  40 ], 48 );
		SDL_TextHFontR( font, texts[ language +  41 ], 144 );
		SDL_TextHFontR( font, texts[ language +  42 ], 164 );

		/* Animation control */
		if (animation < 13)	animation ++;
		else				animation = 0;

		/* Jean running */
		if (posjean < 257) {
			posjean += 0.75;
			desjean.x = posjean;
			srcjean.x = 384 + ((animation / 7) * 16); /* Walking animation */
			srcjean.y = 88; 
			SDL_RenderCopy( renderer, tiles, &srcjean, &desjean );
		}

		/* Crusaders running */
		/* When start running */
		for( i=0; i <4; i++ ) {
			if (posjean > (35 + (30 * i)))
				posenem[i] += 0.65;
		}
		/* Draw */
		for (i=0;i<4;i++) {
			if ((posenem[i] > -17) && (posenem[i] < 257)) {
				desenem.x = posenem[i];
				srcenem.x = 96 + ((animation / 7) * 16);
				srcenem.y = 64;
				SDL_RenderCopy(renderer,tiles,&srcenem,&desenem);
			}
		}

		/* Check keyboard */
		key = commoncontrol();
		if( key & _QUIT_ ) { 
			exit = 1;
			state = _RUN_DESTROY_;
			pause = SDL_FALSE;
		} 
		if( key & _ESCAPE_ ) { 
			exit = 1;
			state = _RUN_STARTSCREEN_;
		}
		if( key & _UP_ ) { // Start game 
			state = _RUN_GAME_;
			exit =  1;
		}
		if( posenem[3] > 256 ) { /* Ending history */
			exit = 1;
			state = _RUN_GAME_;
		}

		/* Flip ! */
		renderpresent();

		if( pause ) {
			Mix_PauseMusic();
			while( !exit && pause ) {
				key = commoncontrol();
				if( key & _QUIT_   ) { exit = 1; state = _RUN_DESTROY_; pause = SDL_FALSE; }
				if( key & _ESCAPE_ ) { exit = 1; state = _RUN_STARTSCREEN_; pause = SDL_FALSE; }
				if( key & _INFO_   ) { touch.alpha += 16;   updatetouch(); }
				if( key & _UP_     ) { touch.zoom += 0.05f; updatetouch(); }
				if( key & _DOWN_   ) { touch.zoom -= 0.05f; updatetouch(); }
				SDL_RenderClear(renderer);
				/* Show text */
				SDL_TextHFontR( font, texts[ language +  38 ], 8 );
				SDL_TextHFontR( font, texts[ language +  39 ], 28 );
				SDL_TextHFontR( font, texts[ language +  40 ], 48 );
				SDL_TextHFontR( font, texts[ language +  41 ], 144 );
				SDL_TextHFontR( font, texts[ language +  42 ], 164 );
				SDL_TextHVFontR( font, texts[ language + 66 ] );
				renderpresent();
				SDL_Delay( frame );	
			}
			Mix_ResumeMusic();
		} 

		f_ticks = SDL_GetTicks();
		time_ticks = f_ticks - i_ticks;
		i_ticks = f_ticks;
		if( time_ticks < frame ) SDL_Delay( frame - time_ticks );

	}

	Mix_HaltMusic();

}

