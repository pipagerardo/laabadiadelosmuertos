/* jean.h */
#ifndef _JEAN_
#define _JEAN_

#include "environment.h"

void movejean( struct hero *jean );

void drawjean( struct hero *jean, uint counter[] );

void collisions( struct hero *jean, uint stagedata[][22][32], uint room[] );

void touchobj( struct hero *jean, uint stagedata[][22][32], uint room[], uint *parchment, uint *changeflag, struct enem *enemies, float proyec[] );

void contact( struct hero *jean, struct enem enemies, float proyec[], uint room[] );

#endif

