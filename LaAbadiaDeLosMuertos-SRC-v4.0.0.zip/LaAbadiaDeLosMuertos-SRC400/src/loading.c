/* loading.c */
#include "loading.h"
#include "control.h"

size_t SDL_RWfgets( SDL_RWops* context, char* str, size_t num ) {
	if( context == NULL ) return 0;
	if( str     == NULL ) return 0;
	if( num     <  2    ) return 0;
	--num;
	size_t i = 0;
	char   c = 0;
	while( i < num ) { 
		if( SDL_RWread( context, &c, 1, 1 ) == 0 ) break;
		if( c == '\r' ) continue;
		if( c == '\n' ) { str[ i ] = 0; ++i; break; }
		str[ i ] = c; ++i;
	}
	if( i < num ) str[i] = 0;
	return i;
}

/*
SDL_bool copyfile( const char* src, const char* dst ) {
	SDL_RWops *srcfile = NULL;
	SDL_RWops *dstfile = NULL;
	void* buffer = NULL;
	size_t size  = 0; 
	size_t read  = 0;
	size_t write = 0;
	
	// ABRIMOS LA FUENTE
	srcfile = SDL_RWFromFile( src, "r" );
	if( srcfile == NULL ) return SDL_FALSE;
	
	// ABRIMOS EL DESTINO
	dstfile = SDL_RWFromFile( dst, "w" );
	if( dstfile == NULL ) {
		SDL_RWclose( srcfile );
		return SDL_FALSE;
	}
	
	// LEEMOS LA FUENTE 
	size   = (size_t)SDL_RWsize( srcfile );
	buffer = SDL_malloc( size );
	read  = SDL_RWread( srcfile, buffer, size, 1 );
	SDL_RWclose( srcfile );
	if( read == 0 ) {
		SDL_RWclose( dstfile );
		SDL_free( buffer );
		return SDL_FALSE;
	}
	
	// ESCRIBIMOS EN EL DESTINO 
	write = SDL_RWwrite( dstfile, (const void*)buffer, size, 1 );
	SDL_RWclose( dstfile );
	SDL_free( buffer );

	return ( write > 0 ) ? SDL_TRUE : SDL_FALSE;

}
*/

void readfile( SDL_RWops *file ) {
	char line[129];
	char* pos;
	size_t ret;
	
	do {
		ret = SDL_RWfgets( file, line, 129 );
		if( line[0] == '#' ) continue;

		pos = SDL_strstr( line, "language=" );
		if( pos != NULL ) {
			pos += 9;
			if( SDL_strstr( pos, "spanish" ) ) language = _SPANISH_;
			if( SDL_strstr( pos, "english" ) ) language = _ENGLISH_;
		#ifdef _SHOW_LOG_
			SDL_LOG( "language=%d\n", language );
		#endif
			continue;
		}

		pos = SDL_strstr( line, "graphics=" );
		if( pos != NULL ) {
			pos += 9;
			if( SDL_strstr( pos, "zx"   ) ) systemgraph = _ZXSPEC_;
			if( SDL_strstr( pos, "msx1" ) ) systemgraph = _MSX1_;
			if( SDL_strstr( pos, "msx2" ) ) systemgraph = _MSX2_;
		#ifdef _SHOW_LOG_
			SDL_LOG( "graphics=%d\n", systemgraph );
		#endif
			continue;
		}
		
		pos = SDL_strstr( line, "fullscreen=" );
		if( pos != NULL ) {
			pos += 11;
			if( SDL_strstr( pos, "on"  ) ) fullscreen = 1;
			if( SDL_strstr( pos, "off" ) ) fullscreen = 0;
		#ifdef _SHOW_LOG_
			SDL_LOG( "fullscreen=%d\n", fullscreen );
		#endif
			continue;
		}

		pos = SDL_strstr( line, "mutemusic=" );
		if( pos ) {
			pos += 10;
			if( SDL_strstr( pos, "on"  ) ) bmusic = SDL_FALSE;
			if( SDL_strstr( pos, "off" ) ) bmusic = SDL_TRUE;
		#ifdef _SHOW_LOG_
			SDL_LOG( "mutemusic=%d\n", !bmusic );
		#endif
			continue;
		}

		pos = SDL_strstr( line, "frame=" );
		if( pos != NULL ) {
			pos += 6;
			SDL_sscanf( pos, "%u\n", &frame );
			if     ( frame < 15  ) frame = 15;
			else if( frame > 200 ) frame = 200;
		#ifdef _SHOW_LOG_
			SDL_LOG( "frame=%u\n", frame );
		#endif
			continue;
		}
		
		pos = SDL_strstr( line, "windowzoom=" );
		if( pos != NULL ) {
			pos += 11;
			SDL_sscanf( pos, "%d\n", &zoom );
			if     ( zoom < 1 ) zoom = 1;
			else if( zoom > 6 ) zoom = 6;
		#ifdef _SHOW_LOG_
			SDL_LOG( "windowzoom=%d\n", zoom );
		#endif
			continue;
		}

		pos = SDL_strstr( line, "joystick=" );
		if( pos != NULL ) {
			pos += 9;
			SDL_sscanf( pos, "%d\n", &joyn );
			if     ( joyn < 0 ) joyn = 0;
			else if( joyn > 3 ) joyn = 0;
		#ifdef _SHOW_LOG_
			SDL_LOG( "joystick=%d\n", joyn );
		#endif
			continue;
		}

		pos = SDL_strstr( line, "joyaxisx=" );
		if( pos != NULL ) {
			pos += 9;
			SDL_sscanf( pos, "%d\n", &axisx );
			if     ( axisx < 0  ) axisx = 0;
			else if( axisx > 16 ) axisx = 0;
		#ifdef _SHOW_LOG_
			SDL_LOG( "joyaxisx=%d\n", axisx );
		#endif
			continue;
		}

		pos = SDL_strstr( line, "joyaxisy=" );
		if( pos!= NULL ) {
			pos += 9;
			SDL_sscanf( pos, "%d\n", &axisy );
			if     ( axisy < 0  ) axisy = 1;
			else if( axisy > 16 ) axisy = 1;
		#ifdef _SHOW_LOG_
			SDL_LOG( "joyaxisy=%d\n", axisy );
		#endif
			continue;	
		}
		
		pos = SDL_strstr( line, "joyflip=" );
		if( pos!= NULL ) {
			pos += 8;
			if( SDL_strstr( pos, "x"  ) ) flipx = -1;
			if( SDL_strstr( pos, "y"  ) ) flipy = -1;
		#ifdef _SHOW_LOG_
			SDL_LOG( "joyflip=%d,%d\n", flipx, flipy );
		#endif
			continue;
		}

		pos = SDL_strstr( line, "joyaxisr=" );
		if( pos != NULL ) {
			pos += 9;
			SDL_sscanf( pos, "%d\n", (int*)&axisr );
			if     ( axisr < 16 ) axisr = 12000;
		#ifdef _SHOW_LOG_
			SDL_LOG( "joyaxisr=%d\n", axisr );
		#endif
			continue;
		}

		pos = SDL_strstr( line, "touchzoom=" );
		if( pos != NULL ) {
			pos += 10;
			SDL_sscanf( pos, "%f\n", &touch.zoom );
			if( touch.zoom < 0.5f ) touch.zoom = 0.5f;
			if( touch.zoom > 2.0f ) touch.zoom = 2.0f;
		#ifdef _SHOW_LOG_
			SDL_LOG( "touchzoom=%1.3f\n", touch.zoom );
		#endif
			continue;
		}

		pos = SDL_strstr( line, "touchalpha=" );
		if( pos != NULL ) {
			pos += 11;
			SDL_sscanf( pos, "%d\n", &touch.alpha );
			if( touch.alpha < 32  ) touch.alpha = 32;
			if( touch.alpha > 255 ) touch.alpha = 255;
		#ifdef _SHOW_LOG_
			SDL_LOG( "touchalpha=%u\n", touch.alpha );
		#endif
			continue;
		}

	} while( ret > 0 );
			
}

void readpath() {
	if( configpath != NULL ) return;
#ifdef _PORT_ANDROID_
	const char* path = SDL_AndroidGetExternalStoragePath();
	size_t len = SDL_strlen( path ) + SDL_strlen( _FILE_CONFIG_ ) + 1;
	configpath = SDL_malloc( len );
	if( configpath == NULL ) return;
	SDL_strlcpy( configpath, path, len );
	SDL_strlcat( configpath, _FILE_CONFIG_, len );
	// SDL_free( path );
#else
	size_t len = SDL_strlen( _FILE_CONFIG_ ) + 1;
	configpath = SDL_malloc( len );
	SDL_strlcpy( configpath, _FILE_CONFIG_, len );
#endif

#ifdef _SHOW_LOG_
	SDL_LOG( "configpath=%s\n", configpath );
#endif
	// __android_log_print( ANDROID_LOG_ERROR, "ABBAYE", "configpath=%s\n", configpath );
}
	
void readconfigfile() {	
	if( configpath == NULL ) return;
#ifdef _PORT_ANDROID_
	if( ( SDL_AndroidGetExternalStorageState() & SDL_ANDROID_EXTERNAL_STORAGE_READ  ) == 0 ) {
	#ifdef _SHOW_LOG_
		SDL_LOG( "SDL_ANDROID_EXTERNAL_STORAGE_READ = FALSE\n" );
	#endif
		return;
	} 
#endif	
	
	/* Leemos el archivo de configuraci�n */
	SDL_RWops *file = NULL;
	file = SDL_RWFromFile( configpath, "r" );
	
	/* No hay archivo de configuraci�n */
	if( file == NULL ) return;
	
	/* En este punto debiera est�r abierto el archivo de configuraci�n*/
	/* Leemos la informaci�n del archivo de configuraci�n */
	readfile( file );
	
	/* Cerramos  el fichero */
	SDL_RWclose( file );
	
}

void writeconfigfile() {
	if( configpath == NULL ) return;
#ifdef _PORT_ANDROID_
	if( ( SDL_AndroidGetExternalStorageState() & SDL_ANDROID_EXTERNAL_STORAGE_WRITE ) == 0 ) {
	#ifdef _SHOW_LOG_
		SDL_LOG( "SDL_ANDROID_EXTERNAL_STORAGE_WRITE = FALSE\n" );
	#endif
		return;
	}
#endif
		
	/* Abrimos el archivo de configuraci�n */
	char line[129];
	SDL_RWops *file = NULL;
	file = SDL_RWFromFile( configpath, "w" );
	if( file == NULL ) return;

	SDL_RWwrite( file, "#####################################################################\r\n", 71, 1 );
	SDL_RWwrite( file, "# language=spanish|[english]     Languaje (Only one).               #\r\n", 71, 1 );
	SDL_RWwrite( file, "# graphics=[zx]|msx1|msx2        Style ZX Spectrum, MSX1 or MSX2.   #\r\n", 71, 1 );	
	SDL_RWwrite( file, "# mutemusic=on|[off]             Mute the music.                    #\r\n", 71, 1 );
	SDL_RWwrite( file, "# fullscreen=on|[off]            Fullscreen mode.                   #\r\n", 71, 1 );
	SDL_RWwrite( file, "# frame=[15~200]                 Recommended 50, change game speed. #\r\n", 71, 1 );
	SDL_RWwrite( file, "# windowzoom=[1~6]               Window size (256x192) * zoom.      #\r\n", 71, 1 );
	SDL_RWwrite( file, "# joystick=[0~3]                 Number of Joystick, default 0.     #\r\n", 71, 1 );
	SDL_RWwrite( file, "# joyaxisx=[0~16]                Axis Horizontal, default 0.        #\r\n", 71, 1 );
	SDL_RWwrite( file, "# joyaxisy=[0~16]                Vertical Axis,   default 1.        #\r\n", 71, 1 );
	SDL_RWwrite( file, "# joyflip=[x|y|xy]               Flip Horizontal or Vertical Axis.  #\r\n", 71, 1 );
	SDL_RWwrite( file, "# joyaxisr=[0~32767]             Precision default 12000.           #\r\n", 71, 1 );
	SDL_RWwrite( file, "# touchzoom=[0.5f~2.0f]          Default 1.0f.                      #\r\n", 71, 1 );
	SDL_RWwrite( file, "# touchalpha=[32~255]            Default 127.                       #\r\n", 71, 1 );
	SDL_RWwrite( file, "#####################################################################\r\n", 71, 1 );
	if( language  == _ENGLISH_ ) 
		SDL_RWwrite( file, "language=english\r\n", 18, 1 );
	else
		SDL_RWwrite( file, "language=spanish\r\n", 18, 1 );
	if( systemgraph  == _ZXSPEC_ ) 
		SDL_RWwrite( file, "graphics=zx\r\n", 13, 1 );
	if( systemgraph  == _MSX1_ ) 
		SDL_RWwrite( file, "graphics=msx1\r\n", 15, 1 );
	if( systemgraph  == _MSX2_ ) 
		SDL_RWwrite( file, "graphics=msx2\r\n", 15, 1 );
	if( bmusic ) SDL_RWwrite( file, "mutemusic=off\r\n", 15, 1 );
	else         SDL_RWwrite( file, "mutemusic=on\r\n",  14, 1 );
	if( fullscreen ) SDL_RWwrite( file, "fullscreen=on\r\n",  15, 1 );
	else             SDL_RWwrite( file, "fullscreen=off\r\n", 16, 1 );
	SDL_snprintf( line, 128, "frame=%u\r\n", 1000 / frame );		
	SDL_RWwrite( file, line, SDL_strlen(line), 1 );
	SDL_snprintf( line, 128, "windowzoom=%u\r\n", zoom );		
	SDL_RWwrite( file, line, SDL_strlen(line), 1 );
	SDL_snprintf( line, 128, "joystick=%d\r\n", joyn );		
	SDL_RWwrite( file, line, SDL_strlen(line), 1 );
	SDL_snprintf( line, 128, "joyaxisx=%d\r\n", axisx );		
	SDL_RWwrite( file, line, SDL_strlen(line), 1 );
	SDL_snprintf( line, 128, "joyaxisy=%d\r\n", axisy );		
	SDL_RWwrite( file, line, SDL_strlen(line), 1 );
	if( ( flipx == -1 ) && ( flipy == -1 ) ) SDL_RWwrite( file, "joyflip=xy\r\n", 12, 1 );
	else if( flipx == -1 ) SDL_RWwrite( file, "joyflip=x\r\n", 11, 1 );
	else if( flipy == -1 ) SDL_RWwrite( file, "joyflip=y\r\n", 11, 1 );
	else                   SDL_RWwrite( file, "joyflip=\r\n",  10, 1 );
	SDL_snprintf( line, 128, "joyaxisr=%d\r\n", axisr );		
	SDL_RWwrite( file, line, SDL_strlen(line), 1 );
	SDL_snprintf( line, 128, "touchzoom=%1.3f\r\n", touch.zoom );		
	SDL_RWwrite( file, line, SDL_strlen(line), 1 );
	SDL_snprintf( line, 128, "touchalpha=%u\r\n", touch.alpha );		
	SDL_RWwrite( file, line, SDL_strlen(line), 1 );

	/* Cerramos  el fichero */
	SDL_RWwrite( file, "\r\n", 2, 1 );
	SDL_RWclose( file );	
}

uint loaddata(uint stagedata[][22][32],int enemydata[][7][15]) {

	int i = 0;
	int j = 0;
	int k = 0;
	char line[129],temp[4],line2[61];
	temp[3] = 0;

	/* Loading file */
	SDL_RWops *datafile = NULL;
	datafile = SDL_RWFromFile( _DATA_MAP_, "r" );
	if( datafile == NULL ) {
	#ifdef _SHOW_LOG
		SDL_LOG( "Error loading map: %s\n", SDL_GetError() );
	#endif
		return 1;
	}
	SDL_RWfgets( datafile, line, 129 );
	SDL_RWfgets( datafile, line, 129 );

	/* Cargamos los datos del fichero en el array */
	for( i=0; i<=24; i++ ) {
		for (j=0; j<=21; j++) {
			for (k=0; k<=31; k++) {
				temp[0] = line[k*4];
				temp[1] = line[(k*4) + 1];
				temp[2] = line[(k*4) + 2];
				SDL_sscanf(temp, "%d", &stagedata[i][j][k]);
			}
			SDL_RWfgets( datafile, line, 129 );
		}
		SDL_RWfgets( datafile, line, 129 );
	}

	/* Cerramos fichero */
	if( datafile != NULL ) SDL_RWclose( datafile );

	/* Loading file */
	datafile = NULL;
	datafile = SDL_RWFromFile( _DATA_ENEMIES_, "r" );
	if( datafile == NULL ) {
	#ifdef _SHOW_LOG
		SDL_LOG( "Error loading enemies: %s\n", SDL_GetError() );
	#endif
		return 1;
	}
	SDL_RWfgets( datafile, line2, 61 );
	SDL_RWfgets( datafile, line2, 61 );
	
	/* Cargamos los datos del fichero en el array */
	for (i=0; i<=24; i++) {
		for (j=0; j<7; j++) {
			for (k=0; k<15; k++) {
				temp[0] = line2[k*4];
				temp[1] = line2[(k*4) + 1];
				temp[2] = line2[(k*4) + 2];
				SDL_sscanf(temp, "%d", &enemydata[i][j][k]);
			}
			SDL_RWfgets( datafile, line2, 61 );
		}
		SDL_RWfgets( datafile, line2, 61 );
	}

	if( datafile != NULL ) SDL_RWclose( datafile );
	
	return 0;

}

void loadingcover() {

	SDL_Rect srcintro = {0,0,256,192};
	// SDL_Rect desintro = {0,0,256,192};
	SDL_Rect desintro_msx = {16,16,224,160};
	SDL_Rect rect_msx     = {0,0,256,23};
	// SDL_Event keyp;
	
	Uint8 c = 0;	
	Uint32 ticks, i_ticks, time_ticks, f_ticks;
	ticks = i_ticks = f_ticks = SDL_GetTicks();
	int key = 0;
	uint exit = 0;
	
	while( exit != 1 ) {
		
		/* Start game */
		if( ( f_ticks - ticks ) > 1000 )  { 
			exit = 1;
		}
		// Check Controls
		key = commoncontrol();
		if( ( key & _QUIT_ ) || ( key & _ESCAPE_ ) ) { 
			state = _RUN_DESTROY_; 
			pause = SDL_FALSE;
			if( loading != NULL ) SDL_DestroyTexture( loading );
			return;
		} 
		if( pause || ( key & _UP_  )  ) {
			if( loading != NULL ) SDL_DestroyTexture( loading );
			state = _RUN_STARTSCREEN_;
			return;
		}

		/* Cleaning the renderer */
		SDL_SetRenderDrawColor( renderer, 0, 0, 0, 255 );
		SDL_RenderClear( renderer );
		for( rect_msx.y -= 192; rect_msx.y < 192; rect_msx.y += 23 ) {
			if( systemgraph == _ZXSPEC_ )
				SDL_SetRenderDrawColor( renderer,  zxcolor[c][0],  zxcolor[c][1],  zxcolor[c][2], 255 );
			else 
				SDL_SetRenderDrawColor( renderer, msxcolor[c][0], msxcolor[c][1], msxcolor[c][2], 255 );
			SDL_RenderFillRect( renderer, &rect_msx );
			++c; if( c > 15 ) c = 0;
		}
		renderpresent();
		f_ticks = SDL_GetTicks();
		time_ticks = f_ticks - i_ticks;
		i_ticks = f_ticks;
		if( time_ticks < frame ) SDL_Delay( frame - time_ticks );
	}

	exit = 0;
	int c_systemgraph = systemgraph;
	SDL_SetRenderDrawColor( renderer, 0, 0, 0, 255 );

	ticks = i_ticks = f_ticks = SDL_GetTicks();
	while (exit != 1) {
		/* Start game */
		if( ( f_ticks - ticks ) > 5000 ) {
			state = _RUN_STARTSCREEN_;
			exit  = 1;
		}
		// Check Controls
		key = commoncontrol();
		if(  c_systemgraph != systemgraph  ) {
			if( loading != NULL ) SDL_DestroyTexture( loading );
			if     ( systemgraph == _MSX1_ ) loading = IMG_LoadTexture( renderer, _LOAD_MSX1_ );
			else if( systemgraph == _MSX2_ ) loading = IMG_LoadTexture( renderer, _LOAD_MSX2_ );
			else						   	 loading = IMG_LoadTexture( renderer, _LOAD_ZX_   );
			if( loading == NULL ) {
			#ifdef _SHOW_LOG_
				SDL_LOG( "Error loading: %s\n", SDL_GetError() );
			#endif
				state = _RUN_STARTSCREEN_;
				return;
			}
			c_systemgraph = systemgraph;
		}
		if( ( key & _QUIT_ ) || ( key & _ESCAPE_ ) ) { 
			state = _RUN_DESTROY_;
			pause = SDL_FALSE;
			exit = 1;
		} 
		if( pause || ( key & _UP_ ) ) {
			state = _RUN_STARTSCREEN_;
			exit = 1;
		}
		/* Cleaning the renderer */
		SDL_SetRenderDrawColor( renderer, 0, 0, 0, 255 );
		SDL_RenderClear( renderer );
		for( rect_msx.y -= 192; rect_msx.y < 192; rect_msx.y += 23 ) {
			if( systemgraph == _ZXSPEC_ )
				SDL_SetRenderDrawColor( renderer,  zxcolor[c][0],  zxcolor[c][1],  zxcolor[c][2], 255 );
			else 
				SDL_SetRenderDrawColor( renderer, msxcolor[c][0], msxcolor[c][1], msxcolor[c][2], 255 );
			SDL_RenderFillRect( renderer, &rect_msx );
			++c; if( c > 15 ) c = 0;
		}
		/* Put image on renderer */
		SDL_RenderCopy( renderer, loading, &srcintro, &desintro_msx );
		renderpresent();
		f_ticks = SDL_GetTicks();
		time_ticks = f_ticks - i_ticks;
		i_ticks = f_ticks;
		if( time_ticks < frame ) SDL_Delay( frame - time_ticks );

	}
	/* Cleaning */
	if( loading != NULL ) SDL_DestroyTexture( loading );
	SDL_SetRenderDrawColor( renderer, 0, 0, 0, 255 );
	SDL_RenderClear( renderer );
	renderpresent();
	return;
}

uint loadingmultimedia() {
	int i;

	/* Fxs */
	fx[0] = Mix_LoadWAV ( _SOUND_0_ );
	fx[1] = Mix_LoadWAV ( _SOUND_1_ );
	fx[2] = Mix_LoadWAV ( _SOUND_2_ );
	fx[3] = Mix_LoadWAV ( _SOUND_3_ );
	fx[4] = Mix_LoadWAV ( _SOUND_4_ );
	fx[5] = Mix_LoadWAV ( _SOUND_5_ );
	fx[6] = Mix_LoadWAV ( _SOUND_6_ );
	fx[7] = Mix_LoadWAV ( _SOUND_7_ );
	// fx[8] = Mix_LoadWAV ( _SOUND_8_ );
	for( i=0; i<8; i++ )  {
		if ( fx[i] == NULL ) {
		#ifdef _SHOW_LOG_
			SDL_LOG( "Mix_LoadWAV Error: %s\n", SDL_GetError() );
		#endif
			return SDL_FALSE;
		}
	}
	
	// Load Fonts:
	font = SDL_NewFont( _FONT_1_, SDL_TRUE, renderer, NULL );
	if( font == NULL ) {
	#ifdef _SHOW_LOG_
		SDL_LOG( "Error Font: %s\n", SDL_GetError() );
	#endif
		return SDL_FALSE;
	}
	minifont = SDL_NewFont( _FONT_2_, SDL_TRUE, renderer, NULL );
	if( minifont == NULL ) {
	#ifdef _SHOW_LOG_
		SDL_LOG( "Error Font: %s\n", SDL_GetError() );
	#endif
		return SDL_FALSE;
	}
	tiles  = IMG_LoadTexture( renderer, filespng[ systemgraph ] );
	if( tiles == NULL ) {
	#ifdef _SHOW_LOG_
		SDL_LOG( "Error loading tiles: %s\n", SDL_GetError() );
	#endif
		return SDL_FALSE;
	}
	
	/* Loading PNG */
	if     ( systemgraph == _MSX1_ ) loading = IMG_LoadTexture( renderer, _LOAD_MSX1_ );
	else if( systemgraph == _MSX2_ ) loading = IMG_LoadTexture( renderer, _LOAD_MSX2_ );
	else						   	 loading = IMG_LoadTexture( renderer, _LOAD_ZX_   );
	if( loading == NULL ) {
	#ifdef _SHOW_LOG_
		SDL_LOG( "Error loading: %s\n", SDL_GetError() );
	#endif
	}
				
	return SDL_TRUE;
}

void playmus( size_t num, int loops ) {
	if( num != c_num ) {
		Mix_HaltMusic();
		if( bso != NULL ) {
			Mix_FreeMusic( bso );
			bso = NULL;
		}
		if( num > 9 ) return;
		if( bmusic ) {
			bso = Mix_LoadMUS( fmn[ num ] );
			if( bso == NULL ) {
			#ifdef _SHOW_LOG_
				SDL_LOG( "Mix_LoadMUS Error: %s\n", SDL_GetError() );
			#endif
			} 
		}
	}
	if( bso != NULL ) Mix_PlayMusic( bso, loops );
	c_num = num;
}

void freemultimedia() {
	int i;
	if( bso != NULL ) {
		Mix_FreeMusic( bso );
		bso = NULL;
	} 
	for( i=0; i<8; i++ ) {
		if( fx[i] != NULL ) Mix_FreeChunk( fx[i] );
		fx[i] = NULL;
	}
	if( tiles   != NULL ) {
		SDL_DestroyTexture( tiles  );
		tiles = NULL;
	}
	if( loading != NULL ) {
		SDL_DestroyTexture( loading );
		loading = NULL;
	}
	if( font     != NULL ) {
		SDL_DeleteFont( font );
		font = NULL;
	}	
	if( minifont != NULL ) {
		SDL_DeleteFont( minifont );
		minifont = NULL;
	}
}

