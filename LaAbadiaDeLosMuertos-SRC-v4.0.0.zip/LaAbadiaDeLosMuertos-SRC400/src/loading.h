/* loading.h */
#ifndef _LOADING_
#define _LOADING_
#include "environment.h"

size_t SDL_RWfgets( SDL_RWops* context, char* str, size_t num );

void readpath();

void readconfigfile();

void writeconfigfile();

uint loaddata( uint stagedata[][22][32], int enemydata[][7][15] );

void loadingcover();

SDL_bool loadingmultimedia();

void playmus( size_t num, int loops );

void freemultimedia();

#endif

