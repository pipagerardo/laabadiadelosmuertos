/* L'Abbaye des Morts */
/* The Abbey of the Dead */
/* La Abadia de los Muertos */
/* Version 3.0.8 */
/* (c) 2010 - Locomalito & Gryzor87 */
/* 2013 - David "Nevat" Lara */
/* 2015 - PIPAGERARDO */
/* GPL v3 license */
#ifndef _PORT_ANDROID_
#define SDL_MAIN_HANDLED
#endif

#include "environment.h"
#include "control.h"
#include "loading.h"
#include "startscreen.h"
#include "demo.h"
#include "history.h"
#include "game.h"
#include "gameover.h"
#include "ending.h"


#ifndef _PORT_ANDROID_	
int main() {
#else
int main( int argc, char* args[] ) {
#endif

	SDL_bool running = SDL_TRUE;
	
	#ifndef _PORT_ANDROID_
	SDL_SetMainReady();
	#endif
	
	/* Read Path */
	readpath();
	
	/* Read config file */
	readconfigfile();
	
	/* Init SDL */
	if( !init() ) return destroy( _EXIT_FAILURE_ );
	
	/* Load music and graphics	*/	
	if( !loadingmultimedia() ) return destroy( _EXIT_FAILURE_ );
	
	updatetouch();
	/* Bucle principal */
	while( running ) {
		switch( state ) {
			case _RUN_LOADING_:		loadingcover(); 		break;
			case _RUN_STARTSCREEN_:	startscreen();			break;
			case _RUN_DEMO_: 		demo(); 				break;
			case _RUN_HISTORY_:		history(); 				break;
			case _RUN_GAME_: 		game(); 				break;
			case _RUN_GAMEOVER_: 	gameover(); 			break;
			case _RUN_ENDING_: 		ending(); 				break;
			case _RUN_DESTROY_: 	running = SDL_FALSE;	break;
		}
	}

	/* Write config file */
	writeconfigfile();
	
	/* Exiting normally */
	return destroy( _EXIT_SUCCESSFUL_ );

}

