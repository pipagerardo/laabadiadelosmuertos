/* startscreen.c */
#include "startscreen.h"
#include "control.h"
#include "loading.h"

void showabbey() {
	SDL_Rect srcintro;
	SDL_Rect desintro;
	desintro.x =  34; desintro.y =  21;
	desintro.w = 186; desintro.h =  34;
	srcintro.x =   0; srcintro.y =  120;
	srcintro.w = 186; srcintro.h =  34;
	int i;
	for( i = 0; i < 4; ++i ) {
		SDL_RenderCopy( renderer, tiles, &srcintro, &desintro);
		desintro.y +=  34; srcintro.x += 186;
	}
}

void showtitle() {
	SDL_Rect srcintro;
	SDL_Rect desintro;
	desintro.x = 109; desintro.y =  16;
	desintro.w = 108; desintro.h =  72;
	srcintro.x = 762; srcintro.y =   0;
	srcintro.w = 108; srcintro.h =  72;
	SDL_RenderCopy( renderer, tiles, &srcintro, &desintro);
}

void showabbeytexts() {
	// Magenta
	if( systemgraph == _ZXSPEC_ )	SDL_ColorModFont( minifont, 255,  0, 255 ); 
	else							SDL_ColorModFont( minifont, 201, 91, 186 );
	SDL_TextFontR( minifont, " FREEWARE", 0, 4 );
	SDL_TextRFontR( minifont, "� 2010 ", 4 );
	
	SDL_TextRFontR( minifont, "A GAME BY LOCOMALITO ", 161 ); 
	SDL_TextRFontR( minifont, "MUSIC BY GRYZOR87 ", 170 ); 
	SDL_TextRFontR( minifont, _VERSION_, 179 );
	// Amarillo
	if( systemgraph == _ZXSPEC_ ) 	SDL_ColorModFont( minifont, 255, 255,   0 ); 
	else					 		SDL_ColorModFont( minifont, 230, 206, 128 );
	SDL_TextFontR( minifont, texts[ language + 23 ], 0, 161 );
	// Cian
	if( systemgraph == _ZXSPEC_ )	SDL_ColorModFont( minifont,  0, 255, 255 ); 
	else  							SDL_ColorModFont( minifont, 66, 235, 245 ); 
	SDL_TextFontR( minifont, texts[ language + 24 ], 0,  170 );
	SDL_TextFontR( minifont, texts[ language + 25 ], 0,  179 );	
}

void showinfo1( uint animation ) {		
	SDL_Rect srcintro;
	SDL_Rect desintro;

	// Amarillo
	if( systemgraph == _ZXSPEC_ )	SDL_ColorModFont( minifont, 255, 255,   0 ); 
	else					 		SDL_ColorModFont( minifont, 230, 206, 128 );
	SDL_TextFontR( minifont, texts[ language + 27 ], 26, 12 );
	SDL_TextFontR( minifont, texts[ language + 28 ], 26, 22 );
	desintro.x =  10; desintro.y =   9;
	desintro.w =  14; desintro.h =  24;
	// srcintro.x = 322+((animation/8) * 16);
	srcintro.x = 322+(( animation >> 3 ) << 4 ); 
	srcintro.y =  88;
	srcintro.w =  14; srcintro.h =  24;
	SDL_RenderCopy( renderer, tiles, &srcintro, &desintro);
	SDL_TextFontR( minifont, texts[ language + 26 ], 211, 150 );
	desintro.x = 196; desintro.y = 148;
	desintro.w =  10; desintro.h =  13;
	srcintro.x = 587; srcintro.y =  89;
	srcintro.w =  10; srcintro.h =  13;
	SDL_RenderCopy( renderer, tiles, &srcintro, &desintro);
	SDL_TextFontR( minifont, texts[ language + 26 ], 231, 170 );
	desintro.x = 210; desintro.y = 166;
	desintro.w =  16; desintro.h =   8;
	srcintro.x =  96; srcintro.y =  16;
	srcintro.w =  16; srcintro.h =   8;
	SDL_RenderCopy( renderer, tiles, &srcintro, &desintro);
	desintro.y +=  8; srcintro.x += 16;
	SDL_RenderCopy( renderer, tiles, &srcintro, &desintro);
	// Fin Amarillo 
	
	// Gris
	if( systemgraph == _ZXSPEC_ )	SDL_ColorModFont( minifont, 205, 205, 205 );
	else 							SDL_ColorModFont( minifont, 204, 204, 204 );
	SDL_TextFontR( minifont, texts[ language + 26 ], 230, 12 );
	desintro.x = 211; desintro.y =   9;
	desintro.w =  16; desintro.h =   8;
	srcintro.x = 336; srcintro.y =  16;
	srcintro.w =  16; srcintro.h =   8;
	SDL_RenderCopy( renderer, tiles, &srcintro, &desintro);
	desintro.y +=  8; srcintro.x += 16;
	SDL_RenderCopy( renderer, tiles, &srcintro, &desintro); 
	SDL_TextFontR( minifont, texts[ language + 32 ], 187, 67 );
	SDL_TextFontR( minifont, texts[ language + 33 ], 187, 77 );
	desintro.x = 167; desintro.y =  62;
	desintro.w =  16; desintro.h =   8;
	srcintro.x = 256; srcintro.y =  16;
	srcintro.w =  16; srcintro.h =   8;
	SDL_RenderCopy( renderer, tiles, &srcintro, &desintro);
	desintro.y +=  8; srcintro.x += 16;
	SDL_RenderCopy( renderer, tiles, &srcintro, &desintro);
	desintro.y +=  8; srcintro.x += 16;
	SDL_RenderCopy( renderer, tiles, &srcintro, &desintro);
	SDL_TextFontR( minifont, texts[ language + 36 ], 29, 159 );
	SDL_TextFontR( minifont, texts[ language + 37 ], 29, 169 );
	desintro.x =   9; desintro.y = 160;
	desintro.w =  16; desintro.h =   8;
	srcintro.x = 160; srcintro.y =  16;
	srcintro.w =  16; srcintro.h =   8;
	SDL_RenderCopy( renderer, tiles, &srcintro, &desintro);
	desintro.y +=  8; srcintro.x += 16;
	SDL_RenderCopy( renderer, tiles, &srcintro, &desintro);
	// Fin Gris
	
	// Verde
	if( systemgraph == _ZXSPEC_ )	SDL_ColorModFont( minifont,  0, 255,   0 ); 
	else							SDL_ColorModFont( minifont, 94, 220, 120 );
	SDL_TextFontR( minifont, texts[ language + 29 ], 150, 36 );
	desintro.x = 131; desintro.y =  34;
	desintro.w =  16; desintro.h =   8;
	srcintro.x = 224; srcintro.y =  16;
	srcintro.w =  16; srcintro.h =   8;
	SDL_RenderCopy( renderer, tiles, &srcintro, &desintro);
	desintro.y +=  8; srcintro.x += 16;
	SDL_RenderCopy( renderer, tiles, &srcintro, &desintro);
	// Fin Verde
	
	// Rojo
	if( systemgraph == _ZXSPEC_ )	SDL_ColorModFont( minifont, 255,   0,   0 );
	else							SDL_ColorModFont( minifont, 255, 121, 120 );
	SDL_TextFontR( minifont, texts[ language + 30 ], 47, 57 );
	desintro.x =  31; desintro.y =  55;
	desintro.w =  16; desintro.h =   8;
	// srcintro.x =  96 + ((animation/8) * 32);
	srcintro.x =  96 + (( animation >> 3 ) << 5 ); 
	srcintro.y =  24;
	srcintro.w =  16; srcintro.h =   8;
	SDL_RenderCopy( renderer, tiles, &srcintro, &desintro);
	desintro.y +=  8; srcintro.x += 16;
	SDL_RenderCopy( renderer, tiles, &srcintro, &desintro);
	// Fin Rojo
	
	// Cian
	if( systemgraph == _ZXSPEC_ )	SDL_ColorModFont( minifont,  0, 255, 255 ); 
	else  							SDL_ColorModFont( minifont, 66, 235, 245 ); 
	SDL_TextFontR( minifont, texts[ language + 31 ], 34, 79 );
	desintro.x =  21; desintro.y =  80;
	desintro.w =   8; desintro.h =   8;
	// srcintro.x = 664 + ((animation/4) * 8);
	srcintro.x = 664 + (( animation >> 2 ) << 3); 
	srcintro.y =   0; // 680
	srcintro.w =   8; srcintro.h =   8;
	SDL_RenderCopy( renderer, tiles, &srcintro, &desintro);
	// Fin Cian
	
	// Magenta
	if( systemgraph == _ZXSPEC_ )	SDL_ColorModFont( minifont, 255,  0, 255 ); 
	else							SDL_ColorModFont( minifont, 201, 91, 186 );
	SDL_TextFontR( minifont, texts[ language + 34 ], 152, 113 );
	SDL_TextFontR( minifont, texts[ language + 35 ], 152, 123 );
	desintro.x = 114; desintro.y = 111;
	desintro.w =  32; desintro.h =  26;
	// srcintro.x =  ((animation/8) * 32);
	srcintro.x =  (( animation >> 3 ) << 5 ); 
	srcintro.y =  90;
	srcintro.w =  32; srcintro.h =  26;
	SDL_RenderCopy( renderer, tiles, &srcintro, &desintro);
	// Fin Magenta
	
	// Azul
	if( systemgraph == _ZXSPEC_ )	SDL_ColorModFont( minifont,   0,   0, 205 ); 
	else							SDL_ColorModFont( minifont, 125, 118, 252 );
	SDL_TextFontR( minifont, texts[ language + 26 ], 64, 123 );
	desintro.x =  44; desintro.y = 114;
	desintro.w =  16; desintro.h =  24;
	// srcintro.x = 600+ ((animation/4) * 16);
	srcintro.x = 600+ ((animation >> 2 ) << 4 ); 
	srcintro.y =   0;
	srcintro.w =  16; srcintro.h =  24;
	SDL_RenderCopy( renderer, tiles, &srcintro, &desintro);
	// Fin Azul

}

void showinfo2() {		
	SDL_Rect srcintro;
	SDL_Rect desintro;

	// Amarillo
	if( systemgraph == _ZXSPEC_ )	SDL_ColorModFont( minifont, 255, 255,   0 ); 
	else					 		SDL_ColorModFont( minifont, 230, 206, 128 );
	SDL_TextHFontR( minifont, "L'Abbaye des Morts", 0 ); 
	// Magenta
	if( systemgraph == _ZXSPEC_ )	SDL_ColorModFont( minifont, 255,  0, 255 ); 
	else							SDL_ColorModFont( minifont, 201, 91, 186 );
	SDL_TextHFontR( minifont, "The Abbey of the Dead", 10 );	
	// Rojo
	if( systemgraph == _ZXSPEC_ )	SDL_ColorModFont( minifont, 255,   0,   0 );
	else							SDL_ColorModFont( minifont, 255, 121, 120 );
	SDL_TextHFontR( minifont, "La Abad�a de los Muertos", 20 );	

	// Verde
	if( systemgraph == _ZXSPEC_ )	SDL_ColorModFont( minifont,  0, 255,   0 ); 
	else							SDL_ColorModFont( minifont, 94, 220, 120 );
	if( language == _SPANISH_ ) {
	SDL_TextFontR( minifont, "OPCIONES:", 8, 36 );
	#ifdef _PORT_ANDROID_
	SDL_TextFontR( minifont, "Tocando la parte superior de la pantalla:", 16, 46 );
	SDL_TextFontR( minifont, "Izquierda - Gr�ficos ZX, MSX1 o MSX2.. .", 16, 56 );
	SDL_TextFontR( minifont, "Centro - Pausa.", 16, 66 );
	SDL_TextFontR( minifont, "Derecha - Quitar t�ctil.", 16, 76 );
	#else
	SDL_TextFontR( minifont, "L - Idioma Espa�ol o Ingles.", 16, 46 );
	SDL_TextFontR( minifont, "P - Pausa.", 16, 56 );
	SDL_TextFontR( minifont, "G - Gr�ficos ZX, MSX1 o MSX2.", 16, 66 );
	SDL_TextFontR( minifont, "M - Quita la m�sica.", 16, 76 );
	#endif
	} else {
	SDL_TextFontR( minifont, "OPTIONS:", 8, 36 );
	#ifdef _PORT_ANDROID_
	SDL_TextFontR( minifont, "Touching the top of the screen:", 16, 46 );
	SDL_TextFontR( minifont, "Left - Graphics ZX, MSX1 or MSX2.", 16, 56 );
	SDL_TextFontR( minifont, "Center - Pause.", 16, 66 );
	SDL_TextFontR( minifont, "Right - Remove touch.", 16, 76 );
	#else
	SDL_TextFontR( minifont, "L - Spanish or English language.", 16, 46 );
	SDL_TextFontR( minifont, "P - Pause.", 16, 56 );
	SDL_TextFontR( minifont, "G - Graphics ZX, MSX1 or MSX2.", 16, 66 );
	SDL_TextFontR( minifont, "M - Mutes the music.", 16, 76 );
	#endif
	}

	// Gris
	if( systemgraph == _ZXSPEC_ )	SDL_ColorModFont( minifont, 205, 205, 205 );
	else 							SDL_ColorModFont( minifont, 204, 204, 204 );
	if( language == _SPANISH_ ) {
	SDL_TextFontR( minifont, "CONTROL:",    8, 92 );
	SDL_TextFontR( minifont, "TECLADO",   62, 92 );
	SDL_TextFontR( minifont, "JOYSTICK", 156, 92 );
	SDL_TextFontR( minifont, "Derecha",   16, 102 );
	SDL_TextFontR( minifont, "Izquierda", 16, 112 );
	SDL_TextFontR( minifont, "Agacharse", 16, 122 );
	SDL_TextFontR( minifont, "Saltar",    16, 132 );
	SDL_TextFontR( minifont, "Cursor derecho",   70, 102 );
	SDL_TextFontR( minifont, "Cursor izquierdo", 70, 112 );
	SDL_TextFontR( minifont, "Cursor abajo",     70, 122 );
	SDL_TextFontR( minifont, "Arriba o espacio", 70, 132 );
	SDL_TextFontR( minifont, "Palanca derecha",   162, 102 );
	SDL_TextFontR( minifont, "Palanca izquierda", 162, 112 );
	SDL_TextFontR( minifont, "Palanca abajo",     162, 122 );
	SDL_TextFontR( minifont, "Bot�n 1, 2 o 3",    162, 132 );
	} else {
	SDL_TextFontR( minifont, "CONTROL:",    8, 92 );
	SDL_TextFontR( minifont, "KEYBOARD",   62, 92 );
	SDL_TextFontR( minifont, "JOYSTICK", 156, 92 );
	SDL_TextFontR( minifont, "Right",   16, 102 );
	SDL_TextFontR( minifont, "Left", 16, 112 );
	SDL_TextFontR( minifont, "Ducking", 16, 122 );
	SDL_TextFontR( minifont, "Jump",    16, 132 );
	SDL_TextFontR( minifont, "Right",   70, 102 );
	SDL_TextFontR( minifont, "Left", 70, 112 );
	SDL_TextFontR( minifont, "Down",     70, 122 );
	SDL_TextFontR( minifont, "Up or space", 70, 132 );
	SDL_TextFontR( minifont, "Right lever",   162, 102 );
	SDL_TextFontR( minifont, "Left lever", 162, 112 );
	SDL_TextFontR( minifont, "Down Lever",     162, 122 );
	SDL_TextFontR( minifont, "Button 1, 2 o 3",  162, 132 );
	}

	// Rojo
	if( systemgraph == _ZXSPEC_ )	SDL_ColorModFont( minifont, 255,   0,   0 );
	else							SDL_ColorModFont( minifont, 255, 121, 120 );
	if( language == _SPANISH_ ) {
	SDL_TextHFontR( minifont, "Versi�n Original por LOCOMALITO", 152 );	
	} else {
	SDL_TextHFontR( minifont, "Original Version by LOCOMALITO", 152 );	
	}
	// Magenta
	if( systemgraph == _ZXSPEC_ )	SDL_ColorModFont( minifont, 255,  0, 255 ); 
	else							SDL_ColorModFont( minifont, 201, 91, 186 );
	if( language == _SPANISH_ ) {
	SDL_TextHFontR( minifont, "Musica por GRYZOR87", 162 );
	} else {
	SDL_TextHFontR( minifont, "Music by GRYZOR87", 162 );
	}
	// Cian
	if( systemgraph == _ZXSPEC_ )	SDL_ColorModFont( minifont,  0, 255, 255 ); 
	else  							SDL_ColorModFont( minifont, 66, 235, 245 ); 
	if( language == _SPANISH_ ) {
	SDL_TextHFontR( minifont, "Versi�n de Linux por David NEVAT Lara", 172 );
	} else {
	SDL_TextHFontR( minifont, "Linux version by David NEVAT Lara", 172 );
	}
	// Amarillo
	if( systemgraph == _ZXSPEC_ )	SDL_ColorModFont( minifont, 255, 255,   0 ); 
	else					 		SDL_ColorModFont( minifont, 230, 206, 128 );
	if( language == _SPANISH_ ) {
	#ifdef _PORT_ANDROID_
	SDL_TextHFontR( minifont, "Versi�n Android por PIPAGERARDO", 182 );
	#else
	SDL_TextHFontR( minifont, "Versi�n Windows por PIPAGERARDO", 182 );
	#endif	
	} else {
	#ifdef _PORT_ANDROID_
	SDL_TextHFontR( minifont, "Android version by PIPAGERARDO", 182 );
	#else
	SDL_TextHFontR( minifont, "Windows version by PIPAGERARDO", 182 );
	#endif	
	}
	SDL_RenderCopy( renderer, tiles, &srcintro, &desintro);
}
	
void startscreen() {

	SDL_SetRenderDrawColor( renderer, 0, 0, 0, 255 );
	if( pause ) {
		SDL_RenderClear( renderer );
		showabbey();
		renderpresent();
	}
	
	/* Joysticks */
	/*
	if( joystick == NULL ) {
		int nJoysticks = SDL_NumJoysticks();
		if( nJoysticks > 0 ) joystick = SDL_JoystickOpen( joyn );
		// int SDL_JoystickNumAxes( joystick );
		// int SDL_JoystickNumBalls( joystick );
		// int SDL_JoystickNumHats( joystick );
		// int SDL_JoystickNumButtons( joystick );
	} else {
		if( !SDL_JoystickGetAttached( joystick ) ) {
			SDL_JoystickClose( joystick );
			joystick = NULL;
		}
	}
	*/
	
	uint exit = 0;
	uint musicplay = 0;
	SDL_bool info1 = SDL_FALSE;
	SDL_bool info2 = SDL_FALSE;
	// SDL_Event keyp;
	Uint32 i_ticks, time_ticks, f_ticks, tmp;
	i_ticks = tmp = SDL_GetTicks();
	int i = 0;
	int key = 0;
	uint animation = 0;
	
	while( exit != 1 ) {
		
		// Check Controls
		key = commoncontrol();

		if( ( i_ticks - tmp ) > 15000 ) {
			state = _RUN_DEMO_;
			exit  = 1;
		} 
		if( ( key & _QUIT_ ) || ( key & _ESCAPE_ ) ) { 
			state = _RUN_DESTROY_; 
			pause = SDL_FALSE;
			exit = 1;
		} 
		if( key & _INFO_ ) { // Show instructions  
			tmp = SDL_GetTicks();
			if ( info2 == SDL_TRUE ) {
				info2 = SDL_FALSE;
				musicplay = 0;
			} else if( info1 == SDL_FALSE ) {
				info1 = SDL_TRUE;
				Mix_HaltMusic();
				Mix_PlayChannel( -1, fx[2], 0 );
			} else {
				info1 = SDL_FALSE;
				info2 = SDL_TRUE;
				Mix_PlayChannel( -1, fx[2], 0 );
			} 
		}
		if( key & _UP_ ) { // Start game 
			if( info1 == SDL_TRUE ) {
				info1 = SDL_FALSE;
				info2 = SDL_TRUE;
				Mix_PlayChannel( -1, fx[2], 0 );
			} else if ( info2 == SDL_TRUE ) {
				info2 = SDL_FALSE;
				musicplay = 0;
			} else {
				state = _RUN_HISTORY_;
				exit =  1;
			}		
		}
		
		/* Play music if required */
		if( musicplay == 0 ) {
			musicplay = 1;
			playmus( 8, 0 );
			for( i = 0; i < 16; ++i ) {
				key = commoncontrol();
				if( ( key & _QUIT_ ) || ( key & _ESCAPE_ ) ) { exit = 1; state = _RUN_DESTROY_; break; } 
				if( pause || ( key & _UP_ ) ) break;
				SDL_RenderClear( renderer );
				showabbey();
				if( systemgraph == _ZXSPEC_ ) SDL_SetTextureColorMod( tiles,  zxcolor[i][0],  zxcolor[i][1],   zxcolor[i][2] );
				else  SDL_SetTextureColorMod( tiles,  msxcolor[i][0], msxcolor[i][1], msxcolor[i][2] );
				showtitle();
				SDL_SetTextureColorMod( tiles , 255, 255, 255 );
				renderpresent();
				SDL_Delay( 100 );
			}
			/* Joysticks */
			if( joystick == NULL ) {
				int nJoysticks = SDL_NumJoysticks();
				if( nJoysticks > 0 ) joystick = SDL_JoystickOpen( joyn );
			}
			SDL_Delay( 200 );
		}
	
		/* Cleaning the renderer */
		SDL_RenderClear( renderer );
		if     ( info1 ) showinfo1( animation );
		else if( info2 ) showinfo2();
		else {
			showabbey();
			showtitle();
			showabbeytexts();
			SDL_Rect srcintro;
			SDL_Rect desintro;
			desintro.x =  220; desintro.y =  124;
			desintro.w =   32; desintro.h =   32;
			srcintro.x =  936;		// Teclado
			if( joystick != NULL ) srcintro.x =  968;
			if( touch.id != 0 )    srcintro.x =  904;						
			srcintro.y =  122;
			srcintro.w =   32; srcintro.h =  32;
			SDL_RenderCopy( renderer, tiles, &srcintro, &desintro );
		}
		
		/* Animation control */
		if (animation < 15) animation ++;
		else				animation = 0;   

		/* Flip ! */
		renderpresent();
		
		if( pause ) {
			info1 = SDL_FALSE;
			info2 = SDL_FALSE;
			Mix_PauseMusic();
			while( !exit && pause ) {
				key = commoncontrol();
				if( key & _QUIT_   ) { exit = 1; state = _RUN_DESTROY_; pause = SDL_FALSE; }
				if( key & _ESCAPE_ ) { exit = 1; state = _RUN_STARTSCREEN_; pause = SDL_FALSE; }
				if( key & _INFO_   ) { touch.alpha += 16; if( touch.alpha > 255 ) touch.alpha = 32; updatetouch(); }
				if( key & _UP_     ) { touch.zoom += 0.05f; updatetouch(); }
				if( key & _DOWN_   ) { touch.zoom -= 0.05f; updatetouch(); }
				SDL_RenderClear( renderer );
				showabbey();
				showtitle();
				showabbeytexts();
				SDL_TextHVFontR( font, texts[ language + 66 ] );
				renderpresent();
				SDL_Delay( frame );	
			}
			Mix_ResumeMusic();
			SDL_RenderClear( renderer );
		} 

		f_ticks = SDL_GetTicks();
		time_ticks = f_ticks - i_ticks;
		i_ticks = f_ticks;
		if( time_ticks < frame ) SDL_Delay( frame - time_ticks );

	}
	Mix_HaltMusic();
	if( ( state == _RUN_DESTROY_ ) || ( state == _RUN_DEMO_ ) ) return;
	
	/* Trueno */
	Mix_PlayChannel( -1, fx[7], 0 );
	for( i = 0; i < 9; ++i ) {
		key = commoncontrol();
		if( ( key & _QUIT_ ) || ( key & _ESCAPE_ ) ) { state = _RUN_DESTROY_; Mix_HaltChannel( -1 ); break; } 
		if( pause || ( key & _UP_ ) ) break;
		SDL_SetRenderDrawColor( renderer, 255, 255, 255, 255 );
		SDL_RenderClear( renderer );
		showtitle();
		SDL_SetTextureColorMod( tiles , 0, 0, 0 );
		showabbey();
		renderpresent();
		SDL_Delay( 90 );
		SDL_SetRenderDrawColor( renderer, 0, 0, 0, 255 );
		SDL_RenderClear( renderer );
		SDL_SetTextureColorMod( tiles , 255, 255, 255 );
		showabbey();
		showtitle();
		renderpresent();
		SDL_Delay( 90 );
	}
	for( i = 0; i < 2400; i += 100 ) {
		key = commoncontrol();
		if( ( key & _QUIT_ ) || ( key & _ESCAPE_ ) ) { state = _RUN_DESTROY_; break; } 
		if( pause || ( key & _UP_ ) ) break;
		SDL_Delay( 100 );
	}
	Mix_HaltChannel( -1 );
	
}

