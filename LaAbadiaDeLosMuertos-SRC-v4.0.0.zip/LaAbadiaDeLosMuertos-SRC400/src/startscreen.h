/* startscreen.h */
#ifndef _STARTSCREEN_
#define _STARTSCREEN_
#include "environment.h"

void startscreen();

#endif

